import type { LevelPartition } from '@endfield-noclip/formats/endfield/level-partition';
import type { PlaceInfo } from '@endfield-noclip/package-format/manifest';
import type { Vec3 } from '@endfield-noclip/package-format/values';

import type { StructureModel } from '../dynamic/dynamic-structures.ts';
import type { Alternatives } from '../state/game-state.ts';
import type { InteractiveStateGate } from '../state/interactive-variables.ts';
import type { DraftControl, Visibility } from '../state/scene-control.ts';

import { AnimatorStarts } from './animator-starts.ts';
import { TelescopicBridges } from './bridges.ts';
import { CraneTowers } from './cranes.ts';
import { DoodadGrades } from './doodad-grades.ts';
import { DoodadGroups } from './doodad-groups.ts';
import { type InteractiveDoor, InteractiveDoors } from './doors.ts';
import { ElectricFences } from './electric-fences.ts';
import { FacilityForms } from './facility-forms.ts';
import {
	type FacilityContext,
	FacilitySources,
	PrefabHashes,
	type UnsupportedFile,
} from './facility-sources.ts';
import {
	type InteractiveKind,
	InteractiveRow,
	rowGate,
	RowSwitches,
	type TemplateReader,
} from './interactive-row.ts';
import { JumpPads } from './jump-pads.ts';
import { MovingPlatforms } from './moving-platforms.ts';
import { collectPlacements, LevelDataExtras } from './placed-interactives.ts';
import { RegionWalls } from './region-walls.ts';
import { RestLooks } from './rest-looks.ts';
import { RestingEffects } from './resting-effects.ts';
import { loadInteractiveTable, resolveTemplateModels } from './template-models.ts';
import { TemplateTraitsReader } from './template-traits.ts';

export type { InteractiveDoor } from './doors.ts';

/** a placed interactive with a model the reader couldn't find, to draw a stand-in for */
export interface InteractiveStandIn {
	/** `<LevelData path>#<row id>` */
	source: string;
	template: string;
	reason: string;
	levelTag: number;
	position: [number, number, number];
	/** Unity Euler angles, degrees */
	rotation: [number, number, number];
	scale: [number, number, number];
	/** when it shows: always, or with its level's `created` control for a row the game creates later */
	visibility: Visibility;
}

/**
 * places the models of the interactives that referenced LevelData places. each row is drawn by the first kind
 * that claims it, else as its graded doodad forms, doodad-group forms, plain model, or facility forms; each
 * kind's class says what it draws and under which control, and
 * docs/extraction/prefabs-and-interactives.md#interactives lists the steps
 *
 * @param context install readers and the bundle resolver
 * @param options.scene owning map
 * @param options.level restricts decoding to one level, or null for the map
 * @param options.partition numeric level tags
 * @param options.scripted logic ids of the interactives level scripts show and hide
 * @param options.erosionCores by logic id, the conditions a blight core's erosion root loads under
 * @param options.interactiveStates by logic id, off/on conditions for map-variable-backed `state`
 *   interactives
 * @returns placements, controls, explicit unsupported-file diagnostics and the placements of interactives
 *   whose model wasn't found (a template that's missing or can't be read, or a model id the model table
 *   lacks); no partial file is used
 * @throws {FormatError} for broken authored references or malformed supported records
 */
export const loadInteractiveFacilities = async (
	context: FacilityContext,
	{
		scene,
		level,
		partition,
		scripted,
		erosionCores,
		interactiveStates,
	}: {
		scene: string;
		level: string | null;
		partition: LevelPartition | undefined;
		scripted: ReadonlySet<string>;
		erosionCores: ReadonlyMap<string, Alternatives>;
		interactiveStates: ReadonlyMap<string, InteractiveStateGate>;
	},
): Promise<{
	models: StructureModel[];
	progressions: DraftControl[];
	/** by logic id, the controls of the rows level scripts show and hide, shown as placed */
	scriptControls: Map<string, DraftControl>;
	/** per level with rows the game creates later (`createState` ≠ 0), the control that shows them, off */
	created: DraftControl[];
	/** the control that shows limited-time event placements, off; empty when the scene has none */
	activities: DraftControl[];
	/** controls of interactives whose look follows the player's presence */
	proximityControls: DraftControl[];
	doors: InteractiveDoor[];
	bridges: DraftControl[];
	unsupported: UnsupportedFile[];
	standIns: InteractiveStandIn[];
	/** every placed row's template and position, by logic id */
	placements: Map<string, { template: string; position: Vec3 }>;
	/** resolved named places across the scene's levels */
	places: PlaceInfo[];
}> => {
	// the order below is the order models, controls and diagnostics are emitted in, which downstream ids
	// follow: keep it when adding a kind
	const [sources, prefabs] = await Promise.all([FacilitySources.open(context), PrefabHashes.open(context)]);
	const interactives = await loadInteractiveTable(sources);
	// placements first, so only the templates they use are read
	const { placed, createdControls, levelDataPaths, places } = await collectPlacements(sources, {
		scene,
		level,
		partition,
	});
	const rows = new Map(placed.map(({ row }) => [row.id, row]));
	const templates = await resolveTemplateModels(sources, interactives, placed);
	const { authored, modelless } = templates;
	await prefabs.find(authored.values().flatMap((template) => template.forms.map((form) => form.prefab)));
	const doodads = new DoodadGroups(sources, prefabs);
	await doodads.read(authored);

	const models: StructureModel[] = [];
	const progressions: DraftControl[] = [];
	const effects = new RestingEffects(sources, prefabs);
	const extras = new LevelDataExtras(sources, levelDataPaths);
	const facilities = new FacilityForms(sources, progressions);
	const platforms = new MovingPlatforms(sources, extras);
	const jumpPads = new JumpPads(effects);
	const fences = new ElectricFences(sources, prefabs, effects);
	const bridges = new TelescopicBridges(sources, prefabs);
	const doors = new InteractiveDoors(sources);
	const targetStates = new Map<string, InteractiveStateGate>(interactiveStates);
	const restLooks = new RestLooks(sources, { prefabs, progressions, doodads, rows, targetStates });
	const animatorStarts = new AnimatorStarts(sources, { prefabs, progressions, doodads });
	const regionWalls = new RegionWalls(sources);
	const cranes = new CraneTowers(sources, prefabs);
	// a row is drawn by the first of these that claims it, else as its plain model or facility forms
	const kinds: InteractiveKind[] = [bridges, doors, restLooks, animatorStarts, regionWalls, cranes];
	const readers: TemplateReader[] = [platforms, jumpPads, fences, ...kinds];
	const traits = new TemplateTraitsReader(sources, templates.traits);
	{
		for (const [key, template] of authored) {
			if (template.model === null) {
				// oxlint-disable-next-line no-await-in-loop -- one view state file and a clip per form
				await facilities.prepare(template);
				continue;
			}
			const single = { ...template, model: template.model };
			const traitsOf = traits.of(template.data);
			for (const reader of readers) {
				// oxlint-disable-next-line no-await-in-loop -- a few view state files and one-frame clips per model
				await reader.prepare(key, single, traitsOf);
			}
		}
	}
	for (const { row } of placed) {
		if (doors.handles(row.template)) {
			const control = `door:${row.id}`;
			targetStates.set(row.id.toString(), {
				off: [[{ control, mask: 1 }]],
				on: [[{ control, mask: 2 }]],
			});
		} else if (bridges.handles(row.template)) {
			const control = `bridge:${row.id}`;
			targetStates.set(row.id.toString(), {
				off: [[{ control, mask: 1 }]],
				on: [[{ control, mask: 2 }]],
			});
		}
	}
	{
		const nexus = await regionWalls.readNexus(placed);
		if (nexus !== null) {
			progressions.push(nexus);
		}
	}
	await cranes.hang(placed, authored, rows);
	const grades = new DoodadGrades(sources, prefabs);
	await grades.read(scene, placed, authored, traits);

	const switches = new RowSwitches(scripted);
	const standIns: InteractiveStandIn[] = [];
	for (const entry of placed) {
		const { path, levelId, levelTag, row } = entry;
		const gate = rowGate(switches.of(entry), erosionCores.get(row.id.toString()));
		// oxlint-disable-next-line no-await-in-loop -- splines are read once per level
		const ride = await platforms.rideOf(entry);
		// oxlint-disable-next-line no-await-in-loop -- locks are read once per level
		const locked = await extras.isLocked(levelId, row.id);
		const template = authored.get(row.template);
		if (template === undefined) {
			const reason = modelless.get(row.template);
			if (reason !== undefined) {
				standIns.push({
					source: `${path}#${row.id}`,
					template: row.template,
					reason,
					levelTag,
					position: row.position,
					rotation: row.rotation,
					scale: row.scale,
					visibility: gate({ alternatives: [[]] }),
				});
			}
			continue;
		}
		const placer = new InteractiveRow({
			prefabs,
			models,
			effects,
			placed: entry,
			template,
			gate,
			ride,
			hang: cranes.hangOf(row.id),
			locked,
		});
		jumpPads.decorate(placer);
		fences.decorate(placer);
		let claimed = false;
		for (const kind of kinds) {
			// oxlint-disable-next-line no-await-in-loop -- each kind reads once per prefab and parameter set
			if (await kind.place(placer)) {
				claimed = true;
				break;
			}
		}
		if (claimed) {
			continue;
		}
		if (template.name === null) {
			if (!grades.place(placer) && !doodads.place(placer)) {
				placer.place(template.forms[0], { alternatives: [[]] }, null);
			}
		} else {
			facilities.place(placer);
		}
	}
	await effects.place(models);
	progressions.push(...doodads.progressions(), ...grades.progressions());

	return {
		models,
		progressions,
		scriptControls: switches.scriptControls,
		created: [...createdControls.values()],
		activities: switches.activities(),
		proximityControls: restLooks.proximityControls,
		doors: doors.doors,
		bridges: bridges.controls,
		unsupported: sources.unsupported,
		standIns,
		placements: new Map(
			placed.map(({ row }) => [row.id.toString(), { template: row.template, position: row.position }]),
		),
		places,
	};
};
