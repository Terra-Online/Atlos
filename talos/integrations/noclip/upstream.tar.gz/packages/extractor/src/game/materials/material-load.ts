import { FormatError } from '@endfield-noclip/formats/binary/binary-reader';
import {
	type MaterialRecord,
	parseMaterial,
	type ShaderSummary,
} from '@endfield-noclip/formats/unity/material';
import { UnityClass } from '@endfield-noclip/formats/unity/serialized-file';

import { errorText } from '../../errors.ts';
import { loadShaderSummary } from '../assets/asset-decode.ts';
import {
	type AssetRef,
	type AssetResolver,
	locateObject,
	type ObjectLocator,
	objectKey,
	type ObjectRef,
} from '../assets/assets.ts';

import { classifyHgrpMaterial, type MaterialClassification } from './material-classify.ts';

// materials are loaded here rather than in asset-decode.ts, so the conversion worker, which imports that
// module, doesn't import their classification: changing it then keeps the mesh and texture cache

/** a material's texture slot with its texture located */
export interface ResolvedTextureSlot {
	/** the texture object, or `null` for empty slots */
	ref: ObjectRef | null;
	/** set when the PPtr couldn't be followed */
	error?: string;
}

/** a material with its shader and textures located */
export interface LoadedMaterial {
	record: MaterialRecord;
	shader: ShaderSummary;
	/** the shader object; materials of one shader share its summary */
	shaderObject: LocatedObject;
	classification: MaterialClassification;
	textures: Record<string, ResolvedTextureSlot>;
}

/** an object by key and locator, which, unlike an {@link ObjectRef}, doesn't keep its bundle loaded */
export interface LocatedObject {
	key: string;
	locator: ObjectLocator;
}

/** a {@link LoadedMaterial} with its object and textures located rather than referenced */
export interface LocatedMaterial extends Omit<LoadedMaterial, 'textures'> {
	/** the Material's {@link objectKey} */
	object: string;
	textures: Record<string, { texture: LocatedObject | null; error?: string }>;
}

/** @returns the object's key and locator */
export const locatedObject = (ref: ObjectRef): LocatedObject => ({
	key: objectKey(ref),
	locator: locateObject(ref),
});

/**
 * {@link loadMaterial} by asset, keeping nothing that holds its bundles: a pack keeps every material's load
 * until its textures are listed, and refs would hold thousands of bundles' files and blocks (gigabytes on
 * map02). the pack cache stores the result, so it must depend on nothing but the bundles read and this
 * module's code
 *
 * @param resolver asset resolver
 * @param asset the material
 * @returns the material, its shader summary, classification and located textures
 * @throws {Error} if the material or its shader can't be read
 */
export const locateMaterial = async (resolver: AssetResolver, asset: AssetRef): Promise<LocatedMaterial> => {
	const ref = await resolver.findUnique(asset, UnityClass.Material);
	const { textures, ...loaded } = await loadMaterial(resolver, ref);
	return {
		...loaded,
		object: objectKey(ref),
		textures: Object.fromEntries(
			Object.entries(textures).map(([slot, { ref: texture, error }]) => [
				slot,
				{ texture: texture === null ? null : locatedObject(texture), error },
			]),
		),
	};
};

/**
 * @param resolver asset resolver
 * @param ref a Material object
 * @returns the material, its shader summary, classification and located textures
 * @throws {Error} if the material or its shader can't be read
 */
export const loadMaterial = async (resolver: AssetResolver, ref: ObjectRef): Promise<LoadedMaterial> => {
	if (ref.info.classId !== UnityClass.Material) {
		throw new FormatError(`object ${ref.info.pathId} is class ${ref.info.classId}, not a Material`);
	}
	const record = parseMaterial(await resolver.read(ref));
	const shaderRef = await resolver.resolve(ref, record.shader);
	if (shaderRef === null) {
		throw new FormatError(`material ${record.name} has no shader`);
	}
	const shader = await loadShaderSummary(resolver, shaderRef);
	// in the material's slot order, whichever resolves first: texture ids follow it
	const textures = Object.fromEntries(
		await Promise.all(
			Object.entries(record.textures).map(
				async ([slot, { texture }]): Promise<[string, ResolvedTextureSlot]> => {
					if (texture === null) {
						return [slot, { ref: null }];
					}
					try {
						return [slot, { ref: await resolver.resolve(ref, texture) }];
					} catch (error) {
						return [slot, { ref: null, error: errorText(error) }];
					}
				},
			),
		),
	);
	return {
		record,
		shader,
		shaderObject: locatedObject(shaderRef),
		classification: classifyHgrpMaterial(record, shader),
		textures,
	};
};
