/* oxlint-disable no-await-in-loop -- walks a small subtree in authored order */
import { readClipActivity } from '@endfield-noclip/formats/unity/animation-clip';
import { UnityClass } from '@endfield-noclip/formats/unity/serialized-file';
import { hasTypeFields, type TypeTreeObject } from '@endfield-noclip/formats/unity/type-tree';
import {
	arrayField,
	asPPtr,
	isObject,
	numberField,
	objectField,
	objectsField,
	pptrField,
} from '@endfield-noclip/formats/unity/values';

import { objectKey, type AssetResolver, type ObjectRef } from '../assets/assets.ts';
import { PRUNE, walkPrefab } from '../prefabs/prefab-walk.ts';

// effects a prefab's view states never show at rest: docs/game-data/effects.md#one-shot-effects

/**
 * @param resolver bundle reader
 * @param animator an Animator component
 * @param data its fields
 * @returns binding paths (CRC32 of the path below the Animator) of the GameObjects its controller's clips
 *   switch but never show: every clip that animates their activity starts and ends with them off. empty for a
 *   disabled Animator or a controller other than a plain AnimatorController
 */
export const animatorHiddenNodes = async (
	resolver: AssetResolver,
	animator: ObjectRef,
	data: TypeTreeObject,
): Promise<Set<number>> => {
	const hidden = new Set<number>();
	if (numberField(data, 'm_Enabled') === 0) {
		return hidden;
	}
	const controller = await resolver.resolve(animator, pptrField(data, 'm_Controller'));
	if (controller === null || controller.info.classId !== UnityClass.AnimatorController) {
		return hidden;
	}
	const shown = new Set<number>();
	for (const pointer of arrayField(await resolver.read(controller), 'm_AnimationClips')) {
		const clip = await resolver.resolve(controller, asPPtr(pointer));
		if (clip === null) {
			continue;
		}
		for (const [path, on] of readClipActivity(await resolver.read(clip))) {
			(on ? shown : hidden).add(path);
		}
	}
	for (const path of shown) {
		hidden.delete(path);
	}
	return hidden;
};

/**
 * @param ref a MonoBehaviour
 * @returns whether it's a prefab's own view-state controller (`PostModelViewStateController` and its kin)
 */
export const isViewStateControllerType = (ref: ObjectRef): boolean =>
	hasTypeFields(ref.info.type, 'stateList', 'animatorNode');

/**
 * @param resolver bundle reader
 * @param controller the controller component (see {@link isViewStateControllerType})
 * @param data its fields
 * @returns keys of the GameObjects its states switch on to play an effect
 */
export const playedEffectNodes = async (
	resolver: AssetResolver,
	controller: ObjectRef,
	data: TypeTreeObject,
): Promise<Set<string>> => {
	const nodes = new Set<string>();
	for (const state of objectsField(data, 'stateList')) {
		for (const config of objectsField(state, 'effectPlayConfigs')) {
			if (numberField(config, 'controlActive') === 0) {
				continue;
			}
			const node = await resolver.resolve(controller, pptrField(config, 'effectNode'));
			if (node !== null) {
				nodes.add(objectKey(node));
			}
		}
	}
	return nodes;
};

/**
 * @param ref a MonoBehaviour
 * @returns whether it's an `EffectSetting`
 */
export const isEffectSettingType = (ref: ObjectRef): boolean =>
	hasTypeFields(ref.info.type, 'effectLogicCfg');

/**
 * @param resolver bundle reader
 * @param setting an `EffectSetting` (see {@link isEffectSettingType})
 * @param data its fields
 * @returns keys of the GameObjects its LOD table switches. the table keeps each one off when it was saved off
 *   (docs/game-data/effects.md#effect-lod-tables), so those never show. empty when the setting is disabled
 */
export const effectLodNodes = async (
	resolver: AssetResolver,
	setting: ObjectRef,
	data: TypeTreeObject,
): Promise<Set<string>> => {
	const nodes = new Set<string>();
	if (numberField(data, 'm_Enabled') === 0) {
		return nodes;
	}
	for (const entry of objectsField(data, 'lodSetting')) {
		const node = await resolver.resolve(setting, pptrField(entry, 'gameobject'));
		if (node !== null) {
			nodes.add(objectKey(node));
		}
	}
	return nodes;
};

/** camera distances `near < d ≤ far`, in metres */
export interface DistanceRange {
	near: number;
	far: number;
}

/**
 * @param a ranges, ascending and disjoint
 * @param b likewise
 * @returns the distances in both, ascending and disjoint
 */
export const intersectRanges = (
	a: readonly DistanceRange[],
	b: readonly DistanceRange[],
): DistanceRange[] => {
	const out: DistanceRange[] = [];
	for (const x of a) {
		for (const y of b) {
			const near = Math.max(x.near, y.near);
			const far = Math.min(x.far, y.far);
			if (near < far) {
				out.push({ near, far });
			}
		}
	}
	out.sort((p, q) => p.near - q.near);
	return out;
};

/** an `EffectSetting`'s distance LOD: where the camera has to be for the GameObjects it switches to show */
export interface EffectDistanceLod {
	/** where the setting's own GameObject is on: everywhere, or within the cull distance */
	self: DistanceRange[];
	/** by GameObject key, the distances its LOD entries leave it on at */
	nodes: Map<string, DistanceRange[]>;
}

/**
 * @param resolver bundle reader
 * @param setting an `EffectSetting` (see {@link isEffectSettingType})
 * @param data its fields
 * @returns the distances its GameObjects show at (docs/game-data/effects.md#effect-lod-tables), or `null`
 *   when the setting is disabled or doesn't switch by distance
 * @throws {FormatError} on a malformed LOD entry or distance band
 */
export const effectDistanceLod = async (
	resolver: AssetResolver,
	setting: ObjectRef,
	data: TypeTreeObject,
): Promise<EffectDistanceLod | null> => {
	if (numberField(data, 'm_Enabled') === 0 || numberField(data, 'isUseDistanceLod') === 0) {
		return null;
	}
	const distances = objectsField(data, 'distanceLodCfgList').map((band) => numberField(band, 'distance'));
	if (distances.length === 0) {
		return null;
	}
	// the game picks the last band past whose distance the camera is, or the first; so a band runs from its
	// own distance to the nearest distance of a later band
	const bands = distances.map((distance, i): DistanceRange => {
		const later = distances.slice(i + 1);
		return { near: i === 0 ? 0 : distance, far: Math.min(Infinity, ...later) };
	});
	const nodes = new Map<string, DistanceRange[]>();
	for (const [node, active] of await lodEntryBands(resolver, setting, data, bands.length)) {
		const on: DistanceRange[] = [];
		for (const [i, band] of bands.entries()) {
			if (!active[i] || band.near >= band.far) {
				continue;
			}
			const previous = on.at(-1);
			if (previous?.far === band.near) {
				previous.far = band.far;
			} else {
				on.push({ ...band });
			}
		}
		nodes.set(node, on);
	}
	// past the cull distance the game switches the whole effect off, when `_isCullDisable` asks it to
	const cull = numberField(data, '_isCullDisable') !== 0 ? numberField(data, 'cullDis') : Infinity;
	return { self: [{ near: 0, far: cull }], nodes };
};

/** the LOD levels a dynamic scene's LOD proxy sets: its near grid loaded, only its far grid, or neither */
export const PROXY_LEVELS = 3;

/**
 * a dynamic scene's effect row shows the band its LOD proxy's level names, never by the camera's distance or
 * past a cull distance (docs/game-data/effects.md#effect-lod-tables)
 *
 * @param resolver bundle reader
 * @param setting the `EffectSetting` on the prefab's root (see {@link isEffectSettingType})
 * @param data its fields
 * @returns by GameObject key its LOD entries list, a mask of the proxy levels (bit `i` for level `i`) it's on
 *   at; `null` when the setting has no bands, so its table is never applied
 * @throws {FormatError} on a malformed LOD entry
 */
export const effectProxyBands = async (
	resolver: AssetResolver,
	setting: ObjectRef,
	data: TypeTreeObject,
): Promise<Map<string, number> | null> => {
	const count = arrayField(data, 'distanceLodCfgList').length;
	if (count === 0) {
		return null;
	}
	const nodes = new Map<string, number>();
	for (const [node, active] of await lodEntryBands(resolver, setting, data, count)) {
		let mask = 0;
		for (let level = 0; level < PROXY_LEVELS; level++) {
			// a level past the last band leaves the table as it was, which coming from nearer is the last band
			if (active[Math.min(level, count - 1)]) {
				mask |= 1 << level;
			}
		}
		nodes.set(node, mask);
	}
	return nodes;
};

/**
 * @returns by GameObject key an `EffectSetting`'s LOD entries list, whether its entries leave it on in each
 *   of `count` bands; a GameObject several entries list is on where all of them are
 * @throws {FormatError} on a malformed LOD entry
 */
const lodEntryBands = async (
	resolver: AssetResolver,
	setting: ObjectRef,
	data: TypeTreeObject,
	count: number,
): Promise<Map<string, boolean[]>> => {
	const nodes = new Map<string, boolean[]>();
	for (const entry of objectsField(data, 'lodSetting')) {
		const node = await resolver.resolve(setting, pptrField(entry, 'gameobject'));
		if (node === null) {
			continue;
		}
		const infos = arrayField(entry, '_distanceLodInfos');
		const active = Array.from({ length: count }, (_, i) => {
			const info = infos[i];
			// a band the entry has no info for is assumed on (what the game fills in is unchecked)
			return info === undefined || (isObject(info) && numberField(info, 'isActive') !== 0);
		});
		const known = nodes.get(objectKey(node));
		nodes.set(objectKey(node), known === undefined ? active : known.map((on, i) => on && active[i]));
	}
	return nodes;
};

/**
 * @param resolver bundle reader
 * @param go a GameObject
 * @returns whether its subtree is effects that don't loop: it has `EffectSetting`s and none loops
 */
export const isOneShotEffect = async (resolver: AssetResolver, go: ObjectRef): Promise<boolean> => {
	let settings = 0;
	let loops = false;
	await walkPrefab(
		resolver,
		go,
		{
			enter: async (node) => {
				// one looping setting settles it, so the rest of the subtree isn't read
				if (loops) {
					return PRUNE;
				}
				for (const setting of node.behaviours(isEffectSettingType)) {
					settings++;
					if (numberField(objectField(await setting.read(), 'effectLogicCfg'), 'isLoop') !== 0) {
						loops = true;
						return PRUNE;
					}
				}
				return undefined;
			},
		},
		undefined,
	);
	return !loops && settings > 0;
};
