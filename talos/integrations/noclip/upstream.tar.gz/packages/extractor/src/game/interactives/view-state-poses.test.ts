import assert from 'node:assert/strict';
import { test } from 'node:test';

import { ROOT_EMISSIVE } from '../prefabs/emissive-override.ts';

import {
	restingEffects,
	restingEmissives,
	restingLengths,
	settledPath,
	stateSwitches,
	testedValues,
	type ViewStateRecord,
} from './view-state-poses.ts';

const effect = (
	effectId: string,
	flags: { persistent?: boolean; active?: boolean; fireAndForget?: boolean; node?: string } = {},
): ViewStateRecord => ({
	$type: 'Beyond_Gameplay_Core_ModelViewStateController_MVSCEffectBehaviorDataForMemoryPack',
	effectId,
	effectNodeName: flags.node ?? '',
	isPersistence: flags.persistent ?? false,
	active: flags.active ?? false,
	fireAndForget: flags.fireAndForget ?? false,
	followRot: true,
	dontFollowTrans: false,
});

const state = (stateName: string, behaviors: ViewStateRecord[], to: string | null): ViewStateRecord => ({
	stateName,
	behaviors,
	transitions: to === null ? [] : [{ targetStateName: to, conditionGroup: { conditions: [], logic: 0 } }],
});

test("the jump pad's effect layer rests in On, which keeps its glow playing", () => {
	// int_jumpmachine's EffectLayer: Off → On while `state` is 1
	const layer = {
		layerName: 'EffectLayer',
		stateDatas: [
			{
				...state('Off', [], null),
				isStartingNode: true,
				transitions: [
					{
						targetStateName: 'On',
						conditionGroup: {
							conditions: [
								{
									key: 'state',
									comparison: 0,
									isInvert: false,
									conditionValue: { type: 2, conditionValue: { intValue: 1 } },
								},
							],
						},
					},
				],
			},
			state('On', [effect('P_common_bouncingplatform_01')], null),
		],
	};
	const path = settledPath(layer, new Map([['state', 1]]));
	assert.deepEqual(
		path.map((entry) => entry.stateName),
		['Off', 'On'],
	);
	assert.deepEqual(restingEffects('P_interactive_zmdspring+1_001', path), [
		{
			effect: 'P_common_bouncingplatform_01',
			node: null,
			fallback: 'P_interactive_zmdspring+1_001',
			followRotation: true,
		},
	]);
	assert.deepEqual(restingEffects(null, settledPath(layer, new Map())), []);
});

test('a persistent effect stays on until a later state switches it off; others end with their state', () => {
	const path = [
		state('a', [effect('burst'), effect('kept', { persistent: true, active: true })], 'b'),
		state('b', [effect('glow', { persistent: true, active: true, node: 'Point' })], 'c'),
		state(
			'c',
			[
				effect('glow', { persistent: true, active: false, node: 'Point' }),
				effect('spark', { fireAndForget: true }),
			],
			null,
		),
	];
	assert.deepEqual(
		restingEffects(null, path).map((rest) => rest.effect),
		['kept'],
	);
});

const setActive = (gameObjName: string, active: boolean): ViewStateRecord => ({
	$type: 'Beyond_Gameplay_Core_ModelViewStateController_MVSCSetActiveBehaviorDataForMemoryPack',
	gameObjName,
	active,
});

test("an empty SetActive name switches the animator's own GameObject", () => {
	// int_monster_heart_postmodel's HeartSwitch layer on the root animator: Dis hides the heart, Finsh shows it
	const dis = state('Dis', [setActive('', false)], null);
	const finsh = state('Finsh', [setActive('P_iprop_map02_jade+1_001_01b', false), setActive('', true)], null);
	assert.deepEqual(stateSwitches([{ animator: null, states: [dis] }]), {
		active: new Map(),
		rootActive: false,
	});
	assert.deepEqual(stateSwitches([{ animator: null, states: [finsh] }]), {
		active: new Map([['P_iprop_map02_jade+1_001_01b', false]]),
		rootActive: true,
	});
	// on a named animator (dyn_big_wheel_postmodel's TempRoot), it switches that GameObject
	assert.deepEqual(
		stateSwitches([{ animator: 'TempRoot', states: [state('Playing', [setActive('', true)], null)] }]),
		{ active: new Map([['TempRoot', true]]), rootActive: true },
	);
});

const length = (
	nodeName: string,
	fields: { key?: string; val?: number; deviation: number },
): ViewStateRecord => ({
	$type: 'Beyond_Gameplay_Core_ModelViewStateController_MVSCEffectLengthBehaviorDataForMemoryPack',
	nodeName,
	dependBlackBoard: fields.key !== undefined,
	dependFloatKey: fields.key ?? '',
	val: fields.val ?? 0,
	deviation: fields.deviation,
});

test("the rope lift's length outlasts set_rope, from RopeLength plus its deviation", () => {
	// int_rope_port_topright_postmodel: start → set_rope → on_idle while `state` > 0
	const rope = 'P_iprop_com_rope+1_001_02';
	const path = [
		state('start', [], 'set_rope'),
		state('set_rope', [length(rope, { key: 'RopeLength', deviation: 1.4 })], 'on_idle'),
		state('on_idle', [], null),
	];
	assert.deepEqual([...restingLengths(path, new Map([['RopeLength', 7]]))], [[rope, 8.4]]);
	// without the float, nothing is set
	assert.deepEqual([...restingLengths(path, new Map())], []);
	// a constant length is its value plus the deviation
	assert.deepEqual(
		[...restingLengths([state('s', [length(rope, { val: 2, deviation: 0.5 })], null)], new Map())],
		[[rope, 2.5]],
	);
});

const emissive = (emissiveNodeName: string, emissiveConfigHash: bigint): ViewStateRecord => ({
	$type: 'Beyond_Gameplay_Core_ModelViewStateController_MVSCEmissiveBehaviorDataForMemoryPack',
	emissiveNodeName,
	// longs decode as decimal strings
	emissiveConfigHash: String(emissiveConfigHash),
	isBlend: false,
	blendTime: 0,
});

test('a locked hydrant keeps the disabled emissive config its starting state applied', () => {
	// int_xiranite_hydrant_postmodel's BaseLayer at `state` 0: Idle → broken → locked_Idle; Idle applies
	// IntEmissiveConfig_Disabled_Wuling, the working states IntEmissiveConfig_On_Wuling
	const pillar = 'P_igroup_map02_pool+1_003_02';
	const disabled = 45_509_677_811_683_174n;
	const on = 367_726_622_296_899_561n;
	const locked = [
		state('Idle', [emissive(pillar, disabled)], 'broken'),
		state('broken', [setActive('fixed', false)], 'locked_Idle'),
		state('locked_Idle', [effect('P_fxint_l_hydrantbase_xirang_lowlight_801')], null),
	];
	assert.deepEqual([...restingEmissives(null, locked)], [[pillar, disabled]]);
	const working = [
		state('Idle', [emissive(pillar, disabled)], 'working'),
		state('working', [emissive(pillar, on)], null),
	];
	assert.deepEqual([...restingEmissives(null, working)], [[pillar, on]]);
});

test("an empty emissive name means the animator's own GameObject", () => {
	// int_water_hydrant_postmodel's root layer starts in `off`, which applies a config without a name
	const off = [state('off', [emissive('', 45_509_677_811_683_174n)], null)];
	assert.deepEqual([...restingEmissives(null, off)], [[ROOT_EMISSIVE, 45_509_677_811_683_174n]]);
	assert.deepEqual([...restingEmissives('TempRoot', off)], [['TempRoot', 45_509_677_811_683_174n]]);
});

test('the values a state machine tests on an int key are listed once, ascending', () => {
	const condition = (key: string, type: number, value: number): ViewStateRecord => ({
		key,
		comparison: 0,
		conditionValue: { type, conditionValue: { intValue: value, floatValue: value } },
	});
	const go = (...conditions: ViewStateRecord[]): ViewStateRecord => ({
		targetStateName: 'x',
		conditionGroup: { conditions },
	});
	// a Wuling bridge's off and on, a float on another key, and an extra test of 1
	const states = {
		model: 'int_bridge_wuling_12m_postmodel',
		path: 'test',
		data: {
			modelAnimatorDatas: [
				{
					layerFsmDatas: [
						{
							stateDatas: [
								{ stateName: 'off', transitions: [go(condition('state', 2, 1))] },
								{
									stateName: 'on',
									transitions: [go(condition('state', 2, 0)), go(condition('speed', 1, 3))],
								},
								{ stateName: 'again', transitions: [go(condition('state', 2, 1))] },
							],
						},
					],
				},
			],
		},
	};
	assert.deepEqual(testedValues(states, 'state'), [0, 1]);
	assert.deepEqual(testedValues(states, 'speed'), []);
});
