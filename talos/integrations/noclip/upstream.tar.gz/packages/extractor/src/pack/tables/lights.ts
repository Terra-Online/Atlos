import { type ChunkLight, LightType } from '@endfield-noclip/formats/endfield/chunk-lights';
import { unityEulerQuaternion } from '@endfield-noclip/formats/unity/transform';
import { type LightEntry, LightKind, type LightsTable } from '@endfield-noclip/package-format/lights';

import type { Visibility } from '../../game/state/scene-control.ts';
import type { ChunkSource } from '../../game/world/world-index.ts';

// local lights for `tables/lights.json`. lights repeat in every cell chunk they overlap, in scene states and in
// stream areas, so they're deduplicated by id and load with the files holding them, like instances. lights in
// dynamic structures load with their structure instead.

/** collects a scene's lights across its chunk files */
export class LightCollector {
	readonly #lights = new Map<number, { light: ChunkLight; sources: ChunkSource[] }>();
	readonly #conditional = new Map<number, { light: ChunkLight; visibility: Visibility }>();
	/** lights left out, by reason */
	readonly skipped: Record<string, number> = {};

	/**
	 * @param light a light from a chunk file
	 * @param source the file's scene state and stream area
	 */
	add(light: ChunkLight, source: ChunkSource): void {
		const { sceneState, area } = source;
		const known = this.#lights.get(light.id);
		if (known === undefined) {
			this.#lights.set(light.id, { light, sources: [{ sceneState, area }] });
		} else {
			known.sources.push({ sceneState, area });
		}
	}

	/**
	 * adds a light that loads with a dynamic structure. lights the chunk files also hold keep their files'
	 * gating, like the structures' renderers
	 *
	 * @param light a light from a dynamic structure's ECS group
	 * @param visibility its structure's visibility
	 */
	addConditional(light: ChunkLight, visibility: Visibility): void {
		if (this.#lights.has(light.id)) {
			return;
		}
		const known = this.#conditional.get(light.id);
		if (known === undefined) {
			this.#conditional.set(light.id, { light, visibility: { alternatives: [...visibility.alternatives] } });
		} else {
			known.visibility.alternatives.push(...visibility.alternatives);
		}
	}

	/**
	 * @param groupOf the visibility group of content a level owns that loads with any of these files
	 * @param groupOfVisibility the visibility group of content a level owns under this visibility
	 * @returns the table, lights in id order
	 */
	finish(
		groupOf: (levelTag: number, sources: readonly ChunkSource[]) => number,
		groupOfVisibility: (levelTag: number, visibility: Visibility) => number,
	): LightsTable {
		const entries: { light: ChunkLight; group: () => number }[] = [];
		for (const { light, sources } of this.#lights.values()) {
			entries.push({ light, group: () => groupOf(light.levelTag, sources) });
		}
		for (const [id, { light, visibility }] of this.#conditional) {
			if (!this.#lights.has(id)) {
				entries.push({ light, group: () => groupOfVisibility(light.levelTag, visibility) });
			}
		}
		const lights: LightEntry[] = [];
		entries.sort((a, b) => a.light.id - b.light.id);
		for (const { light, group } of entries) {
			const reason = skipReason(light);
			if (reason !== null) {
				this.skipped[reason] = (this.skipped[reason] ?? 0) + 1;
				continue;
			}
			lights.push(lightEntry(light, group()));
		}
		return { lights };
	}
}

/** @returns why the viewer has no use for a light, or `null` */
const skipReason = (light: ChunkLight): string | null => {
	if (light.type !== LightType.Spot && light.type !== LightType.Point) {
		return `type ${light.type}`;
	}
	if (light.shadowOnly) {
		// they only darken other local lights through their shadow maps, which aren't drawn
		return 'shadow only';
	}
	if (light.characterOnly) {
		return 'character only';
	}
	if (!(light.range > 0)) {
		return 'no range';
	}
	return null;
};

/**
 * @param light a spot or point light
 * @param group its visibility group
 * @returns its table entry
 */
export const lightEntry = (light: ChunkLight, group: number): LightEntry => {
	const spot = light.type === LightType.Spot;
	const box = light.cullingBox;
	return {
		kind: spot ? LightKind.Spot : LightKind.Point,
		entityId: light.id,
		group,
		position: light.position,
		direction: light.direction,
		color: light.color,
		range: light.range,
		spotAngle: spot ? light.spotAngle : 0,
		innerSpotAngle: spot ? light.innerSpotAngle : 0,
		// a spot's own length field means nothing to the shading
		tubeLength: spot ? 0 : light.tubeLength,
		softSourceRadius: light.softSourceRadius,
		falloffExponent: light.falloffExponent,
		specularIntensity: light.specularIntensity,
		volumetricScatteringIntensity: light.volumetricScatteringIntensity,
		priority: light.priority,
		distanceFade: light.distanceFade,
		cullingBox:
			box === null
				? null
				: {
						matrix: inverseBox(box.offset, box.rotation, box.halfExtents),
						falloffThreshold: box.falloffThreshold,
					},
	};
};

/** @returns rows3x4 of the inverse of `TRS(offset, Euler(rotation), halfExtents)`: `S⁻¹ Rᵀ (v − offset)` */
const inverseBox = (
	offset: readonly number[],
	rotation: readonly number[],
	halfExtents: readonly number[],
): number[] => {
	const [x, y, z, w] = unityEulerQuaternion(rotation);
	// the rotation's columns, i.e. the box's axes in world space
	const axes = [
		[1 - 2 * (y * y + z * z), 2 * (x * y + z * w), 2 * (x * z - y * w)],
		[2 * (x * y - z * w), 1 - 2 * (x * x + z * z), 2 * (y * z + x * w)],
		[2 * (x * z + y * w), 2 * (y * z - x * w), 1 - 2 * (x * x + y * y)],
	];
	const rows: number[] = [];
	for (const [i, axis] of axes.entries()) {
		// a degenerate box confines the light to nothing; a huge scale keeps the matrix finite
		const inverse = halfExtents[i] > 0 ? 1 / halfExtents[i] : 1e6;
		const dot = axis[0] * offset[0] + axis[1] * offset[1] + axis[2] * offset[2];
		rows.push(axis[0] * inverse, axis[1] * inverse, axis[2] * inverse, -dot * inverse);
	}
	return rows;
};
