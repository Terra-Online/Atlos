import type { Context } from '../context.ts';
import type { SceneEnvironmentVolume } from '../game/environment.ts';

import {
	collectPlacedVolumes,
	collectPlacementSources,
	type ScenePlacementSources,
} from './content/entities.ts';
import { PackContent } from './content/pack-content.ts';
import { indexScene, type SceneIndex } from './scene-index.ts';
import { progressionControls } from './states.ts';

// the entities phase's placement sources run on their own, without the chunk files or prefab renderers, so
// the inspection commands see the placements, gating and volumes a package of the scene holds

/** a whole scene's placements, as the packer finds them */
export interface ScenePlacementSurvey extends ScenePlacementSources {
	scene: SceneIndex;
	/** the content the sources wrote; its stand-ins and unsupported inputs are the package's */
	content: PackContent;
}

/**
 * @param context install readers
 * @param scene streaming scene id
 * @param level optional LevelConfig id to restrict interactive placement decoding to one level
 * @param options.includeEcs whether to decode dynamic ECS entity/light chunks (default `true`)
 * @returns every placement source of the scene (or level)
 * @throws {Error} what the packer's setup and placement sources throw
 */
export const surveyPlacements = async (
	context: Context,
	scene: string,
	level: string | null = null,
	options?: { includeEcs?: boolean },
): Promise<ScenePlacementSurvey> => {
	const index = await indexScene(context, { scene, level, bounds: null }, { terrain: false, hlod: false });
	const content = await PackContent.create(context.world, index, () => {});
	return { scene: index, content, ...(await collectPlacementSources(context, content, options)) };
};

/**
 * @param context install readers
 * @param survey the scene's placements
 * @returns the environment volumes its placed prefabs carry, with whether each loads by default
 */
export const surveyPlacedVolumes = async (
	context: Context,
	survey: ScenePlacementSurvey,
): Promise<SceneEnvironmentVolume[]> =>
	collectPlacedVolumes(
		survey.roots,
		survey.content,
		survey.placements,
		await progressionControls(context.world, survey.scene.id),
	);
