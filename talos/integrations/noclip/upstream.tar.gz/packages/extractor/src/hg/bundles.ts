import { promisify } from 'node:util';
import { brotliDecompress, brotliDecompressSync } from 'node:zlib';

import { type BundleNode, type ByteSource, UnityBundle } from '@endfield-noclip/formats/hg/bundle';
import { deriveBundlePad } from '@endfield-noclip/formats/hg/bundle-cipher';
import { BundleManifest } from '@endfield-noclip/formats/hg/bundle-manifest';
import {
	getObjectInfo,
	type ObjectInfo,
	parseSerializedFile,
	parseSerializedFileHeader,
	SERIALIZED_FILE_HEADER_SIZE,
	type SerializedFile,
	serializedFileMetadataEnd,
	UnityClass,
} from '@endfield-noclip/formats/unity/serialized-file';
import {
	objectBytes,
	peekObjectName,
	readObject,
	type TypeTreeObject,
} from '@endfield-noclip/formats/unity/type-tree';
import {
	arrayField,
	asPPtr,
	isObject,
	mapEntries,
	numberField,
	type PPtr,
} from '@endfield-noclip/formats/unity/values';

import { groupByDefined } from '@mary-ext/array-fns';

import type { Keys } from '../config.ts';

import { type Vfs, type VfsFile, VfsGroup } from './vfs.ts';

/** logical directory of the Bundle group */
export const BUNDLE_PREFIX = 'Data/Bundles/Windows/';

/** the bundle manifest's logical path, in {@link VfsGroup.BundleManifest} */
const MANIFEST_PATH = 'Data/Bundles/Windows/manifest.hgmmap';

const brotliDecompressAsync = promisify(brotliDecompress);

const MANIFEST_OPTIONS = { brotliDecompress: (data: Uint8Array) => brotliDecompressSync(data) };

/**
 * @param vfs the VFS
 * @returns the parsed bundle manifest, its {@link BundleManifest.bytes} backed by a `SharedArrayBuffer` so
 *   worker threads can read it through {@link sharedBundleManifest} without a copy of their own
 * @throws {Error} if it's missing or its md5 doesn't match the catalog
 */
export const loadBundleManifest = async (vfs: Vfs): Promise<BundleManifest> => {
	const file = await vfs.find(VfsGroup.BundleManifest, MANIFEST_PATH);
	if (file === undefined) {
		throw new Error(`${MANIFEST_PATH} not found in vfs group ${VfsGroup.BundleManifest}`);
	}
	// ~150 MB decompressed; the async form keeps the event loop free for the reads setup runs alongside
	const decompressed = await brotliDecompressAsync(await vfs.readVerified(file));
	const bytes = new Uint8Array(new SharedArrayBuffer(decompressed.length));
	bytes.set(decompressed);
	return new BundleManifest(bytes, MANIFEST_OPTIONS);
};

/**
 * @param bytes {@link BundleManifest.bytes} of a manifest from {@link loadBundleManifest}, e.g. passed to a
 *   worker
 * @returns a reader over the same bytes
 */
export const sharedBundleManifest = (bytes: Uint8Array): BundleManifest => {
	return new BundleManifest(bytes, MANIFEST_OPTIONS);
};

/**
 * normalizes the ways a bundle gets named into its logical VFS path
 *
 * @param name `Data/Bundles/Windows/main/<hex>.ab`, `main/<hex>.ab` (the manifest's form) or a bare `<hex>`
 * @returns the logical path in the Bundle group
 */
export const bundlePath = (name: string): string => {
	if (name.startsWith(BUNDLE_PREFIX)) {
		return name;
	}
	if (/^[0-9a-f]+$/i.test(name)) {
		return `${BUNDLE_PREFIX}main/${name.toLowerCase()}.ab`;
	}
	return `${BUNDLE_PREFIX}${name}`;
};

/**
 * @param path an archive path such as `archive:/CAB-<hex>/CAB-<hex>.resS`
 * @returns the file name, e.g. `CAB-<hex>.resS`
 */
export const archiveFileName = (path: string): string => path.slice(path.lastIndexOf('/') + 1);

const pads = new WeakMap<Keys['bundle'], Uint8Array>();

/** @returns the bundle cipher pad, derived once per key set */
const bundlePad = (keys: Keys): Uint8Array => {
	return pads.getOrInsertComputed(keys.bundle, deriveBundlePad);
};

/** @returns a range-reading {@link ByteSource} over a logical file */
const vfsSource = (vfs: Vfs, file: VfsFile): ByteSource => {
	return {
		size: file.entry.length,
		read: (start, end) => vfs.read(file, start, end),
	};
};

/**
 * locates a bundle's logical file
 *
 * @param vfs the VFS
 * @param name any form accepted by {@link bundlePath}
 * @returns the file; its catalog entry carries the bundle's md5
 * @throws {Error} if the bundle isn't in the catalog
 */
export const findBundleFile = async (vfs: Vfs, name: string): Promise<VfsFile> => {
	const path = bundlePath(name);
	// `initial/` bundles ship in their own group
	const file =
		(await vfs.find(VfsGroup.Bundle, path)) ??
		(path.startsWith(`${BUNDLE_PREFIX}initial/`) ? await vfs.find(VfsGroup.InitialBundle, path) : undefined);
	if (file === undefined) {
		throw new Error(`bundle ${path} not found in groups ${VfsGroup.Bundle}/${VfsGroup.InitialBundle}`);
	}
	return file;
};

/**
 * opens a bundle from the Bundle group without reading it whole
 *
 * @param context VFS and keys
 * @param name any form accepted by {@link bundlePath}
 * @throws {Error} if the bundle isn't in the catalog
 */
export const openBundle = async (context: { vfs: Vfs; keys: Keys }, name: string): Promise<UnityBundle> => {
	const file = await findBundleFile(context.vfs, name);
	return UnityBundle.open(vfsSource(context.vfs, file), bundlePad(context.keys));
};

/** SerializedFiles up to this size are read whole; larger ones read objects on demand */
const EAGER_SERIALIZED_FILE_SIZE = 16 * 1024 * 1024;

/** bytes read from the start of an object to find its `m_Name` in a lazily read file */
const NAME_PREFIX_SIZE = 4096;

/** a `m_Container` entry: an asset path and the object it names */
export interface ContainerEntry {
	path: string;
	asset: PPtr;
	/** references in this container entry's preload range */
	preloads: PPtr[];
}

/** an AssetBundle object's name and container */
export interface AssetBundleObject {
	/** the owning AssetBundle object; pointers are relative to its SerializedFile */
	info: ObjectInfo;
	name: string | undefined;
	container: ContainerEntry[];
}

/** a SerializedFile inside a bundle, with object access by path id */
export class BundleAssetFile {
	readonly bundle: UnityBundle;
	readonly node: BundleNode;
	readonly file: SerializedFile;
	readonly #bytes: Uint8Array | undefined;
	/** per class id: lowercase `m_Name` → objects */
	readonly #names = new Map<number, Promise<Map<string, ObjectInfo[]>>>();

	/**
	 * @param bundle containing bundle
	 * @param node the SerializedFile's node
	 * @param file parsed metadata
	 * @param bytes the whole file, if it was read eagerly
	 */
	constructor(bundle: UnityBundle, node: BundleNode, file: SerializedFile, bytes: Uint8Array | undefined) {
		this.bundle = bundle;
		this.node = node;
		this.file = file;
		this.#bytes = bytes;
	}

	/**
	 * reads the metadata, and the whole file too if it's small
	 *
	 * @param bundle containing bundle
	 * @param node a node flagged as a SerializedFile
	 */
	static async open(bundle: UnityBundle, node: BundleNode): Promise<BundleAssetFile> {
		if (node.size <= EAGER_SERIALIZED_FILE_SIZE) {
			const bytes = await bundle.readNode(node);
			return new BundleAssetFile(bundle, node, parseSerializedFile(bytes), bytes);
		}
		const header = parseSerializedFileHeader(
			await bundle.readNodeRange(node, 0, SERIALIZED_FILE_HEADER_SIZE),
		);
		const prefix = await bundle.readNodeRange(node, 0, serializedFileMetadataEnd(header));
		return new BundleAssetFile(bundle, node, parseSerializedFile(prefix), undefined);
	}

	/** @returns the raw bytes of one object */
	async objectBytes(info: ObjectInfo): Promise<Uint8Array> {
		if (this.#bytes !== undefined) {
			return objectBytes(this.#bytes, info);
		}
		return this.bundle.readNodeRange(this.node, info.byteStart, info.byteStart + info.byteSize);
	}

	/**
	 * @param target object path id or table entry
	 * @returns the object's fields
	 * @throws {FormatError} if there's no such object or it doesn't match its TypeTree
	 */
	async read(target: bigint | ObjectInfo): Promise<TypeTreeObject> {
		const info = typeof target === 'bigint' ? getObjectInfo(this.file, target) : target;
		return readObject(this.file, info, await this.objectBytes(info));
	}

	/** @returns the object's `m_Name`, or `undefined` if its class has none */
	async peekName(info: ObjectInfo): Promise<string | undefined> {
		if (this.#bytes !== undefined || info.byteSize <= NAME_PREFIX_SIZE) {
			return peekObjectName(this.file, info, await this.objectBytes(info));
		}
		// `m_Name` sits near the start of every class that has one; read the rest only if it doesn't fit
		const prefix = await this.bundle.readNodeRange(
			this.node,
			info.byteStart,
			info.byteStart + NAME_PREFIX_SIZE,
		);
		try {
			return peekObjectName(this.file, info, prefix);
		} catch {
			return peekObjectName(this.file, info, await this.objectBytes(info));
		}
	}

	/**
	 * finds objects by name; the first call per class reads every name of that class
	 *
	 * @param classId class of the objects
	 * @param name `m_Name`, lowercase
	 * @returns the objects of that class whose lowercased name is `name`
	 */
	async objectsNamed(classId: number, name: string): Promise<ObjectInfo[]> {
		const index = this.#names.getOrInsertComputed(classId, async () => {
			const objects = this.file.objects.filter((info) => info.classId === classId);
			const names = await Promise.all(objects.map((info) => this.peekName(info)));
			return groupByDefined(objects, (_info, i) => names[i]?.toLowerCase());
		});
		return (await index).get(name) ?? [];
	}

	/** @returns every AssetBundle object of the file with its `m_Container` */
	async assetBundles(): Promise<AssetBundleObject[]> {
		const bundles: AssetBundleObject[] = [];
		for (const info of this.file.objects) {
			if (info.classId !== UnityClass.AssetBundle) {
				continue;
			}
			// oxlint-disable-next-line no-await-in-loop -- a file holds at most one AssetBundle in practice
			const value = await this.read(info);
			const preloads = arrayField(value, 'm_PreloadTable').map(asPPtr);
			const container: ContainerEntry[] = [];
			for (const [path, entry] of mapEntries(value.m_Container)) {
				if (typeof path === 'string' && isObject(entry)) {
					const start = numberField(entry, 'preloadIndex');
					const size = numberField(entry, 'preloadSize');
					if (
						!Number.isInteger(start) ||
						!Number.isInteger(size) ||
						start < 0 ||
						size < 0 ||
						start + size > preloads.length
					) {
						throw new Error(`invalid preload range for ${path}`);
					}
					container.push({ path, asset: asPPtr(entry.asset), preloads: preloads.slice(start, start + size) });
				}
			}
			bundles.push({
				info,
				name: typeof value.m_AssetBundleName === 'string' ? value.m_AssetBundleName : undefined,
				container,
			});
		}
		return bundles;
	}
}

/**
 * @param bundle an opened bundle
 * @returns its SerializedFiles
 */
export const openAssetFiles = (bundle: UnityBundle): Promise<BundleAssetFile[]> => {
	return Promise.all(bundle.serializedFileNodes().map((node) => BundleAssetFile.open(bundle, node)));
};
