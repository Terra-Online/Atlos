import { ByteView } from './byte-view.ts';

/**
 * minimal schema-less FlatBuffers accessor. Endfield ships no `.fbs` schemas for its world data, so readers
 * address fields by vtable slot index and validate everything they dereference.
 */
export class FlatBuffer extends ByteView {
	/** @param bytes the whole FlatBuffer; not copied */
	constructor(bytes: Uint8Array) {
		super(bytes, 'flatbuffer');
	}

	/** @returns position of the root table */
	root(): number {
		return this.u32(0);
	}

	/** @returns the number of vtable slots a table declares */
	fieldCount(table: number): number {
		const vtable = table - this.i32(table);
		return (this.u16(vtable) - 4) >> 1;
	}

	/**
	 * @param table table position
	 * @param slot vtable slot index
	 * @returns absolute position of the field, or `undefined` if absent (default-valued)
	 */
	field(table: number, slot: number): number | undefined {
		const vtable = table - this.i32(table);
		const vtableSize = this.u16(vtable);
		if (4 + slot * 2 >= vtableSize) {
			return undefined;
		}
		const relative = this.u16(vtable + 4 + slot * 2);
		return relative === 0 ? undefined : table + relative;
	}

	/** follows the uoffset stored at `at` */
	deref(at: number): number {
		return at + this.u32(at);
	}

	/**
	 * @param table table position
	 * @param slot vtable slot holding a vector uoffset
	 * @returns the vector's element start and length; an absent field reads as empty
	 */
	vector(table: number, slot: number): { start: number; length: number } {
		const at = this.field(table, slot);
		if (at === undefined) {
			return { start: 0, length: 0 };
		}
		const vector = this.deref(at);
		const length = this.u32(vector);
		return { start: vector + 4, length };
	}

	/** @returns the table referenced by element `index` of a vector of tables */
	tableAt(vectorStart: number, index: number): number {
		return this.deref(vectorStart + index * 4);
	}

	/** @returns a view (not a copy) of a byte vector stored in slot `slot` */
	byteVector(table: number, slot: number): Uint8Array {
		const { start, length } = this.vector(table, slot);
		return this.subarray(start, length);
	}

	/** @returns the table referenced by slot `slot`, or `undefined` if absent */
	tableField(table: number, slot: number): number | undefined {
		const at = this.field(table, slot);
		return at === undefined ? undefined : this.deref(at);
	}

	/** @returns the FlatBuffers string (`u32 length ‖ UTF-8`) starting at `at` */
	stringAt(at: number): string {
		const length = this.u32(at);
		return this.utf8(at + 4, length);
	}

	/** @returns the UTF-8 string stored in slot `slot`, or `''` if absent */
	stringField(table: number, slot: number): string {
		const at = this.field(table, slot);
		return at === undefined ? '' : this.stringAt(this.deref(at));
	}

	/** @returns the boolean stored in slot `slot`, or `false` if absent */
	boolField(table: number, slot: number): boolean {
		const at = this.field(table, slot);
		return at !== undefined && this.u8(at) !== 0;
	}

	/** @returns the unsigned 8-bit integer stored in slot `slot`, or `0` if absent */
	u8Field(table: number, slot: number): number {
		const at = this.field(table, slot);
		return at === undefined ? 0 : this.u8(at);
	}

	/** @returns the signed 32-bit integer stored in slot `slot`, or `0` if absent */
	i32Field(table: number, slot: number): number {
		const at = this.field(table, slot);
		return at === undefined ? 0 : this.i32(at);
	}

	/** @returns the unsigned 32-bit integer stored in slot `slot`, or `0` if absent */
	u32Field(table: number, slot: number): number {
		const at = this.field(table, slot);
		return at === undefined ? 0 : this.u32(at);
	}

	/** @returns the 32-bit float stored in slot `slot`, or `0` if absent */
	f32Field(table: number, slot: number): number {
		const at = this.field(table, slot);
		return at === undefined ? 0 : this.f32(at);
	}

	/** @returns the unsigned 64-bit integer stored in slot `slot`, or `0n` if absent */
	u64Field(table: number, slot: number): bigint {
		const at = this.field(table, slot);
		return at === undefined ? 0n : this.u64(at);
	}
}
