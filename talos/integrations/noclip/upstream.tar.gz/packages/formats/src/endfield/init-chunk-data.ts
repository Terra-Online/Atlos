import { FormatError } from '../binary/binary-reader.ts';
import { ByteView } from '../binary/byte-view.ts';
import { FlatBuffer } from '../binary/flatbuffer.ts';
import type { Aabb } from '../unity/values.ts';

import { levelTagOf } from './level-partition.ts';
import { readChunkRows, type ChunkRows } from './mono-objects.ts';

export { ChunkObjectKind, INIT_CHUNK_VERSIONS } from './mono-objects.ts';

// static scenery placements (docs/game-data/world.md#static-scenery-initchunkdata-and-streamingchunkdata).
// framing ported from An1X3R/Endfield-map-extractor (MIT, `extractor_core/{instances,flatbuffer}.py`,
// `extract_scene_renderer_materials.py`) and field readings of Variante/endfield_research_kit (MIT,
// `memory/game_data/world_chunk*.md`).

// #region types

/** a root object row */
export interface ChunkObject {
	id: number;
	/** union tag of the row: a `ChunkObjectKind` value, or another the game has */
	kind: number;
	name: string;
	/** a {@link StreamingLayer} value: the layer whose grid and radius load the object */
	layer: number;
}

/**
 * the game's `StreamingLayer`: each has its own grid and load radius
 * (docs/game-data/world.md#streaming-layers)
 */
export const StreamingLayer = {
	Default: 0,
	Persistent: 1,
	HLOD0: 2,
	HLOD1: 3,
	HLOD2: 4,
	Collider: 5,
	Tiny: 6,
	Water: 7,
	Lighting: 8,
	Audio: 9,
	RendererWithCollider: 10,
} as const;

/** one component column inside a group's blob */
export interface ComponentColumn {
	/** anonymous descriptor id; see {@link Component} for the ones with known meaning */
	id: number;
	stride: number;
	/** byte offset of the column's first element within the group blob */
	offset: number;
}

/** a set of entities sharing the same components, stored column-major */
export interface ComponentGroup {
	ids: Uint32Array;
	/** union of the members' world bounds, or `null` when unset */
	bounds: Aabb | null;
	columns: ComponentColumn[];
	blob: Uint8Array;
}

/** a parsed InitChunkData FlatBuffer */
export interface InitChunk {
	version: number;
	/** chunk origin in world metres, `null` for Global chunks */
	origin: { x: number; z: number } | null;
	objects: ChunkObject[];
	groups: ComponentGroup[];
	/** the underlying 8-slot root and union rows, shared with light, foliage, and MonoBehaviour readers */
	rows: ChunkRows;
}

/** a draw call of a static renderer */
export interface RendererDraw {
	/** StringPathHash key of the mesh (`<container>.fbx##<subasset>`, `.mesh` or `.asset`) */
	meshHash: bigint;
	/** StringPathHash key of the `.mat` */
	materialHash: bigint;
	submesh: number;
	/** renderer flag word; bit {@link DrawFlags.ShadowOnly} marks shadow-caster-only draws */
	flags: number;
	/**
	 * the draw is visible while `minSquared < s² <= maxSquared`, where `s` is the renderer's screen-relative
	 * height as in Unity's LODGroup. `maxSquared` is `FLT_MAX` for the nearest LOD; a negative `minSquared`
	 * means it's never culled by size
	 */
	lodMaxSquared: number;
	lodMinSquared: number;
	/** LOD level of this draw, from {@link Component.LodRanges} */
	lod: number;
}

/** what a static entity draws */
export interface StaticRenderer {
	draws: RendererDraw[];
	/** number of LOD levels */
	lodCount: number;
}

/** a placed entity with its decoded components */
export interface ChunkEntity {
	/** full 32-bit entity id */
	id: number;
	/** `id >>> 27`: the owning level's namespace; 0 is the map-wide shared set */
	levelTag: number;
	name: string;
	/** a {@link StreamingLayer} value, from the entity's object row; `Default` without a row */
	layer: number;
	/** 4×4 column-major object-to-world matrix, when the entity has one */
	matrix: Float32Array | null;
	/** world bounds, when present */
	bounds: Aabb | null;
	renderer: StaticRenderer | null;
	/**
	 * a projected rect decal's placement values, or `null` for other entities; its material lives in
	 * StreamingChunkData, not here
	 */
	decal: RectDecal | null;
	/**
	 * a WaterDecal foam box's placement values (component 31), or `null` for other entities; like a rect
	 * decal's, its material lives in StreamingChunkData
	 */
	waterDecal: WaterDecal | null;
	/**
	 * the world point a light-art entity's (component 58) LOD thresholds are camera distances from, its
	 * component-6 LOD centre; `null` for entities whose thresholds are screen-relative sizes
	 */
	lodDistanceFrom: [x: number, y: number, z: number] | null;
	/**
	 * a constant spin the entity turns with (component 54, or 52 turned into world space), or `null` for
	 * entities that hold still
	 */
	rotator: Rotator | null;
	/**
	 * the hash of the cloth simulation that moves the entity's vertices (component 60), which a cloth group
	 * proxy of its cell holds; `null` for entities drawn as their mesh stands
	 */
	clothHash: number | null;
	/** descriptor ids present on the entity */
	components: number[];
}

/**
 * a constant spin about a world axis. at time `t` the entity's stored transform is turned by `speed · t`
 * radians about `axis` through `pivot`, as Unity's `Quaternion.AngleAxis` turns
 */
export interface Rotator {
	/** radians per second, non-negative; the axis carries the direction */
	speed: number;
	/** unit axis, world space */
	axis: [x: number, y: number, z: number];
	/** a point on the axis, world space */
	pivot: [x: number, y: number, z: number];
}

/**
 * a rect decal's own values (component 27 after its matrix and inverse). the decal projects down the local y
 * of a unit box, whose matrix is the entity's
 */
export interface RectDecal {
	/** the box's UVs, `local.xz + 0.5`, are scaled by this and then offset */
	uvScale: [u: number, v: number];
	uvOffset: [u: number, v: number];
	/** RGBA8 as stored, 0–1: the colour multiplies the base colour as is, the alpha the opacity */
	color: [r: number, g: number, b: number, a: number];
	/** scales the colour */
	intensity: number;
	/**
	 * an angle in degrees (270 and 90 seen) that the wetness decal's vertex stage bends the box into a sector
	 * by, when its per-draw shape byte is 2; whether that byte is `flags`' low byte is unchecked
	 */
	sectorAngle: number;
	/** flag word, 0 on every decal seen */
	flags: number;
}

/**
 * a static WaterDecal box's per-placement values (component 31, the game's `HGWaterDecalComponent`): its
 * `HGWaterDecalRenderer`'s, which the shader reads from two per-draw vectors. the box is the render
 * pipeline's unit cube under the entity's matrix
 */
export interface WaterDecal {
	/**
	 * `animParam0`: the renderer's tiling, speed, opacity and brightness; (1, 1, 1, 1) leaves the material as
	 * is
	 */
	params: [tiling: number, speed: number, opacity: number, brightness: number];
	/** `animParam1`: the renderer's displacement, then its tint's rgb */
	displacementTint: [displacement: number, r: number, g: number, b: number];
}

// #endregion

// #region component ids

/**
 * descriptor ids whose meaning is established. ids are anonymous column selectors in the native reader; these
 * labels come from layout + cross-checks against named data (paths, matrices, names).
 */
export const Component = {
	/** f32 world AABB centre x; ids 0–5 are centre xyz then extents xyz */
	BoundsCenterX: 0,
	/**
	 * 20 bytes, the game's `RenderObjectLODInfoComponent`: `f32×3` LOD centre (world), `f32` half size squared,
	 * `u8` dither, `u8` culling options (0 on every map02 entity), 2 padding
	 */
	LodInfo: 6,
	/** 4 + 32·2ⁿ bytes for n = id − 8: `u32 count`, 2ⁿ × 24-byte draw infos, 2ⁿ × `(f32 max², f32 min²)` */
	DrawInfoFirst: 8,
	DrawInfoLast: 14,
	/** 256-byte instance constants; begins with the object-to-world matrix */
	InstanceData: 18,
	/** 64-byte NUL-padded name prefix */
	Name: 21,
	/** 160-byte rect decal constants: matrix, inverse, params, packed color + flags */
	RectDecal: 27,
	/**
	 * 172-byte WaterDecal box (`HGWaterDecalComponent`): `u32` render type mask, mesh and material ids (0 in
	 * the file), the object-to-world matrix at 12, two vectors, then four `animParam` vectors at 108
	 */
	WaterDecal: 31,
	/**
	 * 16-byte spin about the entity's own origin: `f32 speed` (rad/s, non-negative), `f32×3 axis` (unit, local
	 * space)
	 */
	LocalSpin: 52,
	/**
	 * 92-byte spin: `f32 speed` (rad/s), `f32×3 axis`, `f32×3 pivot`, then f32×6 (a local box, unchecked) and
	 * the stored position, rotation quaternion (xyzw) and scale
	 */
	Rotator: 54,
	/** `u32`: the hash of the entity's cloth simulation */
	ClothHash: 60,
	/**
	 * 1 byte (0 seen), on the light-art entities alone (mist cards and boxes, light beams): their draws' LOD
	 * thresholds are squared camera distances from the LOD centre (6) rather than squared screen-relative
	 * sizes
	 */
	DistanceLod: 58,
	/** 24 bytes: `u8 lodCount`, …, at 16 `u8[8]` cumulative draw count per LOD */
	LodRanges: 67,
	/** 8 + 40·2ⁿ bytes for n = id − 68: `u64 count`, 2ⁿ × `(u64 material, u64 mesh, 24 bytes)` */
	DrawRefFirst: 68,
	DrawRefLast: 74,
} as const;

/** known renderer flag bits */
export const DrawFlags = {
	/** set on draws that only cast shadows (shadow proxies) */
	ShadowOnly: 1 << 10,
	/** casts shadows at all */
	CastShadow: 0x8_0000,
	/** one bit per sharp cascade; the game sets all or none */
	Cascades: 0xf0_0000,
	/** casts into the cached far shadow map */
	StaticShadowCaster: 0x100_0000,
	/** casts into the sharp cascades */
	RealtimeShadowCaster: 0x200_0000,
} as const;

// #endregion

/**
 * parses a decoded InitChunkData FlatBuffer
 *
 * @param data the file after `unpackHgPayload` (`hg/payload.ts`)
 * @returns the chunk's objects and component groups
 * @throws {FormatError} on any framing mismatch
 */
export const parseInitChunk = (data: Uint8Array): InitChunk => parseChunk(data, null);

/**
 * reads dynamic ECS renderer columns with the ids from their paired streaming payload
 *
 * @param init decompressed `fb_init` payload
 * @param streaming decompressed matching `fb_streaming` payload
 * @returns the paired chunk, with groups in ECS index order
 * @throws {FormatError} if either root or the paired group counts are invalid
 */
export const parseDynamicChunk = (init: Uint8Array, streaming: Uint8Array): InitChunk =>
	parseChunk(init, streaming);

/**
 * parses an 8-byte-per-column ECS descriptor table (`u16 id, u16 stride, u32 reserved`) and checks that its
 * column-major layout fills `blobLength` exactly
 *
 * @param descriptors raw descriptor bytes (8 bytes per column)
 * @param count entity count
 * @param blobLength byte length of the paired column-major blob
 * @param label context name for error messages
 * @param options.checkReserved require the reserved u32 of every descriptor to be 0 (default `false`)
 * @returns column descriptors with computed byte offsets
 * @throws {FormatError} on reserved-bit or blob-size mismatch
 */
export const parseComponentColumns = (
	descriptors: Uint8Array,
	count: number,
	blobLength: number,
	label: string,
	options?: { checkReserved?: boolean },
): ComponentColumn[] => {
	const view = new ByteView(descriptors, label);
	const columns: ComponentColumn[] = [];
	const checkReserved = options?.checkReserved ?? false;
	let cursor = 0;
	for (let o = 0; o + 8 <= descriptors.length; o += 8) {
		if (checkReserved && view.u32(o + 4) !== 0) {
			throw new FormatError(`${label} descriptor ${o / 8} has non-zero reserved bits`);
		}
		const stride = view.u16(o + 2);
		columns.push({ id: view.u16(o), stride, offset: cursor });
		cursor += stride * count;
	}
	if (blobLength !== cursor) {
		throw new FormatError(`${label} blob is ${blobLength} bytes, descriptors need ${cursor}`);
	}
	return columns;
};

const parseChunk = (init: Uint8Array, idsData: Uint8Array | null): InitChunk => {
	const rows = readChunkRows(init);
	const { fb, version } = rows;
	const root = fb.root();
	const idsFb = idsData === null ? fb : new FlatBuffer(idsData);
	const idsRoot = idsData === null ? root : idsFb.root();
	if (idsData !== null && idsFb.fieldCount(idsRoot) !== 8) {
		throw new FormatError('chunk ids root must have 8 fields');
	}

	let origin: InitChunk['origin'] = null;
	{
		const at = fb.field(root, 1);
		if (at !== undefined) {
			const x = fb.i32(at);
			const z = fb.i32(at + 4);
			if (!(x === 0x7fffffff && z === -0x80000000)) {
				origin = { x, z };
			}
		}
	}

	const objects: ChunkObject[] = rows.rows.map(({ id, tag, table }) => ({
		id,
		kind: tag,
		name: fb.stringField(table, 0),
		// left out of the row when it's the default, 0
		layer: fb.u8Field(table, 1),
	}));

	const groups: ComponentGroup[] = [];
	{
		const idWrappers = idsFb.vector(idsRoot, 6);
		const tables = fb.vector(root, 7);
		if (idWrappers.length !== tables.length) {
			throw new FormatError('init chunk group vectors differ in length');
		}
		for (let g = 0; g < tables.length; g++) {
			const group = fb.tableAt(tables.start, g);
			const idVector = idsFb.vector(idsFb.tableAt(idWrappers.start, g), 0);

			const count = fb.u32Field(group, 1);
			if (count !== idVector.length) {
				throw new FormatError(`group ${g} counts ${count} entities but lists ${idVector.length} ids`);
			}
			const ids = new Uint32Array(count);
			for (let i = 0; i < count; i++) {
				ids[i] = idsFb.u32(idVector.start + i * 4);
			}

			let bounds: Aabb | null = null;
			{
				const at = fb.field(group, 2);
				if (at !== undefined) {
					const center = fb.vec3(at);
					const extents = fb.vec3(at + 12);
					if (center.some((value) => value !== 0) || extents.some((value) => value !== 0)) {
						bounds = { center, extents };
					}
				}
			}

			const descriptors = fb.vector(group, 3);
			const blobTable = fb.tableField(group, 4);
			if (blobTable === undefined) {
				throw new FormatError(`group ${g} has no component blob`);
			}
			const blob = fb.byteVector(blobTable, 0);
			const columns = parseComponentColumns(
				fb.subarray(descriptors.start, descriptors.length * 8),
				count,
				blob.length,
				`group ${g}`,
				{ checkReserved: true },
			);

			groups.push({ ids, bounds, columns, blob });
		}
	}

	return { version, origin, objects, groups, rows };
};

/**
 * @param chunk parsed chunk
 * @returns object names by id from the chunk's root rows
 */
export const chunkObjectNames = (chunk: InitChunk): Map<number, string> =>
	new Map(chunk.objects.map((object) => [object.id, object.name]));

/**
 * decodes every group entity of a chunk. entities that span cells appear in each cell's chunk under the same
 * id; callers dedupe across files.
 *
 * @param chunk parsed chunk
 * @returns one row per group entity, in file order
 * @throws {FormatError} if a renderer's draw columns disagree
 */
export const readChunkEntities = (chunk: InitChunk): ChunkEntity[] =>
	readChunkEntitiesByGroup(chunk, chunk.groups).flat();

/**
 * decodes the entities of selected groups of a chunk, building the chunk's object name/layer index once
 *
 * @param chunk parsed chunk
 * @param groups groups from `chunk.groups` to decode
 * @returns one entity array per group, in input order
 * @throws {FormatError} if a renderer's draw columns disagree
 */
export const readChunkEntitiesByGroup = (
	chunk: InitChunk,
	groups: readonly InitChunk['groups'][number][],
): ChunkEntity[][] => {
	const names = new Map<number, string>();
	const layers = new Map<number, number>();
	for (const object of chunk.objects) {
		names.set(object.id, object.name);
		layers.set(object.id, object.layer);
	}

	const perGroup: ChunkEntity[][] = [];
	for (const group of groups) {
		const entities: ChunkEntity[] = [];
		const ids = group.columns.map((column) => column.id);
		const blobView = new ByteView(group.blob, 'component group');
		const column = (id: number): ComponentColumn | undefined => groupColumn(group, id);

		const boundsOf = groupBounds(group);
		const decalColumn = column(Component.RectDecal);
		const waterDecalColumn = column(Component.WaterDecal);
		if (waterDecalColumn !== undefined && waterDecalColumn.stride !== WATER_DECAL_SIZE) {
			throw new FormatError(`a group has a ${waterDecalColumn.stride}-byte water decal`);
		}
		// the matrix's column and its offset in each element
		let matrixSource: { column: ComponentColumn; at: number } | undefined;
		{
			const own = column(Component.InstanceData) ?? decalColumn;
			if (own !== undefined) {
				matrixSource = { column: own, at: 0 };
			} else if (waterDecalColumn !== undefined) {
				matrixSource = { column: waterDecalColumn, at: WATER_DECAL_MATRIX };
			}
		}
		const rotatorColumn = column(Component.Rotator);
		const localSpinColumn = column(Component.LocalSpin);
		const lodInfoColumn = column(Component.LodInfo);
		const distanceLod = column(Component.DistanceLod) !== undefined;
		if (distanceLod && lodInfoColumn?.stride !== LOD_INFO_SIZE) {
			throw new FormatError('a group has distance LODs without a 20-byte LOD centre');
		}
		const clothColumn = column(Component.ClothHash);
		if (clothColumn !== undefined && clothColumn.stride !== 4) {
			throw new FormatError(`a group has a ${clothColumn.stride}-byte cloth hash`);
		}
		const nameOf = groupNames(group, names);
		const lodColumn = column(Component.LodRanges);
		const refColumns = group.columns.filter(
			(c) => c.id >= Component.DrawRefFirst && c.id <= Component.DrawRefLast,
		);
		// the group's matrices packed into one buffer rather than a buffer per entity, so they don't pin the
		// chunk's payload either
		let matrices: Float32Array | undefined;
		if (matrixSource !== undefined) {
			const { column: matrixColumn, at } = matrixSource;
			matrices = new Float32Array(group.ids.length * 16);
			const bytes = new Uint8Array(matrices.buffer);
			for (let i = 0; i < group.ids.length; i++) {
				const start = matrixColumn.offset + i * matrixColumn.stride + at;
				bytes.set(group.blob.subarray(start, start + 64), i * 64);
			}
		}

		for (let i = 0; i < group.ids.length; i++) {
			const id = group.ids[i];
			const name = nameOf(i);
			const bounds = boundsOf?.(i) ?? null;
			const matrix = matrices?.subarray(i * 16, i * 16 + 16) ?? null;

			let renderer: StaticRenderer | null = null;
			if (refColumns.length > 0) {
				const lodEnds =
					lodColumn === undefined ? undefined : group.blob.subarray(lodColumn.offset + i * lodColumn.stride);
				const draws: RendererDraw[] = [];
				for (const refs of refColumns) {
					const infos = column(refs.id - (Component.DrawRefFirst - Component.DrawInfoFirst));
					if (infos === undefined) {
						throw new FormatError(`entity ${id} has draw refs ${refs.id} without draw infos`);
					}
					draws.push(...decodeDraws(blobView, { refs, infos, index: i, entityId: id }));
				}
				let lodCount = 1;
				if (lodEnds !== undefined) {
					lodCount = lodEnds[0];
					assignLods(draws, lodEnds.subarray(16, 24), id);
				}
				renderer = { draws, lodCount };
			}

			let rotator: Rotator | null = null;
			if (rotatorColumn !== undefined) {
				rotator = readRotator(blobView, rotatorColumn, i, id);
			} else if (localSpinColumn !== undefined && matrix !== null) {
				rotator = readLocalSpin(blobView, localSpinColumn, { index: i, entityId: id, matrix });
			}

			entities.push({
				id,
				levelTag: levelTagOf(id),
				name,
				layer: layers.get(id) ?? StreamingLayer.Default,
				matrix,
				bounds,
				renderer,
				decal: decalColumn === undefined ? null : readRectDecal(blobView, decalColumn, i, id),
				waterDecal: waterDecalColumn === undefined ? null : readWaterDecal(blobView, waterDecalColumn, i),
				lodDistanceFrom:
					distanceLod && lodInfoColumn !== undefined ? readLodCentre(blobView, lodInfoColumn, i) : null,
				rotator,
				clothHash: clothColumn === undefined ? null : blobView.u32(clothColumn.offset + i * 4),
				components: ids,
			});
		}
		perGroup.push(entities);
	}
	return perGroup;
};

const ROTATOR_SIZE = 92;

const readRotator = (view: ByteView, column: ComponentColumn, index: number, entityId: number): Rotator => {
	if (column.stride !== ROTATOR_SIZE) {
		throw new FormatError(`entity ${entityId} has a ${column.stride}-byte rotator`);
	}
	const at = column.offset + index * column.stride;
	const speed = view.f32(at);
	const axis = view.vec3(at + 4);
	if (!(speed >= 0) || Math.abs(Math.hypot(...axis) - 1) > 1e-3) {
		throw new FormatError(`entity ${entityId} has a rotator of speed ${speed} about [${axis.join(', ')}]`);
	}
	return { speed, axis, pivot: view.vec3(at + 16) };
};

const LOCAL_SPIN_SIZE = 16;

/**
 * reads component 52 as a world-space spin: the local axis through the matrix, pivoting on its translation.
 * turning the world transform about that axis equals turning the local one only under uniform scale, which
 * every entity with the component has
 */
const readLocalSpin = (
	view: ByteView,
	column: ComponentColumn,
	{ index, entityId, matrix }: { index: number; entityId: number; matrix: Float32Array },
): Rotator => {
	if (column.stride !== LOCAL_SPIN_SIZE) {
		throw new FormatError(`entity ${entityId} has a ${column.stride}-byte local spin`);
	}
	const at = column.offset + index * column.stride;
	const speed = view.f32(at);
	const local = view.vec3(at + 4);
	if (!(speed >= 0) || Math.abs(Math.hypot(...local) - 1) > 1e-3) {
		throw new FormatError(
			`entity ${entityId} has a local spin of speed ${speed} about [${local.join(', ')}]`,
		);
	}
	const scales = [0, 4, 8].map((c) => Math.hypot(matrix[c], matrix[c + 1], matrix[c + 2]));
	if (Math.max(...scales) - Math.min(...scales) > 1e-3 * Math.max(...scales)) {
		throw new FormatError(
			`entity ${entityId} has a local spin under non-uniform scale [${scales.join(', ')}]`,
		);
	}
	const world = [0, 1, 2].map(
		(r) => matrix[r] * local[0] + matrix[4 + r] * local[1] + matrix[8 + r] * local[2],
	);
	const length = Math.hypot(...world);
	return {
		speed,
		axis: [world[0] / length, world[1] / length, world[2] / length],
		pivot: [matrix[12], matrix[13], matrix[14]],
	};
};

const RECT_DECAL_SIZE = 160;

const LOD_INFO_SIZE = 20;

/** component 6's LOD centre */
const readLodCentre = (view: ByteView, column: ComponentColumn, index: number): [number, number, number] =>
	view.vec3(column.offset + index * column.stride);

const WATER_DECAL_SIZE = 172;
const WATER_DECAL_MATRIX = 12;
const WATER_DECAL_ANIM = 108;

/** component 31's first two `animParam` vectors; the stride is checked per group */
const readWaterDecal = (view: ByteView, column: ComponentColumn, index: number): WaterDecal => {
	const at = column.offset + index * column.stride + WATER_DECAL_ANIM;
	return { params: view.vec4(at), displacementTint: view.vec4(at + 16) };
};

/** component 27 after the matrix and its inverse: UV scale, UV offset, RGBA8 colour, intensity, angle, flags */
const readRectDecal = (
	view: ByteView,
	column: ComponentColumn,
	index: number,
	entityId: number,
): RectDecal => {
	if (column.stride !== RECT_DECAL_SIZE) {
		throw new FormatError(`entity ${entityId} has a ${column.stride}-byte rect decal`);
	}
	const at = column.offset + index * column.stride + 128;
	const rgba = view.u32(at + 16);
	const byte = (shift: number): number => ((rgba >>> shift) & 0xff) / 255;
	return {
		uvScale: [view.f32(at), view.f32(at + 4)],
		uvOffset: [view.f32(at + 8), view.f32(at + 12)],
		color: [byte(0), byte(8), byte(16), byte(24)],
		intensity: view.f32(at + 20),
		sectorAngle: view.f32(at + 24),
		flags: view.u32(at + 28),
	};
};

/**
 * @param group a component group
 * @param id a descriptor id
 * @returns the group's column with that id, if any
 */
export const groupColumn = (group: ComponentGroup, id: number): ComponentColumn | undefined =>
	group.columns.find((column) => column.id === id);

/**
 * @param group a component group
 * @returns a reader of each member's world bounds (by index in the group), or `null` if the group has no
 *   bounds columns
 */
export const groupBounds = (group: ComponentGroup): ((index: number) => Aabb) | null => {
	const columns: ComponentColumn[] = [];
	for (let id = Component.BoundsCenterX; id < Component.BoundsCenterX + 6; id++) {
		const column = groupColumn(group, id);
		if (column === undefined || column.stride !== 4) {
			return null;
		}
		columns.push(column);
	}
	const view = new ByteView(group.blob, 'component group');
	return (index) => {
		const v = columns.map((column) => view.f32(column.offset + index * 4));
		return { center: [v[0], v[1], v[2]], extents: [v[3], v[4], v[5]] };
	};
};

/**
 * @param group a component group
 * @param names object names by id (the root rows'), which win over the group's truncated name column
 * @returns a reader of each member's name (by index in the group); `''` where neither has one
 */
export const groupNames = (
	group: ComponentGroup,
	names: ReadonlyMap<number, string>,
): ((index: number) => string) => {
	const column = groupColumn(group, Component.Name);
	return (index) => {
		const name = names.get(group.ids[index]);
		if (name !== undefined || column === undefined) {
			return name ?? '';
		}
		const start = column.offset + index * column.stride;
		const raw = group.blob.subarray(start, start + column.stride);
		const end = raw.indexOf(0);
		return textDecoder.decode(end < 0 ? raw : raw.subarray(0, end));
	};
};

/** one entity's draw-ref and draw-info columns */
interface DrawColumns {
	refs: ComponentColumn;
	infos: ComponentColumn;
	/** entity index within the group */
	index: number;
	/** for error messages */
	entityId: number;
}

const decodeDraws = (view: ByteView, columns: DrawColumns): RendererDraw[] => {
	const { refs, infos, index, entityId } = columns;
	const capacity = 1 << (refs.id - Component.DrawRefFirst);
	if (refs.stride !== 8 + 40 * capacity || infos.stride !== 4 + 32 * capacity) {
		throw new FormatError(`entity ${entityId} has unexpected draw strides ${refs.stride}/${infos.stride}`);
	}
	const refAt = refs.offset + index * refs.stride;
	const infoAt = infos.offset + index * infos.stride;
	const count = Number(view.u64(refAt));
	if (count > capacity || view.u32(infoAt) !== count) {
		throw new FormatError(`entity ${entityId} draw counts disagree`);
	}
	const out: RendererDraw[] = [];
	for (let d = 0; d < count; d++) {
		const ref = refAt + 8 + d * 40;
		const info = infoAt + 4 + d * 24;
		const lod = infoAt + 4 + capacity * 24 + d * 8;
		out.push({
			materialHash: view.u64(ref),
			meshHash: view.u64(ref + 8),
			submesh: view.u8(info + 2),
			flags: view.u32(info + 16),
			lodMaxSquared: view.f32(lod),
			lodMinSquared: view.f32(lod + 4),
			lod: 0,
		});
	}
	return out;
};

/** spreads LOD levels over draws from the cumulative per-LOD draw counts */
const assignLods = (draws: RendererDraw[], ends: Uint8Array, id: number): void => {
	let lod = 0;
	for (let d = 0; d < draws.length; d++) {
		while (lod < ends.length && d >= ends[lod]) {
			lod++;
		}
		if (lod >= ends.length) {
			throw new FormatError(`entity ${id} has more draws than its LOD ranges cover`);
		}
		draws[d].lod = lod;
	}
};

const textDecoder = new TextDecoder('utf-8');
