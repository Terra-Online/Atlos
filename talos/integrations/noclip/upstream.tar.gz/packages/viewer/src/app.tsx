import { useEffect, useEffectEvent, useRef, useState } from 'react';

import { sourceFromParam } from './package/package-param.ts';
import type { PackageSource } from './package/package-source.ts';
import { CameraReadout } from './ui/camera-readout.tsx';
import { describeError } from './ui/format.ts';
import { LevelsPanel } from './ui/levels-panel.tsx';
import { type OpenPackage, PackagePanel } from './ui/package-panel.tsx';
import { SceneControls } from './ui/scene-controls/scene-controls.tsx';
import { SettingsPanel } from './ui/settings-panel.tsx';
import { StatsPanel } from './ui/stats-panel.tsx';
import { Viewer } from './viewer/viewer.ts';

const PACKAGE_PARAM = 'package';
const LEVEL_PARAM = 'level';

/** sets or clears a search parameter of the page URL without a navigation */
const setParam = (name: string, value: string | null): void => {
	const url = new URL(location.href);
	if (value === null) {
		url.searchParams.delete(name);
	} else {
		url.searchParams.set(name, value);
	}
	history.replaceState(null, '', url);
};

export const App = () => {
	const canvasRef = useRef<HTMLCanvasElement>(null);
	const [viewer, setViewer] = useState<Viewer | null>(null);
	const [error, setError] = useState<string | null>(null);
	const [current, setCurrent] = useState<OpenPackage | null>(null);
	const [status, setStatus] = useState('');

	const open = (target: Viewer, source: PackageSource, param: string | null): void => {
		setParam(PACKAGE_PARAM, param);
		setStatus('opening…');
		setCurrent({ label: source.label, param });
		target
			.load(source, new URL(location.href).searchParams.get(LEVEL_PARAM), setStatus)
			.then(() => setStatus(''))
			.catch((err: unknown) => {
				setCurrent(null);
				setStatus(`couldn't open ${source.label}: ${describeError(err)}`);
			});
	};
	const openInitial = useEffectEvent((instance: Viewer, param: string) =>
		open(instance, sourceFromParam(param), param),
	);

	useEffect(() => {
		const canvas = canvasRef.current;
		if (canvas === null) {
			return;
		}
		// StrictMode mounts this effect twice in development, so the first creation is aborted mid-flight
		const abort = new AbortController();
		let created: Viewer | null = null;
		Viewer.create(canvas, (reason) => setError(`the GPU device was lost: ${reason}`), abort.signal)
			.then((instance) => {
				// built before the abort, so before any replacement touched the canvas: safe to destroy
				if (abort.signal.aborted) {
					instance.destroy();
					return;
				}
				created = instance;
				if (import.meta.env.DEV) {
					// exposed for debugging and automated measurements
					Object.assign(window, { viewer: instance });
				}
				setViewer(instance);
				const param = new URL(location.href).searchParams.get(PACKAGE_PARAM);
				if (param !== null) {
					openInitial(instance, param);
				}
			})
			.catch((err: unknown) => {
				if (!abort.signal.aborted) {
					setError(describeError(err));
				}
			});
		return () => {
			abort.abort();
			created?.destroy();
		};
	}, []);

	// the current level lives in the URL, so a reload or a shared link opens over the same level
	useEffect(() => {
		if (viewer === null) {
			return;
		}
		return viewer.subscribe(() => {
			// nothing to record while no package is loaded (including mid-load)
			if (viewer.manifest !== null && new URL(location.href).searchParams.get(LEVEL_PARAM) !== viewer.level) {
				setParam(LEVEL_PARAM, viewer.level);
			}
		});
	}, [viewer]);

	return (
		<main className="app">
			<canvas ref={canvasRef} className="viewport" />
			{error !== null && (
				<div className="panel error" role="alert">
					<h2>can't start the viewer</h2>
					<p>{error}</p>
				</div>
			)}
			{viewer !== null && (
				<>
					<div className="dock left">
						<PackagePanel
							current={current}
							status={status}
							onOpen={(source, param) => open(viewer, source, param)}
						/>
						<StatsPanel viewer={viewer} />
					</div>
					<div className="dock right">
						<LevelsPanel viewer={viewer} />
						<SceneControls viewer={viewer} />
						<SettingsPanel viewer={viewer} />
					</div>
					<div className="dock bottom">
						<CameraReadout viewer={viewer} />
					</div>
				</>
			)}
		</main>
	);
};
