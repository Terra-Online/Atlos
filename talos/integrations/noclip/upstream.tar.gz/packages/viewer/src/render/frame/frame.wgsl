// per-pass uniforms and the lighting shared by every family (group 0). positions are camera-relative Unity
// coordinates. light is pre-exposed: the sun's illuminance and the ambient probe are already multiplied by
// the level's exposure, so shaded values land around 0–2 before tonemapping.

struct Frame {
	// #region camera
	// camera-relative view-projection: reversed-Z, infinite far plane
	view_proj: mat4x4f,
	// camera world position (f32, for world-space lookups only), w = time (s)
	eye: vec4f,
	// the camera's unit forward, right and up vectors, w unused
	view_forward: vec4f,
	view_right: vec4f,
	view_up: vec4f,
	// output width, height (px), pixel factor (output px per metre at 1 m), minimum projected instance size (px)
	viewport: vec4f,
	// render width, height (px), then the inner and outer radius (m) the player's fire seed adds to every global
	// reveal (`FireSeedInfo.radii`, the game's `_VFXParams3.xy`)
	render_size: vec4f,
	// #endregion
	// #region lighting
	// direction towards the sun, w = 1 when the sun casts light
	sun: vec4f,
	// sun illuminance (pre-exposed lux, linear rgb), w = specular intensity
	sun_color: vec4f,
	// the ambient probe in Unity's shader form: SHAr, SHAg, SHAb, SHBr, SHBg, SHBb, SHC
	sh: array<vec4f, 7>,
	// x = indirect specular factor, y = 1 / post exposure (scales emission that ignores it), z = 1 with a reflection cubemap, w = its last mip level (mip count − 1)
	ambient: vec4f,
	// world position of each irradiance clipmap level's centre (0.5 m, 2 m, 8 m probes), w = 1 once filled
	irradiance: array<vec4f, 3>,
	// this frame's local lights (local-lights.ts): count, screen tiles across and down, near plane (m)
	local_lights: vec4f,
	// #endregion
	// #region terrain and debug
	// terrain: zero-sample height relative to the eye, metres per height unit, hole bit (u32 bits), 0
	terrain: vec4f,
	// x = wireframe, y = debug view (0 lit, 1 albedo, 2 normals, 3 roughness, 4 ambient only; 5, the raw
	// cloud panorama, is lit here and shown by the post chain), z, w reserved
	flags: vec4u,
	// boxes larger than x metres (max half extent) draw as outlines only; y = material texture mip bias (log2 of
	// the render scale, so upsampled frames sample at the output's density); z = `indirectDiffuseFactor`, the
	// game's scale on all diffuse ambient, applied here to the irradiance volume (`sh` already carries it); w
	// reserved
	params: vec4f,
	// #endregion
	// #region shadows
	// camera-relative position → shadow map [0, 1]² × depth, per layer: three sharp cascades, then the far layer
	shadow_matrices: array<mat4x4f, 4>,
	// x = the sharp cascades' reach squared (m²), y = 1 / (reach² − fade start²), z reserved, w = 1 when shadows are on
	shadow_fade: vec4f,
	// xyz = each sharp cascade's filter radius (shadow map uv), w reserved
	shadow_penumbra: vec4f,
	// each layer's bounding sphere: camera-relative centre, w = radius squared
	shadow_spheres: array<vec4f, 4>,
	// x = strength, y = how far the shadow is replaced by z (a fixed attenuation), w = 1 with a penumbra ramp
	shadow_look: vec4f,
	// #endregion
	// #region weather
	// the cloud shadow (`Environment.cloudShadow`): [0] = centre (world), w = 1 when on; [1] = switch start (m),
	// switch end (m), repeats per metre, 0; [2] = flow per second, alpha, far scale; [3] = projection, 0
	cloud_shadow: array<vec4f, 4>,
	// the rain wetness (wetness.ts): [0] = wetness (0: dry), base porosity, porosity factor, occlusion range (m);
	// [1] = far distance factor, far wetness, sheltered wetness, vertical wetness; [2] = x: the standing water's
	// mask threshold (0: none), yzw unused
	wetness: array<vec4f, 3>,
	// the wind (`_WindGlobalParams0`, wind.ts): x = the wind clock, y = the main intensity, zw = the unit XZ
	// direction it blows toward
	wind: vec4f,
	// #endregion
}

@group(0) @binding(0) var<uniform> frame: Frame;
@group(0) @binding(1) var shadow_map: texture_depth_2d_array;
@group(0) @binding(2) var shadow_sampler: sampler_comparison;
// raw depth reads (gathers) of the shadow map
@group(0) @binding(9) var shadow_gather_sampler: sampler;
// the penumbra tint, sampled at the shadow value (u) with irradiance_clamp; black without one
@group(0) @binding(10) var shadow_ramp: texture_2d<f32>;
// the level's sky reflection, prefiltered by roughness over its mips (Unity's convention); a black cube
// until it streams in, flagged by ambient.z
@group(0) @binding(3) var reflection_map: texture_cube<f32>;
@group(0) @binding(4) var reflection_sampler: sampler;
// the baked irradiance volume's clipmaps, levels stacked along z (irradiance-clipmap.wgsl): L0 rgb (A), and
// three slabs along y holding the red, green and blue L1 directions · 0.25 + 0.5 with the probe's validity in
// alpha (B)
@group(0) @binding(5) var irradiance_a: texture_3d<f32>;
@group(0) @binding(6) var irradiance_b: texture_3d<f32>;
@group(0) @binding(7) var irradiance_repeat: sampler;
@group(0) @binding(8) var irradiance_clamp: sampler;
// local lights, 8 vec4s each (`packLight` in local-lights.ts), and their bins: 8-word masks per 32 px screen
// tile, then per 1 m view-depth slice
@group(0) @binding(11) var<storage, read> lights: array<vec4f>;
@group(0) @binding(12) var<storage, read> light_bins: array<u32>;
// the cloud shadow's tiling texture (red), sampled with irradiance_repeat; a placeholder while off
@group(0) @binding(13) var cloud_shadow_map: texture_2d<f32>;
// the local lights' shadow atlas (light-shadows.ts), compared through shadow_sampler; its records follow the lights
// in `lights`, from LIGHT_SHADOW_RECORDS: the matrix from a camera-relative position to a tile's uv, depth and view
// depth, the tile's rect in the atlas (origin, size), then a texel's size at 1 m, the constant offset along the
// normal, the far plane and 1 for a drawn tile
@group(0) @binding(14) var light_shadow_map: texture_depth_2d;

// #region sun shadow

// the classic 16-point Poisson disk
const POISSON = array<vec2f, 16>(
	vec2f(-0.94201624, -0.39906216), vec2f(0.94558609, -0.76890725), vec2f(-0.09418410, -0.92938870),
	vec2f(0.34495938, 0.29387760), vec2f(-0.91588581, 0.45771432), vec2f(-0.81544232, -0.87912464),
	vec2f(-0.38277543, 0.27676845), vec2f(0.97484398, 0.75648379), vec2f(0.44323325, -0.97511554),
	vec2f(0.53742981, -0.47373420), vec2f(-0.26496911, -0.41893023), vec2f(0.79197514, 0.19090188),
	vec2f(-0.24188840, 0.99706507), vec2f(-0.81409955, 0.91437590), vec2f(0.19984126, 0.78641367),
	vec2f(0.14383161, -0.14100790),
);

// the position pushed off the surface by about a texel of the layer, against acne
fn shadow_receiver(rel: vec3f, normal: vec3f, layer: u32) -> vec3f {
	let texel = 2.0 * sqrt(frame.shadow_spheres[layer].w) / f32(textureDimensions(shadow_map).x);
	let n_dot_l = dot(normal, frame.sun.xyz);
	return rel + normal * texel * 1.5 * (1.0 - max(n_dot_l, 0.0) * 0.5);
}

// a sharp cascade's visibility, or -1 outside it: the game's filter, 64 depths on a Poisson disk rotated per 4×4
// pixel cell, shaped by how far the blockers are. near blockers harden the edge, far ones leave plain PCF
fn cascade_shadow(rel: vec3f, normal: vec3f, cascade: u32, px: vec2f) -> f32 {
	let p = frame.shadow_matrices[cascade] * vec4f(shadow_receiver(rel, normal, cascade), 1.0);
	if (any(p.xyz <= vec3f(0.0)) || any(p.xyz >= vec3f(1.0))) {
		return -1.0;
	}
	let cell = vec2u(px) % 4u;
	let angle = f32(cell.x * 4u + cell.y) * (2.0 * PI / 16.0);
	let rotation = mat2x2f(cos(angle), sin(angle), -sin(angle), cos(angle));
	let radius = frame.shadow_penumbra[cascade];
	var gap = 0.0;
	var blockers = 0.0;
	for (var k = 0; k < 16; k++) {
		let depths = textureGather(shadow_map, shadow_gather_sampler, p.xy + rotation * POISSON[k] * radius, cascade);
		let blocked = step(depths, vec4f(p.z));
		gap += dot(vec4f(p.z) - depths, blocked);
		blockers += dot(blocked, vec4f(1.0));
	}
	if (blockers == 0.0) {
		return 1.0;
	}
	let t = 2.0 * clamp(blockers / 64.0, 0.0, 1.0) - 1.0;
	let s = sign(t);
	let u = 1.0 - s * t;
	let k = clamp((gap / blockers) / max(1.0 - p.z, 1e-5), 0.0, 1.0);
	return 0.5 - 0.5 * s * (1.0 - mix(u * u * u, u, k));
}

// the far layer's visibility (1 outside it): a 3×3 grid of bilinear comparisons
fn far_shadow(rel: vec3f, normal: vec3f) -> f32 {
	let p = frame.shadow_matrices[3] * vec4f(shadow_receiver(rel, normal, 3u), 1.0);
	if (any(p.xyz <= vec3f(0.0)) || any(p.xyz >= vec3f(1.0))) {
		return 1.0;
	}
	let size = vec2f(textureDimensions(shadow_map));
	var sum = 0.0;
	for (var y = -1; y <= 1; y++) {
		for (var x = -1; x <= 1; x++) {
			sum += textureSampleCompareLevel(shadow_map, shadow_sampler, p.xy + vec2f(f32(x), f32(y)) / size, 3, p.z);
		}
	}
	// fade out towards the layer's edge
	let d = rel - frame.shadow_spheres[3].xyz;
	let edge = clamp((1.0 - dot(d, d) / frame.shadow_spheres[3].w) * 5.0, 0.0, 1.0);
	return mix(1.0, sum / 9.0, edge);
}

// the sun's visibility at a camera-relative position. as in the game: sharp cascades out to a reach, dithered
// between neighbours over the outer tenth of each one's sphere, fading into the coarse far layer before the reach
// (docs/viewer/lighting.md#shadows)
fn sun_shadow(rel: vec3f, normal: vec3f, px: vec2f) -> f32 {
	if (frame.shadow_fade.w < 0.5) {
		return 1.0;
	}
	let near = clamp((frame.shadow_fade.x - dot(rel, rel)) * frame.shadow_fade.y, 0.0, 1.0);
	var sharp = -1.0;
	if (near > 0.0) {
		var cascade = 3u;
		for (var i = 0u; i < 3u; i++) {
			let d = rel - frame.shadow_spheres[i].xyz;
			if (dot(d, d) < frame.shadow_spheres[i].w) {
				cascade = i;
				break;
			}
		}
		if (cascade < 2u) {
			let d = rel - frame.shadow_spheres[cascade].xyz;
			let next = rel - frame.shadow_spheres[cascade + 1u].xyz;
			if (dot(next, next) < frame.shadow_spheres[cascade + 1u].w) {
				let outer = (sqrt(dot(d, d) / frame.shadow_spheres[cascade].w) - 0.9) * 12.0;
				cascade += u32(step(gradient_noise(px), outer));
			}
		}
		if (cascade < 3u) {
			sharp = cascade_shadow(rel, normal, cascade, px);
		}
	}
	if (near >= 1.0 && sharp >= 0.0) {
		return sharp;
	}
	let far = far_shadow(rel, normal);
	if (sharp < 0.0) {
		return far;
	}
	return mix(far, sharp, near);
}

// the sun's visibility under the cloud shadow at a camera-relative position: a tiling texture projected along
// the sun onto the centre's height plane, switching to a coarser sampling of it far from the centre
// (docs/game-data/lighting.md#cloud-shadows)
fn cloud_shadow(rel: vec3f) -> f32 {
	if (frame.cloud_shadow[0].w < 0.5) {
		return 1.0;
	}
	let d = rel + frame.eye.xyz - frame.cloud_shadow[0].xyz;
	let uv = (d + frame.cloud_shadow[3].xyz * d.y).xz * frame.cloud_shadow[1].z;
	let flow = frame.cloud_shadow[2].xy * frame.eye.w;
	let near = textureSampleLevel(cloud_shadow_map, irradiance_repeat, uv + flow, 0.0).x;
	let far = textureSampleLevel(cloud_shadow_map, irradiance_repeat, uv * frame.cloud_shadow[2].w + flow, 0.0).x;
	// smoothstep, safe for an empty range
	let range = frame.cloud_shadow[1].xy;
	let t = clamp((length(d.xz) - range.x) / max(range.y - range.x, 1e-4), 0.0, 1.0);
	let cloud = mix(near, far, t * t * (3.0 - 2.0 * t));
	return mix(1.0, cloud, frame.cloud_shadow[2].z);
}

// what reaches a surface of the sun's light, per channel: the shadow (with the cloud shadow), replaced by the
// environment's fixed attenuation where it keeps the sun out (caves), weakened by its strength and tinted
// through its penumbra ramp
fn sun_visibility(rel: vec3f, normal: vec3f, px: vec2f) -> vec3f {
	if (frame.shadow_fade.w < 0.5) {
		return vec3f(cloud_shadow(rel));
	}
	var shadow = frame.shadow_look.z;
	if (frame.shadow_look.y < 0.99) {
		shadow = mix(sun_shadow(rel, normal, px) * cloud_shadow(rel), frame.shadow_look.z, frame.shadow_look.y);
	}
	let sh = mix(1.0, min(1.0, shadow), frame.shadow_look.x);
	if (frame.shadow_look.w < 0.5) {
		return vec3f(sh);
	}
	let ramp = textureSampleLevel(shadow_ramp, irradiance_clamp, vec2f(sh, 0.5), 0.0).rgb;
	return vec3f(1.0) - (vec3f(1.0) - ramp) * (1.0 - sh);
}

// #endregion

// the main pass writes the full radiance and, separately, its diffuse ambient part, so ambient occlusion
// computed from the depth buffer afterwards can darken only the light that it occludes. the radiance carries
// the diffuse ambient times the material occlusion; the composite swaps that for the multi-bounce of the
// lower of both occlusions, as the game does
struct Shaded {
	// rgb: radiance, a: albedo luminance (for the multi-bounce)
	@location(0) radiance: vec4f,
	// rgb: diffuse ambient before any occlusion, a: material occlusion
	@location(1) ambient: vec4f,
	// rgb: the sky reflection the radiance holds, which a screen-space hit replaces; a unused
	@location(2) reflection: vec4f,
	// what the screen-space reflections need of the surface (`pack_reflection_surface` in
	// shaders/common/reflection-surface.wgsl); 0 where none
	@location(3) reflection_surface: vec2u,
}

// what a material family hands to the lighting
struct Surface {
	albedo: vec3f,
	// world-space unit normal facing the viewer's side
	normal: vec3f,
	// perceptual roughness
	roughness: f32,
	metallic: f32,
	// the dielectric reflectance at normal incidence (0.04 for most materials)
	f0: f32,
	// baked material occlusion
	occlusion: f32,
	emission: vec3f,
	// foliage: light passing through the leaf
	transmission: f32,
	// lit with the game's two-sided foliage model (`foliage_sun` below)
	foliage: bool,
	// foliage: light wrapped around the leaf's terminator
	subsurface: f32,
	// foliage: the material's own shadow on the sun's diffuse, specular and transmission
	sun_shadow: f32,
	// foliage: the N·L of the sun's diffuse, or negative to take the shading normal's
	sun_n_dot_l: f32,
}

fn default_surface(albedo: vec3f, normal: vec3f) -> Surface {
	var s: Surface;
	s.albedo = albedo;
	s.normal = normal;
	s.roughness = 0.85;
	s.metallic = 0.0;
	s.f0 = 0.04;
	s.occlusion = 1.0;
	s.emission = vec3f(0.0);
	s.transmission = 0.0;
	s.foliage = false;
	s.subsurface = 0.0;
	s.sun_shadow = 1.0;
	s.sun_n_dot_l = -1.0;
	return s;
}

// the game's rain wetness on a surface at a camera-relative position (docs/game-data/environment.md#wetness).
// the rain occlusion map isn't rendered, so everything counts as open to the sky
fn rain_wet_surface(s_in: Surface, rel: vec3f) -> Surface {
	let p0 = frame.wetness[0];
	if (p0.x <= 0.0) {
		return s_in;
	}
	let p1 = frame.wetness[1];
	let threshold = frame.wetness[2].x;
	var s = s_in;
	let up = saturate(s.normal.y);
	let facing = mix(p1.w, 1.0, up);
	let d = max(abs(rel.x), abs(rel.z));
	// sheltered surfaces (none here) take the sheltered wetness inside the occlusion range
	let open = mix(facing, 1.0, smoothstep(0.7 * p0.w, 0.75 * p0.w, d));
	let near = mix(p1.z * facing, 1.0, open);
	let coverage = mix(near, p1.y, smoothstep(p0.w, p1.x * p0.w, d));

	// standing water: on surfaces facing straight up, fading out between 15 and about 80 m of view depth
	var standing = 0.0;
	if (threshold > 0.0) {
		let flat = smoothstep(min(threshold, 0.99), threshold, smoothstep(0.97, 0.99, up));
		let r = s.roughness;
		let level = r * 0.3 * saturate((r - 0.1) * 100.0) * s.occlusion;
		let fill = smoothstep(min(level, 0.99), saturate(level + 0.6), threshold);
		let fade = 1.0 - saturate((dot(rel, frame.view_forward.xyz) - 15.0) * 0.015);
		let wet = p0.x * flat;
		let depth = saturate(mix(threshold * 0.5, 1.0, fill) + smoothstep(0.6, 1.0, threshold) * 0.6);
		standing = smoothstep(0.0, max(s.occlusion * 0.2, 1e-4), wet * depth) * open * fade;
		s.normal = normalize(mix(s.normal, vec3f(0.0, 1.0, 0.0), saturate(wet * fill * open * fade)));
	}

	let smoothness = 1.0 - s.roughness;
	let porosity = mix(saturate(saturate(smoothness * p0.z + p0.y) + standing * 0.1 * s.roughness), 1.0, s.metallic);
	let not_down = 1.0 - smoothstep(0.2, 0.5, -s.normal.y);
	let darken = mix(1.0, 0.25, p0.x * porosity * (1.0 - s.metallic) * not_down);
	let wet_smoothness = min(
		max(saturate(mix(0.9, 0.6, porosity) + mix(-0.6, 0.4, sqrt(smoothness))), smoothness),
		0.99,
	);
	let k = p0.x * saturate(2.0 - p0.x) * not_down * coverage;
	let wet_roughness = (1.0 - mix(smoothness, wet_smoothness, k)) * mix(1.0, 0.1, standing);
	s.roughness = mix(s.roughness, wet_roughness, coverage);
	s.albedo *= mix(1.0, darken, coverage);
	return s;
}

// Unity's ShadeSH9: the probe's irradiance over π, ready to multiply by albedo
fn ambient_probe(n: vec3f) -> vec3f {
	let n4 = vec4f(n, 1.0);
	var c = vec3f(dot(frame.sh[0], n4), dot(frame.sh[1], n4), dot(frame.sh[2], n4));
	let b = n.xyzz * n.yzzx;
	c += vec3f(dot(frame.sh[3], b), dot(frame.sh[4], b), dot(frame.sh[5], b));
	c += frame.sh[6].xyz * (n.x * n.x - n.y * n.y);
	return max(c, vec3f(0.0));
}

// the L1 probe of one clipmap level at a world position, per channel as (L1 · L0, L0), times `weight`; w of
// the result's fourth vector is the probe's validity times `weight`
struct IrradianceSample {
	r: vec4f,
	g: vec4f,
	b: vec4f,
	validity: f32,
}

fn irradiance_level(level: i32, uvw_in: vec3f, clamp_all: bool, weight: f32) -> IrradianceSample {
	var uvw = uvw_in - floor(uvw_in);
	let half = 0.5 / IRRADIANCE_TEXELS;
	if (clamp_all) {
		uvw = clamp(uvw, half, vec3f(1.0) - half);
	}
	let l0 = textureSampleLevel(irradiance_a, irradiance_repeat, vec3f(uvw.xy, irradiance_z(level, uvw.z)), 0.0).xyz;
	let v = clamp(uvw.y, half.y, 1.0 - half.y) / 3.0;
	let z = irradiance_z_clamped(level, uvw.z);
	let br = textureSampleLevel(irradiance_b, irradiance_clamp, vec3f(uvw.x, v, z), 0.0);
	let bg = textureSampleLevel(irradiance_b, irradiance_clamp, vec3f(uvw.x, v + 1.0 / 3.0, z), 0.0);
	let bb = textureSampleLevel(irradiance_b, irradiance_clamp, vec3f(uvw.x, v + 2.0 / 3.0, z), 0.0);
	var s: IrradianceSample;
	s.r = vec4f((br.xyz * 4.0 - 2.0) * l0.x, l0.x) * weight;
	s.g = vec4f((bg.xyz * 4.0 - 2.0) * l0.y, l0.y) * weight;
	s.b = vec4f((bb.xyz * 4.0 - 2.0) * l0.z, l0.z) * weight;
	s.validity = br.w * weight;
	return s;
}

// how far a position is outside a clipmap level's box (half extents h metres, fading over 1/fade metres)
fn irradiance_outside(d: vec3f, h: vec2f, fade: f32) -> f32 {
	return max(clamp((max(abs(d.x), abs(d.z)) - h.x) * fade, 0.0, 1.0), clamp((abs(d.y) - h.y) * fade, 0.0, 1.0));
}

// diffuse ambient: the irradiance volume's L1 probes blended over the clipmap levels, with the ambient probe
// where they don't reach or are invalid, as the game's deferred indirect lighting does without its jitter
// (docs/viewer/lighting.md#ambient)
fn ambient_irradiance(world: vec3f, n: vec3f) -> vec3f {
	let base = ambient_probe(n);
	if (frame.irradiance[2].w < 0.5) {
		return base;
	}
	let p = world + n * 0.25;
	let outside = irradiance_outside(p - frame.irradiance[2].xyz, vec2f(464.0, 208.0), 0.03125);
	if (outside >= 1.0) {
		return base;
	}
	var r = vec4f(0.0);
	var g = vec4f(0.0);
	var b = vec4f(0.0);
	var validity = outside;
	// a level not filled yet counts as out of reach
	let f0 = select(1.0, irradiance_outside(p - frame.irradiance[0].xyz, vec2f(29.0, 13.0), 0.5), frame.irradiance[0].w > 0.5);
	if (f0 < 1.0) {
		let s = irradiance_level(0,(p * 2.0 + 0.5) / IRRADIANCE_TEXELS, false, 1.0 - f0);
		r += s.r;
		g += s.g;
		b += s.b;
		validity += s.validity;
	}
	let f1 = select(1.0, irradiance_outside(p - frame.irradiance[1].xyz, vec2f(116.0, 52.0), 0.125), frame.irradiance[1].w > 0.5);
	// weighted f0 · (1 − f1), so nothing inside level 0's box
	if (f1 < 1.0 && f0 > 0.0) {
		let s = irradiance_level(1,(p * 0.5 + 0.5) / IRRADIANCE_TEXELS, false, f0 * (1.0 - f1));
		r += s.r;
		g += s.g;
		b += s.b;
		validity += s.validity;
	}
	if (f1 > 0.0) {
		let s = irradiance_level(2,(p * 0.125 + 0.5) / IRRADIANCE_TEXELS, true, f1 * (1.0 - outside));
		r += s.r;
		g += s.g;
		b += s.b;
		validity += s.validity;
	}
	// the ambient probe fills in for missing validity; `band` is the game's vertical correction term
	let valid = clamp(validity * 2.0 - 1.0, 0.0, 1.0);
	let band = valid - outside;
	let fallback = (valid + outside) * 0.5;
	let k = frame.params.z;
	let sh = array<vec4f, 3>(r * k, g * k, b * k);
	var c = vec3f(0.0);
	for (var i = 0; i < 3; i++) {
		let d = frame.sh[i];
		let corrected = sh[i] + vec4f(0.0, d.w * band * 0.5, 0.0, d.y * band * 0.375);
		c[i] = dot(corrected.xyz, n) + corrected.w;
	}
	return max(c + base * fallback, vec3f(0.0));
}

// the game's scale on a sky reflection, from the surface's diffuse irradiance against the sky probe's L1 along the
// normal (docs/game-data/lighting.md#ambient)
fn reflection_normalisation(irradiance: vec3f, n: vec3f) -> f32 {
	let d = dot(irradiance, LUMINANCE);
	let sky = LUMINANCE.x * frame.sh[0] + LUMINANCE.y * frame.sh[1] + LUMINANCE.z * frame.sh[2];
	let p = max(1e-4, dot(sky, vec4f(n, 1.0)));
	return (2.0 * clamp(d / p, 0.0, 1.0) + d) / (2.0 + p);
}

// height-correlated Smith visibility (Heitz), V = G / (4 n·l n·v)
fn smith_visibility(n_dot_v: f32, n_dot_l: f32, a2: f32) -> f32 {
	let v = n_dot_l * sqrt(n_dot_v * n_dot_v * (1.0 - a2) + a2);
	let l = n_dot_v * sqrt(n_dot_l * n_dot_l * (1.0 - a2) + a2);
	return 0.5 / max(v + l, 1e-5);
}

// Karis' analytic fit of the split-sum environment BRDF: the scale on f0 and the bias (on f90)
fn environment_brdf_terms(roughness: f32, n_dot_v: f32) -> vec2f {
	let c0 = vec4f(-1.0, -0.0275, -0.572, 0.022);
	let c1 = vec4f(1.0, 0.0425, 1.04, -0.04);
	let r = roughness * c0 + c1;
	let a004 = min(r.x * r.x, exp2(-9.28 * n_dot_v)) * r.x + r.y;
	return vec2f(-1.04, 1.04) * a004 + r.zw;
}

// the environment BRDF with f90 = 1
fn environment_brdf(f0: vec3f, roughness: f32, n_dot_v: f32) -> vec3f {
	let ab = environment_brdf_terms(roughness, n_dot_v);
	return f0 * ab.x + ab.y;
}

// #region local lights

// the first mask word of a pixel's screen tile and of its view-depth slice in `light_bins`, or x = 0xffffffff
// where no light can reach (no lights, or past the last slice). the `LIGHT_` constants come from local-lights.ts
fn light_bin_words(px: vec2f, rel: vec3f) -> vec2u {
	let count = u32(frame.local_lights.x);
	let depth = dot(rel, frame.view_forward.xyz) - frame.local_lights.w;
	if (count == 0u || depth < 0.0 || depth >= LIGHT_SLICES) {
		return vec2u(0xffffffffu, 0u);
	}
	let tiles = vec2u(frame.local_lights.yz);
	let tile = min(vec2u(max(px, vec2f(0.0)) / LIGHT_TILE_SIZE), tiles - 1u);
	return vec2u((tile.y * tiles.x + tile.x) * LIGHT_MASK_WORDS, (tiles.x * tiles.y + u32(depth)) * LIGHT_MASK_WORDS);
}

// what reaches a camera-relative point from one local light, before the BRDF
struct LocalLight {
	// from the point to the light
	to_light: vec3f,
	// distance falloff × cone × culling box; 0 where the light doesn't reach
	attenuation: f32,
	// a tube's ends relative to the point (zero for points and spots)
	a: vec3f,
	b: vec3f,
}

// the game's punctual light falloff: the culling box's fade, inverse square in a smooth window (or a power of
// the window with a falloff exponent), a tube's integrated inverse square, and a spot's squared cone
fn local_light_at(i: u32, rel: vec3f) -> LocalLight {
	let base = i * LIGHT_VEC4S;
	let p = lights[base];
	let d = lights[base + 2u];
	let e = lights[base + 3u];
	let g = lights[base + 4u];
	var out: LocalLight;
	out.to_light = p.xyz - rel;
	out.attenuation = 0.0;
	out.a = vec3f(0.0);
	out.b = vec3f(0.0);
	var box = 1.0;
	if (g.w > 0.5) {
		let q = vec4f(-out.to_light, 1.0);
		let m = max(abs(dot(lights[base + 5u], q)), max(abs(dot(lights[base + 6u], q)), abs(dot(lights[base + 7u], q))));
		let k = g.z * 0.5;
		box = 1.0 - clamp((m - (0.5 + k)) / max(0.5 - k, 1e-4), 0.0, 1.0);
		box *= box;
		if (box < 0.001) {
			return out;
		}
	}
	let d2 = dot(out.to_light, out.to_light);
	let x = d2 * p.w * p.w;
	if (x >= 1.0) {
		return out;
	}
	let spot = lights[base + 1u].w < 0.5;
	var tube = 1.0;
	let tube_length = select(e.y, 0.0, spot);
	if (tube_length > 0.0) {
		let segment = d.xyz * tube_length;
		out.a = out.to_light - segment * 0.5;
		out.b = out.to_light + segment * 0.5;
		tube = 1.0 / ((length(out.a) * length(out.b) + dot(out.a, out.b)) * 0.5 + 1.0);
	}
	var attenuation: f32;
	if (e.z < 0.0) {
		let window = clamp(1.0 - x * x, 0.0, 1.0);
		attenuation = select(1.0 / (d2 + 1.0), tube, tube_length > 0.0) * window * window;
	} else {
		attenuation = tube * pow(1.0 - x, e.z);
	}
	if (spot) {
		let cone = clamp((dot(out.to_light * inverseSqrt(max(d2, 1e-8)), -d.xyz) - d.w) * e.x, 0.0, 1.0);
		attenuation *= cone * cone;
	}
	out.attenuation = attenuation * box;
	return out;
}

// what a local light's shadow map lets through to a camera-relative point (docs/viewer/lighting.md#local-light-
// shadows): a spot looks its one tile up, a point light the tile of the cube face the point lies in. `n` is the
// surface normal the lookup is pushed along (zero in the fog), `to_light` runs from the point to the light
fn local_light_shadow(i: u32, rel: vec3f, n: vec3f, to_light: vec3f) -> f32 {
	let s = lights[i * LIGHT_VEC4S + 8u];
	if (s.x < 0.0 || s.y <= 0.0) {
		return 1.0;
	}
	let spot = lights[i * LIGHT_VEC4S + 1u].w < 0.5;
	var record = u32(s.x);
	if (!spot) {
		// faces in the order +X −X +Y −Y +Z −Z
		let d = -to_light;
		let a = abs(d);
		if (a.x >= a.y && a.x >= a.z) {
			record += select(1u, 0u, d.x > 0.0);
		} else if (a.y >= a.z) {
			record += select(3u, 2u, d.y > 0.0);
		} else {
			record += select(5u, 4u, d.z > 0.0);
		}
	}
	let base = LIGHT_SHADOW_RECORDS + record * LIGHT_SHADOW_VEC4S;
	let params = lights[base + 5u];
	if (params.w < 0.5) {
		return 1.0;
	}
	let m = mat4x4f(lights[base], lights[base + 1u], lights[base + 2u], lights[base + 3u]);
	// off the surface towards the light: the game's constant offset, plus about a texel where the point is
	let depth = (m * vec4f(rel, 1.0)).w;
	let side = select(-1.0, 1.0, dot(n, to_light) >= 0.0);
	let clip = m * vec4f(rel + n * (side * (params.y + params.x * depth * 1.5)), 1.0);
	if (clip.w <= 0.0) {
		return 1.0;
	}
	let p = clip.xyz / clip.w;
	if (any(p <= vec3f(0.0)) || any(p >= vec3f(1.0))) {
		return 1.0;
	}
	let rect = lights[base + 4u];
	let texel = 1.0 / vec2f(textureDimensions(light_shadow_map));
	// taps stay inside the tile
	let low = rect.xy + texel;
	let high = rect.xy + rect.zw - texel;
	let uv = rect.xy + p.xy * rect.zw;
	var sum = 0.0;
	for (var y = -1; y <= 1; y++) {
		for (var x = -1; x <= 1; x++) {
			let tap = clamp(uv + vec2f(f32(x), f32(y)) * texel, low, high);
			sum += textureSampleCompareLevel(light_shadow_map, shadow_sampler, tap, p.z);
		}
	}
	var strength = s.y;
	if (spot) {
		// fades out towards the far plane and the tile's edges
		let edge = min(min(p.x, p.y), min(1.0 - p.x, 1.0 - p.y));
		strength = min(strength, smoothstep(0.0, 0.05, min((params.z - clip.w) * 0.25, edge)));
	}
	return mix(1.0, sum / 9.0, strength);
}

// the local lights' direct light on a surface, with the game's lobe for them (and its sun): GGX without the 1/π,
// Lambert without the 1/π and without (1 − F), so in the units of the light's colour the result is
// `colour · (diffuse + π · specular)`. a soft source radius widens the lobe; a tube takes the point of the
// segment nearest the reflection for its specular. the game's multiple-scattering term is left out
// (docs/game-data/lighting.md#local-lights). foliage takes the two-sided model of `foliage_sun` from each light
// instead, in the same units: its specular faded for back views, light transmitted through the leaf and wrapped
// past the terminator, all under the material's own sun shadow
fn local_lighting(s: Surface, v: vec3f, rel: vec3f, px: vec2f, diffuse_color: vec3f, f0: vec3f, roughness: f32) -> vec3f {
	let n = s.normal;
	let words = light_bin_words(px, rel);
	if (words.x == 0xffffffffu) {
		return vec3f(0.0);
	}
	let count = u32(frame.local_lights.x);
	let n_dot_v = clamp(dot(n, v), 0.0, 1.0);
	let r = reflect(-v, n);
	var sum = vec3f(0.0);
	for (var w = 0u; w * 32u < count; w++) {
		var mask = light_bins[words.x + w] & light_bins[words.y + w];
		while (mask != 0u) {
			let i = w * 32u + firstTrailingBit(mask);
			mask &= mask - 1u;
			let light = local_light_at(i, rel);
			if (light.attenuation <= 0.0) {
				continue;
			}
			let e = lights[i * LIGHT_VEC4S + 3u];
			let tube_length = select(e.y, 0.0, lights[i * LIGHT_VEC4S + 1u].w < 0.5);
			let d2 = dot(light.to_light, light.to_light);
			let distance = sqrt(d2);
			var l = light.to_light / distance;
			var l_spec = l;
			var n_dot_l: f32;
			var norm = 1.0;
			if (tube_length > 0.0) {
				n_dot_l = clamp(0.5 * (dot(n, light.a) / length(light.a) + dot(n, light.b) / length(light.b)), 0.0, 1.0);
				let segment = light.b - light.a;
				let r_dot_s = dot(r, segment);
				let t = clamp(dot(light.a, r * r_dot_s - segment) / max(tube_length * tube_length - r_dot_s * r_dot_s, 1e-6), 0.0, 1.0);
				l_spec = normalize(light.a + segment * t);
				let r2 = roughness * roughness;
				norm = r2 / clamp(r2 + 0.5 * clamp(tube_length / distance, 0.0, 1.0), 1e-6, 1.0);
			} else {
				n_dot_l = clamp(dot(n, l), 0.0, 1.0);
			}
			// foliage is lit from behind too
			if (n_dot_l <= 0.0 && !s.foliage) {
				continue;
			}
			let h = normalize(l_spec + v);
			let n_dot_h = clamp(dot(n, h), 0.0, 1.0);
			let v_dot_h = clamp(dot(v, h), 0.0, 1.0);
			var a = roughness * roughness;
			let soft = clamp(e.w / distance, 0.0, 1.0);
			if (soft > 0.0) {
				a = clamp(a + soft * soft / (3.6 * v_dot_h + 0.4), 0.0, 1.0);
			}
			let a2 = a * a;
			let dd = n_dot_h * n_dot_h * (a2 - 1.0) + 1.0;
			let distribution = a2 / max(dd * dd, 1e-8);
			let visibility = 0.5 / (n_dot_l * sqrt(n_dot_v * n_dot_v * (1.0 - a2) + a2) + n_dot_v * sqrt(n_dot_l * n_dot_l * (1.0 - a2) + a2) + 1e-4);
			let f = fresnel_schlick(f0, v_dot_h);
			let g = lights[i * LIGHT_VEC4S + 4u];
			var lobe = min(f * (distribution * norm * visibility), vec3f(2048.0));
			var through = vec3f(0.0);
			var diffuse = diffuse_color;
			if (s.foliage) {
				let v_dot_l = dot(v, l_spec);
				let n_dot_l_signed = dot(n, l_spec);
				lobe *= mix(saturate(dot(n, v) + 0.2) * saturate(saturate(v_dot_l) + 0.5), 1.0, saturate(v_dot_l + 1.0)) *
					s.sun_shadow;
				let towards_light = saturate(-v_dot_l);
				let spread = (towards_light * 0.36 - towards_light) * towards_light + 1.0;
				let hue = diffuse_color / max(0.01, max(diffuse_color.r, max(diffuse_color.g, diffuse_color.b)));
				through = (hue * s.transmission * saturate(0.5 - n_dot_l_signed) * (0.36 / (spread * spread)) +
					diffuse_color * (saturate(n_dot_l_signed + s.subsurface) - n_dot_l)) * s.sun_shadow;
				diffuse *= s.sun_shadow;
			}
			let specular = clamp(lobe * g.x, vec3f(0.0), vec3f(1000.0));
			let shadow = local_light_shadow(i, rel, n, light.to_light);
			sum += ((specular + diffuse) * n_dot_l + through) * lights[i * LIGHT_VEC4S + 1u].rgb * (light.attenuation * shadow);
		}
	}
	return min(sum, vec3f(255.0));
}

// the local lights scattered towards the camera by the volumetric fog at a camera-relative point: each light's colour,
// falloff and per-light volumetric intensity through a Henyey-Greenstein phase of anisotropy `g` along `ray`
// (towards the point)
fn local_fog_lighting(rel: vec3f, px: vec2f, ray: vec3f, g: f32) -> vec3f {
	let words = light_bin_words(px, rel);
	if (words.x == 0xffffffffu) {
		return vec3f(0.0);
	}
	let count = u32(frame.local_lights.x);
	var sum = vec3f(0.0);
	for (var w = 0u; w * 32u < count; w++) {
		var mask = light_bins[words.x + w] & light_bins[words.y + w];
		while (mask != 0u) {
			let i = w * 32u + firstTrailingBit(mask);
			mask &= mask - 1u;
			let intensity = lights[i * LIGHT_VEC4S + 4u].y;
			if (intensity <= 0.0) {
				continue;
			}
			let light = local_light_at(i, rel);
			if (light.attenuation <= 0.0) {
				continue;
			}
			let phase = henyey_greenstein(g, dot(ray, normalize(light.to_light)));
			let shadow = local_light_shadow(i, rel, vec3f(0.0), light.to_light);
			sum += lights[i * LIGHT_VEC4S + 1u].rgb * (light.attenuation * phase * intensity * shadow);
		}
	}
	return sum;
}

// #endregion

// the game's two-sided foliage lighting for the sun, per unit of its illuminance before shadowing: Lambert
// diffuse at the surface's own N·L, GGX specular faded for grazing back views, light transmitted through the leaf
// towards a viewer looking at the sun (a GGX lobe of α² 0.36 about the light, in the albedo's hue), and diffuse
// wrapped past the terminator by the subsurface amount. all of it is darkened by the material's sun shadow
fn foliage_sun(s: Surface, n: vec3f, v: vec3f, l: vec3f, a2: f32, f0: vec3f, albedo: vec3f) -> vec3f {
	let n_dot_l_signed = dot(n, l);
	let n_dot_l = saturate(n_dot_l_signed);
	let n_dot_v = clamp(abs(dot(n, v)), 1e-4, 1.0);
	let v_dot_l = dot(v, l);
	let diffuse_n_dot_l = select(n_dot_l, s.sun_n_dot_l, s.sun_n_dot_l >= 0.0);
	var color = albedo * diffuse_n_dot_l;

	let h = normalize(l + v);
	let f = fresnel_schlick(f0, saturate(dot(v, h)));
	let back_view = mix(saturate(dot(n, v) + 0.2) * saturate(saturate(v_dot_l) + 0.5), 1.0, saturate(v_dot_l + 1.0));
	let specular = f * (ggx_distribution(saturate(dot(n, h)), a2) * smith_visibility(n_dot_v, n_dot_l, a2)) * back_view;
	color += specular * PI * frame.sun_color.w * n_dot_l;

	let towards_sun = saturate(-v_dot_l);
	let lobe = (towards_sun * 0.36 - towards_sun) * towards_sun + 1.0;
	let hue = albedo / max(0.01, max(albedo.r, max(albedo.g, albedo.b)));
	color += hue * s.transmission * saturate(0.5 - n_dot_l_signed) * (0.36 / (lobe * lobe));
	color += albedo * (saturate(n_dot_l_signed + s.subsurface) - n_dot_l);
	return color * s.sun_shadow / PI;
}

// sun (shadowed) plus ambient probe; `rel` is the camera-relative position
fn shade_surface(s: Surface, rel: vec3f, px: vec2f) -> Shaded {
	let n = s.normal;
	let v = -normalize(rel);
	let l = frame.sun.xyz;
	let n_dot_v = clamp(abs(dot(n, v)), 1e-4, 1.0);
	let n_dot_l = clamp(dot(n, l), 0.0, 1.0);
	let roughness = clamp(s.roughness, 0.045, 1.0);
	let a = roughness * roughness;
	let a2 = a * a;
	let diffuse_color = s.albedo * (1.0 - s.metallic);
	let f0 = mix(vec3f(s.f0), s.albedo, s.metallic);

	var direct = vec3f(0.0);
	if (s.foliage) {
		direct = foliage_sun(s, n, v, l, a2, f0, diffuse_color) * frame.sun_color.rgb * frame.sun.w *
			sun_visibility(rel, n, px);
	} else {
		let h = normalize(l + v);
		let n_dot_h = clamp(dot(n, h), 0.0, 1.0);
		let v_dot_h = clamp(dot(v, h), 0.0, 1.0);
		let f = fresnel_schlick(f0, v_dot_h);
		let specular = f * (ggx_distribution(n_dot_h, a2) * smith_visibility(n_dot_v, n_dot_l, a2)) * frame.sun_color.w;
		let diffuse = diffuse_color / PI * (vec3f(1.0) - f);
		direct = (diffuse + specular) * n_dot_l;
		// the shadow lookup only where the sun can reach
		var visibility = vec3f(0.0);
		if (n_dot_l > 0.0) {
			visibility = sun_visibility(rel, n, px);
		}
		direct *= frame.sun_color.rgb * visibility * frame.sun.w;
	}
	direct += local_lighting(s, v, rel, px, diffuse_color, f0, roughness);

	let irradiance = ambient_irradiance(frame.eye.xyz + rel, n);
	let diffuse_ambient = diffuse_color * irradiance;
	// specular sees only the material occlusion, through Lagarde's specular occlusion
	let specular_occlusion = clamp(pow(n_dot_v + s.occlusion, exp2(-16.0 * roughness - 1.0)) - 1.0 + s.occlusion, 0.0, 1.0);
	// a screen-space hit gets the environment BRDF and specular occlusion but not the sky's specular factor
	let ssr_weight = environment_brdf(f0, roughness, n_dot_v) * specular_occlusion;
	let specular_weight = ssr_weight * frame.ambient.x;
	var specular_ambient: vec3f;
	{
		let r = normalize(mix(reflect(-v, n), n, roughness * roughness));
		// without the cubemap, reflect the ambient probe (the sky's low-frequency radiance)
		var reflected = ambient_probe(r);
		if (frame.ambient.z > 0.5) {
			reflected = textureSampleLevel(reflection_map, reflection_sampler, r, roughness * frame.ambient.w).rgb;
		}
		specular_ambient = reflected * reflection_normalisation(irradiance, n) * specular_weight;
	}
	let ambient = diffuse_ambient * s.occlusion + specular_ambient;
	let albedo_luminance = dot(diffuse_color, LUMINANCE_ROUNDED);

	var out: Shaded;
	out.reflection = vec4f(0.0);
	out.reflection_surface = vec2u(0u);
	switch frame.flags.y {
		case 1u: {
			out.radiance = vec4f(s.albedo, 1.0);
			out.ambient = vec4f(0.0);
			return out;
		}
		case 2u: {
			out.radiance = vec4f(n * 0.5 + 0.5, 1.0);
			out.ambient = vec4f(0.0);
			return out;
		}
		case 3u: {
			out.radiance = vec4f(vec3f(roughness), 1.0);
			out.ambient = vec4f(0.0);
			return out;
		}
		case 4u: {
			out.radiance = vec4f(ambient, albedo_luminance);
			out.ambient = vec4f(diffuse_ambient, s.occlusion);
			return out;
		}
		default: {}
	}
	out.radiance = vec4f(direct + ambient + s.emission, albedo_luminance);
	out.ambient = vec4f(diffuse_ambient, s.occlusion);
	out.reflection = vec4f(specular_ambient, 0.0);
	out.reflection_surface = pack_reflection_surface(n, roughness, ssr_weight);
	return out;
}

// a flat colour that occlusion leaves alone (debug overlays)
fn unlit(color: vec3f) -> Shaded {
	var out: Shaded;
	out.radiance = vec4f(color, 1.0);
	out.ambient = vec4f(0.0);
	out.reflection = vec4f(0.0);
	out.reflection_surface = vec2u(0u);
	return out;
}

fn hue(h: f32) -> vec3f {
	let k = vec3f(0.0, 2.0 / 3.0, 1.0 / 3.0);
	return clamp(abs(fract(vec3f(h) + k) * 6.0 - 3.0) - 1.0, vec3f(0.0), vec3f(1.0));
}

// an instance row (`ROW_WORDS` and `RowWord` in instance-rows.ts): its transform's rows (w: translation from
// the block origin), its bounds' centre and half extents, its block word, info word (`RowKind`, `RowBillboard`),
// texture sheet word (`rowSheet`), colour (RGBA8, multiplying the mesh's vertex colours) and a particle's custom
// data (two f16 pairs)
struct InstanceRow {
	t0: vec4f,
	t1: vec4f,
	t2: vec4f,
	center: vec3f,
	block: u32,
	extent: vec3f,
	info: u32,
	sheet: u32,
	color: u32,
	custom: vec2u,
}

// a mesh's UV sets (xy: UV0, zw: UV1) remapped into the tile of an instance row's texture sheet word
// (`rowSheet` in instance-rows.ts). tiles count from the sheet's top-left; UV (0, 0) is its bottom-left
fn sheet_uv(sheet: u32, uv: vec4f) -> vec4f {
	let tiles = vec2u((sheet & 63u) + 1u, ((sheet >> 6u) & 63u) + 1u);
	let tile = (sheet >> 12u) & 4095u;
	let size = 1.0 / vec2f(tiles);
	let corner = vec2f(f32(tile % tiles.x), f32(tiles.y - 1u - min(tile / tiles.x, tiles.y - 1u))) * size;
	let uv0 = select(uv.xy, uv.xy * size + corner, (sheet & (1u << 24u)) != 0u);
	let uv1 = select(uv.zw, uv.zw * size + corner, (sheet & (1u << 25u)) != 0u);
	return vec4f(uv0, uv1);
}

// a particle row's custom data (`ParticleSystemInfo.customData`), zero for other rows
fn row_custom(row: InstanceRow) -> vec4f {
	return vec4f(unpack2x16float(row.custom.x), unpack2x16float(row.custom.y));
}

// an instance row's block slot, from its block word (`BLOCK_SLOT_BITS` from instance-rows.ts)
fn row_block(word: u32) -> u32 {
	return word & ((1u << BLOCK_SLOT_BITS) - 1u);
}

// an instance row's decal placement index in its block plus 1, or 0 for a row without one, from its block word
fn row_placement(word: u32) -> u32 {
	return word >> BLOCK_SLOT_BITS;
}

// the 3×3 part of an instance row's transform (rows t0–t2). a billboard row's (`RowBillboard` in
// instance-rows.ts, info bits 30–31) is relative to the camera's rotation (1), or to its heading about the
// vertical (2), so it turns to face the camera about its origin
fn row_basis(t0: vec4f, t1: vec4f, t2: vec4f, info: u32) -> mat3x3f {
	let m = mat3x3f(vec3f(t0.x, t1.x, t2.x), vec3f(t0.y, t1.y, t2.y), vec3f(t0.z, t1.z, t2.z));
	switch (info >> 30u) {
		case 1u: {
			return mat3x3f(frame.view_right.xyz, frame.view_up.xyz, frame.view_forward.xyz) * m;
		}
		case 2u: {
			// the camera's right stays level and defined even looking straight down; Unity's forward is right × up
			let right = normalize(vec3f(frame.view_right.x, 0.0, frame.view_right.z));
			let up = vec3f(0.0, 1.0, 0.0);
			return mat3x3f(right, up, cross(right, up)) * m;
		}
		default: {
			return m;
		}
	}
}
