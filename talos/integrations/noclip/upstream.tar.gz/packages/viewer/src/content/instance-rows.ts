/**
 * the GPU layout of instance rows, shared by the decode worker (which builds them) and the instance renderer
 * (whose WGSL `InstanceRow` mirrors it).
 *
 * @module
 */

import { AnimationFlags, AnimationKind, type AnimationBlob } from '@endfield-noclip/package-format/animation';
import type { ClothTable } from '@endfield-noclip/package-format/cloth';
import {
	type Chain,
	ChainFlags,
	type InstanceBlock,
	LOD_GROUP_FLOATS,
	pathOffset,
	type RowPath,
	SPIN_FLOATS,
} from '@endfield-noclip/package-format/instances';

/**
 * 32-bit words per row: transform (12), bounds centre + block word (4), half extents + info (4), then the
 * words {@link RowWord} names from the texture sheet on (4). frame.wgsl's `InstanceRow` mirrors it
 */
export const ROW_WORDS = 24;

/** where a row's words past its transform and bounds centre start */
export const RowWord = {
	/** the block slot and decal placement ({@link BLOCK_SLOT_BITS}) */
	block: 15,
	/** half extents, f32×3 */
	extent: 16,
	/** its {@link RowKind} in bits 0–2 and its {@link RowBillboard} in bits 30–31; the bits between are free */
	info: 19,
	/** the texture sheet tile its mesh's UVs are remapped into ({@link rowSheet}) */
	sheet: 20,
	/** RGBA8 that multiplies the mesh's vertex colours (`instance_color` in frame.wgsl); white for most rows */
	color: 21,
	/**
	 * two words of f16 pairs (xy, zw): a particle's custom data (`ParticleSystemInfo.customData`), which effect
	 * looks read ({@link packRowCustom}); zero for every other row
	 */
	custom: 22,
} as const;

/** the {@link RowWord.color} of a row that leaves its mesh's colours as they are */
const ROW_WHITE = 0xffff_ffff;

/**
 * bits of a row's block word that hold its block slot (`row_block` in frame.wgsl); the bits above hold its
 * decal placement's index in its block plus 1, or 0 for a row without one (`row_placement`)
 */
export const BLOCK_SLOT_BITS = 14;

/** block slots the block word can name */
export const BLOCK_SLOTS = 1 << BLOCK_SLOT_BITS;

/** bytes per row */
export const ROW_BYTES = ROW_WORDS * 4;

/** f32 per row in {@link InstanceRows.cull}: bounding radius, largest half extent */
export const CULL_FLOATS = 2;

/** what a row draws as, its info word; tiers 0–2 are HLOD tiers */
export const RowKind = {
	Hlod0: 0,
	Hlod1: 1,
	Hlod2: 2,
	Detail: 3,
	Global: 4,
} as const;

export type RowKind = (typeof RowKind)[keyof typeof RowKind];

/**
 * a row's texture sheet word ({@link RowWord.sheet}): the tile its mesh's UVs are remapped into (`sheet_uv`
 * in frame.wgsl), tiles across − 1 in bits 0–5, down − 1 in bits 6–11, the tile in bits 12–23, which UV sets
 * take the tile (bit 24 UV0, bit 25 UV1), and per-axis UV flips before tile remapping (bit 26 U, bit 27 V).
 * 0, a 1×1 unflipped sheet, leaves the UVs as they are
 *
 * @param tiles tiles across and down, 1–64 each
 * @param tile the tile, counted from the sheet's top-left along its rows
 * @param uvChannels bit 0 for UV0, bit 1 for UV1
 * @param flip bit 0 to flip U (`1 - u`), bit 1 to flip V (`1 - v`)
 * @returns the sheet word
 */
export const rowSheet = (
	tiles: readonly [number, number],
	tile: number,
	uvChannels: number,
	flip = 0,
): number =>
	((tiles[0] - 1) |
		((tiles[1] - 1) << 6) |
		((tile & 0xfff) << 12) |
		((uvChannels & 3) << 24) |
		((flip & 3) << 26)) >>>
	0;

const customHalves = new Float16Array(4);
const customWords = new Uint32Array(customHalves.buffer);

/**
 * @param custom a particle's four custom data values
 * @returns them as a row's two {@link RowWord.custom} words, each an f16 pair low half first, as WGSL's
 *   `unpack2x16float` reads them
 */
export const packRowCustom = (custom: ArrayLike<number>): [xy: number, zw: number] => {
	customHalves.set(custom);
	return [customWords[0], customWords[1]];
};

/**
 * how a row turns towards the camera (`row_basis` in frame.wgsl), in bits 30–31 of its info word: its
 * transform's rotation is relative to the camera's ({@link ChainFlags.BillboardFacing}), or to the camera's
 * heading about the vertical ({@link ChainFlags.BillboardUpright})
 */
export const RowBillboard = {
	None: 0,
	Facing: 1,
	Upright: 2,
} as const;

export type RowBillboard = (typeof RowBillboard)[keyof typeof RowBillboard];

/**
 * bit in {@link RowWord.info} marking a GPU-simulated cloth row (`row.custom` holds `[skeletonOffset,
 * singleSkeleton]`)
 */
export const ROW_CLOTH_BIT = 1 << 3;

/**
 * marks GPU-simulated cloth rows in their info and custom words, in place, from the package's cloth table
 *
 * @param built rows from {@link buildInstanceRows}; modified in place
 * @param table the package's cloth table, or `null` when the package has no simulated cloth
 */
export const markClothRows = (built: InstanceRows, table: ClothTable | null): void => {
	if (table === null || built.cloths === null) {
		return;
	}
	const { rows: clothRows, values } = built.cloths;
	const { rows } = built;
	for (let i = 0; i < clothRows.length; i++) {
		const entry = table.cloths[values[i]];
		if (entry === undefined) {
			continue;
		}
		const at = clothRows[i] * ROW_WORDS;
		rows[at + RowWord.info] = (rows[at + RowWord.info] | ROW_CLOTH_BIT) >>> 0;
		rows[at + RowWord.custom] = entry.skeletonOffset >>> 0;
		rows[at + RowWord.custom + 1] = entry.nodeCount > 256 ? 1 : 0;
	}
};

/**
 * marks the rows of billboard chains in their info words, in place, by the block's chain runs
 *
 * @param built rows from {@link buildInstanceRows}; their info words are modified
 * @param chains the package's chains
 */
export const markBillboardRows = (built: InstanceRows, chains: readonly Chain[]): void => {
	const { runs, rows } = built;
	for (let r = 0; r < runs.length; r += 3) {
		const flags = chains[runs[r]]?.flags ?? 0;
		let billboard: RowBillboard = RowBillboard.None;
		if (flags & ChainFlags.BillboardFacing) {
			billboard = RowBillboard.Facing;
		} else if (flags & ChainFlags.BillboardUpright) {
			billboard = RowBillboard.Upright;
		}
		if (billboard === RowBillboard.None) {
			continue;
		}
		for (let i = runs[r + 1], end = i + runs[r + 2]; i < end; i++) {
			const at = i * ROW_WORDS + RowWord.info;
			rows[at] = ((rows[at] & ~(3 << 30)) | (billboard << 30)) >>> 0;
		}
	}
};

/**
 * @param rgba linear colour and alpha, 0–1
 * @returns them as a row's RGBA8 {@link RowWord.color}
 */
export const packRowColor = (rgba: ArrayLike<number>): number => {
	let word = 0;
	for (let i = 0; i < 4; i++) {
		word |= Math.round(Math.min(Math.max(rgba[i], 0), 1) * 255) << (i * 8);
	}
	return word >>> 0;
};

/** a span of rows sharing a tier, as listed by the tree's HLOD refs */
export interface TierSpan {
	first: number;
	count: number;
	tier: number;
}

/** what an instance block's rows are: one kind for every row, or the tier spans of an HLOD block */
export type RowKinds = RowKind | readonly TierSpan[];

/** f32 per spinning row in {@link RowSpins.base}: its stored transform (12) and bounds centre (3) */
const SPIN_BASE_FLOATS = 15;

/** a block's spinning rows, which {@link turnRows} turns by the clock */
export interface RowSpins {
	/** the rows, ascending */
	rows: Uint32Array<ArrayBuffer>;
	/** `SPIN_FLOATS` per row, as the package stores them: pivot (relative to the block origin), axis, speed */
	values: Float32Array<ArrayBuffer>;
	/** {@link SPIN_BASE_FLOATS} per row: what the rows hold at time 0 */
	base: Float32Array<ArrayBuffer>;
	/**
	 * (first, end) pairs of row ranges that hold every spinning row, across gaps of up to
	 * {@link MOVING_RUN_GAP} rows: what's rewritten after {@link turnRows}
	 */
	runs: Uint32Array<ArrayBuffer>;
}

/** f32 per riding row in {@link RowRides.base}: its stored translation (3) and bounds centre (3) */
const RIDE_BASE_FLOATS = 6;

/** a block's rows riding paths, which {@link rideRows} moves by the clock. a row doesn't both spin and ride */
export interface RowRides {
	/** the rows, ascending */
	rows: Uint32Array<ArrayBuffer>;
	/** per row, the index into {@link paths} of the path it rides */
	pathOf: Uint32Array<ArrayBuffer>;
	/** {@link RIDE_BASE_FLOATS} per row: what the rows hold off their paths */
	base: Float32Array<ArrayBuffer>;
	/** (first, end) pairs of row ranges that hold every riding row, as {@link RowSpins.runs} */
	runs: Uint32Array<ArrayBuffer>;
	/** the block's paths */
	paths: RowPath[];
}

/** rows that hold still between two moving rows rewritten together rather than in two writes */
const MOVING_RUN_GAP = 8;

/** @returns the (first, end) runs of ascending moving rows, across gaps of up to {@link MOVING_RUN_GAP} rows */
const movingRuns = (rows: Uint32Array): Uint32Array<ArrayBuffer> => {
	const runs: number[] = [];
	for (const row of rows) {
		const last = runs.length - 1;
		if (last > 0 && row - runs[last] <= MOVING_RUN_GAP) {
			runs[last] = row + 1;
		} else {
			runs.push(row, row + 1);
		}
	}
	return new Uint32Array(runs);
};

/** an instance block laid out for the GPU */
export interface InstanceRows {
	count: number;
	origin: [x: number, y: number, z: number];
	/** `count × ROW_WORDS` words */
	rows: Uint32Array<ArrayBuffer>;
	/** `count × CULL_FLOATS` floats for CPU-side culling and LOD selection */
	cull: Float32Array<ArrayBuffer>;
	/** (chain, first, count) triples of equal-chain runs, for per-template instancing */
	runs: Uint32Array<ArrayBuffer>;
	/** the block's rect decal placements, `DECAL_PLACEMENT_FLOATS` each, in the order rows index them */
	placements: Float32Array<ArrayBuffer>;
	/** the block's spinning rows, or `null` when every row holds still */
	spins: RowSpins | null;
	/** the block's rows floating on a water volume, or `null` when none does */
	floaters: RowFloaters | null;
	/** the block's rows riding paths, or `null` when none does */
	rides: RowRides | null;
	/** `.anim` clip bindings from `MOTN`, or `null` when none */
	motions?: RowMotions | null;
	/** the block's GPU-simulated cloth rows and their cloth table indices, or `null` when none */
	cloths: RowCloths | null;
	/**
	 * for `.fol` grass blocks: packed `(firstRow, count, float32Bits(sparsity))` triples per cluster for
	 * progressive density thinning; `null` for `.inst` blocks
	 */
	foliageClusters?: Uint32Array<ArrayBuffer> | null;
}

/** a block's `.anim` motion clip bindings (`MOTN`) */
export interface RowMotions {
	/** the rows, ascending */
	rows: Uint32Array<ArrayBuffer>;
	/** per row: `[animBlob, float32Bits(phaseOffset)]` */
	values: Uint32Array<ArrayBuffer>;
	/** per row: base translation (3) and bounds centre (3) at t = 0 */
	base: Float32Array<ArrayBuffer>;
	/** (first, end) pairs of row ranges that hold every motion row */
	runs: Uint32Array<ArrayBuffer>;
}

/** a block's GPU-simulated cloth rows */
export interface RowCloths {
	/** the rows, ascending */
	rows: Uint32Array<ArrayBuffer>;
	/** per row, the index into `ClothTable.cloths` */
	values: Uint32Array<ArrayBuffer>;
}

/** a block's rows floating on water volumes, which follow their volume's surface up and down */
export interface RowFloaters {
	/** the rows, ascending */
	rows: Uint32Array<ArrayBuffer>;
	/** per row, the index into the package's water volumes of the volume it floats on */
	volumes: Uint32Array<ArrayBuffer>;
}

/**
 * rows as {@link ROW_WORDS} lays them out: transforms relative to the block origin, the bounds, the rows'
 * kinds, a 1×1 texture sheet, white and no custom data.
 *
 * the block slot is left 0; {@link assignBlockSlot} sets it once the block gets a slot.
 *
 * @param block decoded block
 * @param kinds the rows' kinds; rows outside every tier span become tier 0
 * @returns rows, cull data, chain runs and decal placements
 * @throws {RangeError} if the block has more decal placements than a block word can index
 */
export const buildInstanceRows = (block: InstanceBlock, kinds: RowKinds): InstanceRows => {
	const count = block.chains.length;
	const rows = new Uint32Array(count * ROW_WORDS);
	const f32 = new Float32Array(rows.buffer);
	const cull = new Float32Array(count * CULL_FLOATS);
	const rowKinds = new Uint8Array(count);
	if (typeof kinds === 'number') {
		rowKinds.fill(kinds);
	} else {
		for (const span of kinds) {
			rowKinds.fill(span.tier, span.first, span.first + span.count);
		}
	}
	for (let i = 0; i < count; i++) {
		const at = i * ROW_WORDS;
		const ex = block.bounds[i * 6 + 3];
		const ey = block.bounds[i * 6 + 4];
		const ez = block.bounds[i * 6 + 5];
		f32.set(block.transforms.subarray(i * 12, i * 12 + 12), at);
		f32[at + 12] = block.bounds[i * 6];
		f32[at + 13] = block.bounds[i * 6 + 1];
		f32[at + 14] = block.bounds[i * 6 + 2];
		f32[at + 16] = ex;
		f32[at + 17] = ey;
		f32[at + 18] = ez;
		rows[at + RowWord.info] = rowKinds[i];
		rows[at + RowWord.color] = ROW_WHITE;
		// from the f32-rounded extents, as the GPU sees them
		const fx = f32[at + 16];
		const fy = f32[at + 17];
		const fz = f32[at + 18];
		cull[i * CULL_FLOATS] = Math.sqrt(fx * fx + fy * fy + fz * fz);
		cull[i * CULL_FLOATS + 1] = Math.max(fx, fy, fz);
	}
	if (block.lodGroups !== undefined && block.lodGroups.rows.length > 0) {
		const { rows: lodRows, values: lodValues } = block.lodGroups;
		for (let k = 0; k < lodRows.length; k++) {
			const refSize = lodValues[k * LOD_GROUP_FLOATS + 3];
			if (refSize > 0) {
				cull[lodRows[k] * CULL_FLOATS + 1] = refSize * 0.5;
			}
		}
	}
	const { rows: decalRows, values } = block.decals;
	if (decalRows.length >= 2 ** (32 - BLOCK_SLOT_BITS)) {
		throw new RangeError(
			`an instance block has ${decalRows.length} decal placements, more than rows can index`,
		);
	}
	for (let p = 0; p < decalRows.length; p++) {
		rows[decalRows[p] * ROW_WORDS + RowWord.block] = ((p + 1) << BLOCK_SLOT_BITS) >>> 0;
	}

	const runs: number[] = [];
	for (let i = 0; i < count;) {
		const chain = block.chains[i];
		let end = i + 1;
		while (end < count && block.chains[end] === chain) {
			end++;
		}
		runs.push(chain, i, end - i);
		i = end;
	}
	let spins: RowSpins | null = null;
	if (block.spins.rows.length > 0) {
		const spinRows = new Uint32Array(block.spins.rows);
		const base = new Float32Array(spinRows.length * SPIN_BASE_FLOATS);
		for (let s = 0; s < spinRows.length; s++) {
			const at = spinRows[s] * ROW_WORDS;
			base.set(f32.subarray(at, at + SPIN_BASE_FLOATS), s * SPIN_BASE_FLOATS);
		}
		spins = {
			rows: spinRows,
			values: new Float32Array(block.spins.values),
			base,
			runs: movingRuns(spinRows),
		};
	}
	let rides: RowRides | null = null;
	if (block.rides.rows.length > 0) {
		const riding = new Uint32Array(block.rides.rows);
		const base = new Float32Array(riding.length * RIDE_BASE_FLOATS);
		for (let s = 0; s < riding.length; s++) {
			const at = riding[s] * ROW_WORDS;
			base.set(
				[f32[at + 3], f32[at + 7], f32[at + 11], f32[at + 12], f32[at + 13], f32[at + 14]],
				s * RIDE_BASE_FLOATS,
			);
		}
		rides = {
			rows: riding,
			pathOf: new Uint32Array(block.rides.values),
			base,
			runs: movingRuns(riding),
			paths: block.paths.map(({ frameRate, offsets }) => ({ frameRate, offsets: new Float32Array(offsets) })),
		};
	}
	let motions: RowMotions | null = null;
	if (block.motions !== undefined && block.motions.rows.length > 0) {
		const motionRows = new Uint32Array(block.motions.rows);
		const base = new Float32Array(motionRows.length * RIDE_BASE_FLOATS);
		for (let s = 0; s < motionRows.length; s++) {
			const at = motionRows[s] * ROW_WORDS;
			base.set(
				[f32[at + 3], f32[at + 7], f32[at + 11], f32[at + 12], f32[at + 13], f32[at + 14]],
				s * RIDE_BASE_FLOATS,
			);
		}
		motions = {
			rows: motionRows,
			values: new Uint32Array(block.motions.values),
			base,
			runs: movingRuns(motionRows),
		};
	}
	return {
		count,
		origin: block.origin,
		rows,
		cull,
		runs: new Uint32Array(runs),
		placements: new Float32Array(values),
		spins,
		floaters:
			block.floaters.rows.length === 0
				? null
				: { rows: new Uint32Array(block.floaters.rows), volumes: new Uint32Array(block.floaters.values) },
		rides,
		motions,
		cloths:
			block.cloths !== undefined && block.cloths.rows.length > 0
				? { rows: new Uint32Array(block.cloths.rows), values: new Uint32Array(block.cloths.values) }
				: null,
	};
};

/**
 * @param spins a block's spinning rows
 * @param rides its riding rows
 * @returns the rows either moves, ascending, or `null` when every row holds still
 */
export const movingRows = (spins: RowSpins | null, rides: RowRides | null): Uint32Array | null => {
	if (spins === null || rides === null) {
		return spins?.rows ?? rides?.rows ?? null;
	}
	// oxlint-disable-next-line unicorn/no-array-sort -- sorts a fresh array
	return Uint32Array.from(new Set([...spins.rows, ...rides.rows])).sort();
};

/**
 * sets the block slot of every row, keeping its placement index.
 *
 * @param rows rows from {@link buildInstanceRows}; modified in place
 * @param slot index into the per-frame block table, below {@link BLOCK_SLOTS}
 */
export const assignBlockSlot = (rows: Uint32Array, slot: number): void => {
	const keep = ~(BLOCK_SLOTS - 1);
	for (let at = RowWord.block; at < rows.length; at += ROW_WORDS) {
		rows[at] = ((rows[at] & keep) | slot) >>> 0;
	}
};

/** {@link rideRows}' offset, kept so moving allocates nothing */
const OFFSET: [number, number, number] = [0, 0, 0];

/**
 * moves a block's riding rows to where they are at `time`: each row's translation and bounds centre are its
 * stored ones plus its path's offset then
 *
 * @param rows the block's rows, as f32; the riding rows' translation and centre words are overwritten
 * @param rides the block's riding rows
 * @param time seconds of the viewer's clock
 */
export const rideRows = (rows: Float32Array, rides: RowRides, time: number): void => {
	const { rows: riding, pathOf, base, paths } = rides;
	let path = -1;
	for (let s = 0; s < riding.length; s++) {
		// neighbouring rows mostly ride one path
		if (pathOf[s] !== path) {
			path = pathOf[s];
			pathOffset(paths[path], time, OFFSET);
		}
		const b = s * RIDE_BASE_FLOATS;
		const at = riding[s] * ROW_WORDS;
		for (let axis = 0; axis < 3; axis++) {
			rows[at + axis * 4 + 3] = base[b + axis] + OFFSET[axis];
			rows[at + 12 + axis] = base[b + 3 + axis] + OFFSET[axis];
		}
	}
};

/** {@link turnRows}' rotation matrix and pivot, kept so turning allocates nothing */
const ROTATION = new Float64Array(9);
const PIVOT = new Float64Array(3);

const motionPhaseU32 = new Uint32Array(1);
const motionPhaseF32 = new Float32Array(motionPhaseU32.buffer);
const motionOffset: [x: number, y: number, z: number] = [0, 0, 0];

/**
 * advances rows bound to `.anim` clips (`MOTN`), returning whether any row was updated
 *
 * @param rows the block's rows as f32; updated in place
 * @param motions the block's `MOTN` bindings
 * @param time animation clock, s
 * @param clipOf returns a resident {@link AnimationBlob} by blob id, or `null` while streaming
 * @returns whether at least one row was animated by a resident clip
 */
export const animateMotionRows = (
	rows: Float32Array,
	motions: RowMotions,
	time: number,
	clipOf: (blob: number) => AnimationBlob | null,
): boolean => {
	const { rows: motionRows, values, base } = motions;
	let updated = false;
	for (let s = 0; s < motionRows.length; s++) {
		const clip = clipOf(values[s * 2]);
		if (clip === null || clip.kind !== AnimationKind.Transform) {
			continue;
		}
		if ((clip.flags & AnimationFlags.TranslationOnly) === 0 || clip.frameCount === 0) {
			continue;
		}
		motionPhaseU32[0] = values[s * 2 + 1];
		pathOffset({ frameRate: clip.frameRate, offsets: clip.frames }, time + motionPhaseF32[0], motionOffset);
		const b = s * RIDE_BASE_FLOATS;
		const at = motionRows[s] * ROW_WORDS;
		rows[at + 3] = base[b] + motionOffset[0];
		rows[at + 7] = base[b + 1] + motionOffset[1];
		rows[at + 11] = base[b + 2] + motionOffset[2];
		rows[at + 12] = base[b + 3] + motionOffset[0];
		rows[at + 13] = base[b + 4] + motionOffset[1];
		rows[at + 14] = base[b + 5] + motionOffset[2];
		updated = true;
	}
	return updated;
};

/**
 * turns a block's spinning rows to where they are at `time`: each row's transform and bounds centre are its
 * stored ones turned `speed · time` radians about its axis through its pivot. the half extents stay the
 * stored ones, so a row's bounding sphere (centre, |extents|) still holds it
 *
 * @param rows the block's rows, as f32; the spinning rows' transform and centre words are overwritten
 * @param spins the block's spinning rows
 * @param time seconds of the viewer's clock
 */
export const turnRows = (rows: Float32Array, spins: RowSpins, time: number): void => {
	const { rows: spinRows, values, base } = spins;
	const r = ROTATION;
	const pivot = PIVOT;
	for (let s = 0; s < spinRows.length; s++) {
		const v = s * SPIN_FLOATS;
		const px = values[v];
		const py = values[v + 1];
		const pz = values[v + 2];
		const ax = values[v + 3];
		const ay = values[v + 4];
		const az = values[v + 5];
		const angle = values[v + 6] * time;
		// Rodrigues' rotation, as Unity's Quaternion.AngleAxis turns: R = cos·I + sin·[a]× + (1 − cos)·aaᵀ
		const c = Math.cos(angle);
		const sn = Math.sin(angle);
		const k = 1 - c;
		r[0] = c + k * ax * ax;
		r[1] = k * ax * ay - sn * az;
		r[2] = k * ax * az + sn * ay;
		r[3] = k * ay * ax + sn * az;
		r[4] = c + k * ay * ay;
		r[5] = k * ay * az - sn * ax;
		r[6] = k * az * ax - sn * ay;
		r[7] = k * az * ay + sn * ax;
		r[8] = c + k * az * az;
		pivot[0] = px;
		pivot[1] = py;
		pivot[2] = pz;
		const b = s * SPIN_BASE_FLOATS;
		const at = spinRows[s] * ROW_WORDS;
		for (let i = 0; i < 3; i++) {
			for (let j = 0; j < 3; j++) {
				rows[at + i * 4 + j] =
					r[i * 3] * base[b + j] + r[i * 3 + 1] * base[b + 4 + j] + r[i * 3 + 2] * base[b + 8 + j];
			}
			let t = pivot[i];
			let centre = pivot[i];
			for (let j = 0; j < 3; j++) {
				t += r[i * 3 + j] * (base[b + j * 4 + 3] - pivot[j]);
				centre += r[i * 3 + j] * (base[b + 12 + j] - pivot[j]);
			}
			rows[at + i * 4 + 3] = t;
			rows[at + 12 + i] = centre;
		}
	}
};
