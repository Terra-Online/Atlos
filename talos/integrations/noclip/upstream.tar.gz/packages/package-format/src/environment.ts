import type { AnimationCurve, Gradient } from './curves.ts';
import type { TextureRef } from './textures.ts';
import type { Color, Mat3, Vec2, Vec3, Vec4 } from './values.ts';

/**
 * one environment in effect: every section of an `HGEnvironmentPhase` (`EnvParse/Env_*.asset`) plus the
 * post-processing profile of the level's global `Volume`, as a viewer blends them from a level's base phase
 * (`LevelEnvironment`) and the volumes applying over it. each section is the game's `HG*Config` with the
 * game's field names: colours as {@link Color}, vectors as arrays, `SphericalHarmonicsL2` as 27 numbers in
 * the game's order, flags as booleans, nested structs as objects, textures as {@link TextureRef}s and
 * materials as {@link EnvironmentMaterial}s. colour curves, editor state and other object references are left
 * out
 */
export interface EnvironmentProfile {
	/** the level phase's asset name, e.g. `Env_map02_lv001_art_Global_01` */
	name: string;
	light: LightConfig;
	sky: SkyConfig;
	atmosphere: AtmosphereConfig;
	fog: FogConfig;
	heightFog: HeightFogConfig;
	volumetricFog: VolumetricFogConfig;
	cloud: CloudConfig;
	wind: WindConfig;
	lightShaft: LightShaftConfig;
	colorGrading: ColorGradingConfig;
	autoExposure: AutoExposureConfig;
	shadow: ShadowConfig;
	celestial: CelestialConfig;
	star: StarConfig;
	rain?: RainConfig;
	lensFlare?: LensFlareConfig;
	/** the level's global post-processing volume, or `null` if it has none */
	post: PostProfile | null;
}

/** the sections of an environment phase, as in {@link EnvironmentProfile} */
export type EnvironmentSections = Omit<EnvironmentProfile, 'name' | 'post'>;

/**
 * how a field lerps between two phases below full strength: `lerp` linearly (every number of a colour, vector
 * or SH), `round` linearly to the nearest whole number (integer counts and amounts), `switch` to the other
 * side's value at ½ (enums, flags, strings, textures, materials and lens flares)
 */
export type FieldBlend = 'lerp' | 'round' | 'switch';

/** per field of a section, how it blends; nested structs have their own. fields not listed switch */
export interface BlendSchema {
	[field: string]: FieldBlend | BlendSchema;
}

/** per phase section, how its fields blend, from the fields' types in the game's TypeTree */
export type EnvironmentSchema = Record<keyof EnvironmentSections, BlendSchema>;

/**
 * `tables/environment.json.zst`: the scene's environment volumes and everything they apply. phases share
 * their sections through per-section pools, since most phases repeat most sections of others
 */
export interface EnvironmentTable {
	/** levels' post-processing profiles, deduplicated; `LevelEnvironment.post` indexes this list */
	posts: PostProfile[];
	/** how the phases' fields blend */
	schema: EnvironmentSchema;
	/** per section, every distinct value a phase holds; {@link EnvironmentPhaseEntry.sections} index these */
	sections: EnvironmentSectionPools;
	/** every phase a volume applies; {@link EnvironmentVolumeInfo.phase} indexes this list */
	phases: EnvironmentPhaseEntry[];
	/** the scene's environment volumes, for blending at the camera */
	volumes: EnvironmentVolumeInfo[];
	/** the 3D noise the height fog's flow noise samples (one channel), or `null` if the install lacks it */
	flowNoise: TextureRef;
}

/** per section, the distinct values phases hold */
export type EnvironmentSectionPools = {
	[K in keyof EnvironmentSections]-?: NonNullable<EnvironmentSections[K]>[];
};

/** an {@link EnvironmentPhaseInfo} as stored: its sections as indices into {@link EnvironmentTable.sections} */
export interface EnvironmentPhaseEntry {
	name: string;
	active: (keyof EnvironmentSections)[];
	/** per section the phase holds, its index in the section's pool */
	sections: { [K in keyof EnvironmentSections]?: number };
}

/** an {@link EnvironmentTable} with its phases' sections looked up */
export interface ResolvedEnvironmentTable extends Omit<EnvironmentTable, 'sections' | 'phases'> {
	phases: EnvironmentPhaseInfo[];
}

/**
 * @param table a package's environment table
 * @returns the table with each phase's sections looked up in the pools; phases share section objects
 */
export const resolveEnvironment = (table: EnvironmentTable): ResolvedEnvironmentTable => {
	const { sections: pools, phases, ...rest } = table;
	return {
		...rest,
		phases: phases.map(({ name, active, sections }) => {
			const resolved: Partial<Record<keyof EnvironmentSections, unknown>> = {};
			for (const [key, index] of Object.entries(sections)) {
				// oxlint-disable-next-line typescript/no-unsafe-type-assertion -- entries of a section-keyed object
				const section = key as keyof EnvironmentSections;
				resolved[section] = pools[section][index];
			}
			// oxlint-disable-next-line typescript/no-unsafe-type-assertion -- every section a phase holds was looked up
			return { name, active, sections: resolved as EnvironmentSections };
		}),
	};
};

/**
 * an `HGEnvironmentPhase` as the environment volumes apply it: its own sections, uncomposed. sections it
 * marks inactive leave what's under them unchanged
 */
export interface EnvironmentPhaseInfo {
	/** the asset name, e.g. `Env_map02_lv006_jian2_key` */
	name: string;
	/** the sections the phase sets */
	active: (keyof EnvironmentSections)[];
	sections: EnvironmentSections;
}

/** where an environment volume applies, in the Unity world frame */
export type EnvironmentVolumeShape =
	| { kind: 'global' }
	/**
	 * an oriented box: a world point `p` is at `toBox · (p − center)` in the box's frame, where it spans
	 * `±halfExtents`. `toBox` is a rotation, row-major
	 */
	| { kind: 'box'; center: Vec3; toBox: Mat3; halfExtents: Vec3 }
	/** a vertical prism over a closed polygon in world x, z, from `bottom` to `top` (world y) */
	| { kind: 'prism'; points: Vec2[]; bottom: number; top: number };

/**
 * how strongly a volume applies while it holds the camera (the game's `EnvBlendMode`):
 *
 * - `replace`: fully
 * - `depth`: by how deep inside the camera is, `clamp(distance to the edge / distance)`; a global volume fully
 * - `fade`: fading in over `fadeIn` seconds while the camera is inside and out over `fadeOut` once it leaves
 *   (instantly when the camera moves over 5 m in a frame)
 * - `scripted`: by a factor a level script sets, which isn't followed: fully while its control is on
 */
export type EnvironmentBlend =
	| { kind: 'replace' }
	| { kind: 'depth'; distance: number }
	| { kind: 'fade'; fadeIn: number; fadeOut: number }
	| { kind: 'scripted' };

/**
 * an `HGEnvironmentVolume`. the game blends them at the camera each frame (`HGEnvironmentManager`): starting
 * from the default phase, volumes in ascending order of priority (then shape: global, box, prism) that
 * contain the camera apply their phase, as strongly as their {@link EnvironmentBlend} says
 */
export interface EnvironmentVolumeInfo {
	/** the object's name */
	name: string;
	/**
	 * index into `StatesInfo.groups`: the owning level (none for scene-wide), the scene states that load it,
	 * and its {@link control}. a volume applies wherever it holds the camera, whichever level is shown, once its
	 * condition holds
	 */
	group: number;
	/**
	 * index into `StatesInfo.controls` of the `environmentVolume` control that switches it, which its group
	 * requires on; `null` for a volume without a phase, which never applies. a `scripted` volume defaults off,
	 * since the script that fades it in isn't followed, and previews at full strength when on
	 */
	control: number | null;
	shape: EnvironmentVolumeShape;
	blend: EnvironmentBlend;
	priority: number;
	/** index into {@link EnvironmentTable.phases}, or `null` if the phase is unset or unreadable */
	phase: number | null;
}

/**
 * `HGLightConfig`: the sun. physical units: `directLux` is illuminance and `directEV100` the exposure, so
 * `preExposure = 1 / (1.2 · 2^directEV100)`. every effect that draws the sun has its own direction:
 * `<effect>PitchYawMode` 0 follows `directPitchYaw`, 1 uses `<effect>PitchYaw`. the fields the game derives
 * from these (the precomputed intensities, the sun's frame and the effects' rotation quaternions) are left
 * out, since some phases carry them stale
 */
export interface LightConfig {
	/** the colour in effect: `directCustomColor` or the temperature's, per `directColorMode` */
	directColor: Color;
	directColorMode: number;
	directCustomColor: Color;
	/** kelvin */
	directColorTemperature: number;
	directLux: number;
	directEV100: number;
	directSpecularIntensity: number;
	directSoftSourceRadius: number;
	directDirectionMode: number;
	/** degrees: elevation, then azimuth */
	directPitchYaw: Vec2;
	timeOfDayYawOffset: number;
	timeOfDayPitchMax: number;
	indirectDiffuseFactor: number;
	indirectSpecularFactor: number;
	indirectSpecularFactorType: number;
	atmospherePitchYawMode: number;
	atmospherePitchYaw: Vec2;
	lightShaftPitchYawMode: number;
	lightShaftPitchYaw: Vec2;
	sunDiscPitchYawMode: number;
	sunDiscPitchYaw: Vec2;
	lensFlarePitchYawMode: number;
	lensFlarePitchYaw: Vec2;
	cloudShadowPitchYawMode: number;
	cloudShadowPitchYaw: Vec2;
	heightFogDirectionalInscatteringPitchYawMode: number;
	heightFogDirectionalInscatteringPitchYaw: Vec2;
	bakedIndirectMultiplier: number;
	giBakedIndirectMultiplier: number;
}

/** `HGSkyConfig`: sky luminance, ambient light and reflections */
export interface SkyConfig {
	skyDistance: number;
	useSkyDistanceForBakeFogLut: boolean;
	skyBakedIndirectIntensity: number;
	skyDirectIntensity: number;
	giSkyMultiplier: number;
	useCustomIVDefaultSH: boolean;
	/**
	 * an ambient SH, presumably used outside irradiance-volume coverage when {@link useCustomIVDefaultSH} is set
	 * (unverified)
	 */
	customIVDefaultSH: number[];
	skyMaterialType: number;
	proceduralSkyLuxFactor: number;
	enableSunDisc: boolean;
	sunDiscRadius: number;
	sunDiscRampIntensity: number;
	sunDiscColor: Color;
	skyboxBrightness: number;
	skyboxTintColor: Color;
	/** degrees */
	skyboxRotation: number;
	visibleBox: Vec3;
	reflectionType: number;
	/** the sky reflection cubemap (BC6H) */
	reflectionMap: TextureRef;
	culloff: number;
	/**
	 * ambient light, Unity `SphericalHarmonicsL2` order: 9 coefficients of red, then green, then blue.
	 * presumably scaled by {@link LightConfig.indirectDiffuseFactor}; how the game combines them is unknown
	 */
	skyAmbientSH: number[];
	skyboxCubeMap: TextureRef;
}

/** `HGAtmosphereConfig`: physically based sky (Hillaire-style); distances in km */
export interface AtmosphereConfig {
	groundRadius: number;
	groundAlbedo: Color;
	outerSunIrradianceColor: Color;
	atmosphereHeight: number;
	multiScatteringFactor: number;
	rayleighScatteringScale: number;
	rayleighScattering: Color;
	rayleighExponentialDistribution: number;
	mieScatteringScale: number;
	mieScattering: Color;
	mieAbsorptionScale: number;
	mieAbsorption: Color;
	mieAnisotropy: number;
	mieExponentialDistribution: number;
	ozoneAbsorptionScale: number;
	ozoneAbsorption: Color;
	tentTipAltitude: number;
	tentTipValue: number;
	tentWidth: number;
}

/** `HGFogConfig`: distance fog (aerial perspective) */
export interface FogConfig {
	enable: boolean;
	startDistance: number;
	startHeight: number;
	fallOffHeight: number;
	fallOffDistance: number;
	mieScattering: Color;
	mieScatteringScale: number;
	mieAnisotropy: number;
	rayleighScattering: Color;
	rayleighScatteringScale: number;
	inscatterAmbientColor: Color;
}

/** the two exponential height-fog layers and their froxel-fog parameters, shared by both height-fog sections */
export interface HeightFogLayers {
	enable: boolean;
	heightFogStartHeight: number;
	heightFogDensity: number;
	heightFogFalloff: number;
	heightFogStartHeightSecond: number;
	heightFogDensitySecond: number;
	heightFogFalloffSecond: number;
	heightFogInscatter: Color;
	heightFogMaxOpacity: number;
	heightFogStartDistance: number;
	heightFogStartTransition: number;
	heightFogCutoffDistance: number;
	heightFogCutoffTransition: number;
	heightFogDirectionalInscatteringExponent: number;
	heightFogDirectionalInscatteringStartDistance: number;
	heightFogDirectionalInscattering: Color;
	volumetricFogScatteringDistribution: number;
	volumetricFogAlbedo: Color;
	volumetricFogEmissive: Color;
	volumetricFogExtinctionScale: number;
	volumetricFogDistance: number;
	volumetricFogStartDistance: number;
	volumetricFogNearFadeInDistance: number;
	volumetricFogDirectLightingScatteringIntensity: number;
	volumetricFogSkyLightingScatteringIntensity: number;
	enableFlowNoise: boolean;
	flowNoiseIntensity: number;
	flowNoiseDistance: number;
	flowNoiseTilling: number;
	flowNoiseHorizontalDirAngle: number;
	flowNoiseVerticalDirAngle: number;
	flowNoiseDir: Vec3;
	flowNoiseSpeed: number;
}

/** `HGHeightFogConfig`: analytic height fog */
export interface HeightFogConfig extends HeightFogLayers {
	heightFogCullingFarClipPlane: number;
	heightFogDirectionalInscatteringExponentMobile: number;
	heightFogDirectionalInscatteringMobile: Color;
	enableVolumetricFog: boolean;
}

/** `HGVolumetricFogConfig`: froxel volumetric fog */
export interface VolumetricFogConfig extends HeightFogLayers {
	enableVLFlowNoise: boolean;
	flowVLNoise3DTexture: TextureRef;
	enableTwoParameter: boolean;
	flowVLNoiseIntensity: number;
	flowVLNoiseRemapRange: Vec2;
	flowVLNoiseDistance: number;
	flowVLNoiseTilling: number;
	flowVLNoiseTillingScale: Vec3;
	flowVLNoiseHorizontalDirAngle: number;
	flowVLNoiseVerticalDirAngle: number;
	flowVLNoiseDir: Vec3;
	flowVLNoiseSpeed: number;
	flowVLNoisePerturb3DTexture: TextureRef;
	flowVLNoisePerturbTilling: number;
	flowVLNoisePerturbIntensity: number;
	flowVLNoisePerturbSpeed: Vec3;
}

/** `HGCloudShadowConfig` */
export interface CloudShadowConfig {
	cloudShadowTexture: TextureRef;
	cloudShadowEnvCenter: Vec3;
	cloudShadowCoverage: number;
	cloudShadowFlowSpeed: number;
	cloudShadowFlowDirection: Vec2;
	cloudShadowAlpha: number;
	cloudShadowDistanceScale: number;
	cloudShadowScaleStartDistance: number;
	cloudShadowScaleEndDistance: number;
	enableFarCloudShadowTexture: boolean;
	cloudShadowFarEnvCenter: Vec3;
	cloudShadowFarCoverage: number;
	cloudShadowFarFlowSpeed: number;
	cloudShadowFarFlowDirection: Vec2;
}

/** `HGCloudConfig`: the panoramic cloud layer and cloud shadows */
export interface CloudConfig {
	enable: boolean;
	cloudTexture: TextureRef;
	cloudTint: Color;
	cloudContrast: number;
	lightAffectCloud: boolean;
	cloudBrightness: number;
	cloudAbsoluteBrightness: number;
	brightnessAffectCloudAlpha: boolean;
	drawCloudAfterPlanet: boolean;
	cloudTextureMode: number;
	cloudOpacityR: number;
	cloudOpacityG: number;
	cloudFlowType: number;
	/** degrees */
	rotation: number;
	cloudFlowMap: TextureRef;
	flowSpeed: number;
	flowDirectionX: number;
	flowDirectionY: number;
	enableLightShaftCloudMask: boolean;
	lightShaftCloudMaskTexture: TextureRef;
	enableCloudShadow: boolean;
	cloudShadowConfig: CloudShadowConfig;
	cloudFadeAlpha: number;
}

/**
 * a material an environment section draws with (the celestial bodies'), flattened: its shader's name and its
 * properties under Unity's names
 */
export interface EnvironmentMaterial {
	/** e.g. `HGRP/SkydomeStar` */
	shader: string;
	/** enabled keywords, space-separated as in Unity's `m_ShaderKeywords` */
	keywords: string;
	/**
	 * every float, range and int property the shader declares, with the material's value or the declared
	 * default; properties left from the material's earlier shaders are dropped. a shader that declares nothing
	 * keeps the material's values as stored
	 */
	floats: Record<string, number>;
	/** every colour and vector property the shader declares, as for {@link floats} */
	colors: Record<string, Color>;
	/** texture slots the shader declares that resolved, by property name */
	textures: Record<string, TextureRef>;
	/** texture scale (xy) and offset (zw) per slot, as the material stores them */
	textureTransforms: Record<string, Vec4>;
}

/** `RingProperty`: a planet's ring, in the planet's radius units */
export interface RingProperty {
	outerRadius: number;
	width: number;
	ringColor: Color;
	planetRingMap: TextureRef;
}

/** `CelestialObjectProperty` */
export interface CelestialObjectProperty {
	radius: number;
	/** degrees */
	selfTiltX: number;
	selfTiltZ: number;
	selfRotationY: number;
}

/** `CelestialDrawer`: how a body is painted on the sky dome */
export interface CelestialDrawer {
	drawMode: number;
	drawMaterial: EnvironmentMaterial | null;
	/** degrees: where on the sky the body sits */
	pitchYaw: Vec2;
	/** degrees: where its light comes from */
	incidentLightingPitchYaw: Vec2;
}

/** `AtmosphereProperty`: a body's atmosphere rim */
export interface AtmosphereProperty {
	bakeFaceVisibility: boolean;
	atmosphereHeight: number;
	numInscatteredSamplePoints: number;
	numOpticalDepthSamplePoints: number;
	coff_R: number;
	heightScale_R: number;
	atmosphereBrightness: number;
	atmosphereHueshift: number;
}

/** `HGCelestialAtmosphereObjectConfig`: a planet painted on the sky dome */
export interface CelestialAtmosphereObjectConfig {
	drawPlanetInSkydome: boolean;
	drawPlanetBelowHorizon: boolean;
	objectProperty: CelestialObjectProperty;
	skydomeDrawer: CelestialDrawer;
	enableRing: boolean;
	ring: RingProperty;
	enableAtmosphere: boolean;
	atmosphere: AtmosphereProperty;
}

/** `HGCelestialObjectConfig`: the procedural moon */
export interface CelestialObjectConfig {
	radius: number;
	orbitRadius: number;
	enableRing: boolean;
	drawPlanetBelowHorizon: boolean;
	worldLongitude: number;
	worldLatitude: number;
	rotationAroundUp: number;
	ring: RingProperty;
}

/** `HGCelestialAdvancedObjectConfig`: a ray-traced planet with its own material */
export interface CelestialAdvancedObjectConfig {
	drawAdvancedPlanet: boolean;
	advancedPlanetMat: EnvironmentMaterial | null;
}

/** `HGCelestialConfig`: planets and moons in the sky */
export interface CelestialConfig {
	moonConfig: CelestialObjectConfig;
	/** the smaller planet */
	talosAlphaConfig: CelestialAtmosphereObjectConfig;
	/** Talos-II as seen from its surface */
	planetConfig: CelestialAtmosphereObjectConfig;
	advancedPlanetConfig: CelestialAdvancedObjectConfig;
}

/** `HGStarConfig`: the star field and nebula */
export interface StarConfig {
	enableStars: boolean;
	starsTilling: number;
	starsFlickerSpeed: number;
	minMaxRange: Vec2;
	starsTint: Color;
	starsTint1: Color;
	thresholdSoftness: number;
	starsDensity: number;
	starsExposure: number;
	brightnessRandomSeed: number;
	colorRandomSeed: number;
	distributionRandomSeed: number;
	skyBoxStarRangeMap: TextureRef;
	/** degrees */
	skyBoxStarDensityMapRotation: number;
	starRingStarCoverage: number;
	cloudRingStarCoverage: number;
	starDensityMapMaskThres: number;
	debugMode: number;
	enableNebula: boolean;
	nebulaMap: TextureRef;
	nebulaTint: Color;
	/** degrees */
	nebulaMapRotation: number;
	nebulaStarConverage: number;
	celestialNebulaConverage: number;
}

/** `HGShadowConfig`: the sun shadow's look and the cached and contact shadows' settings */
export interface ShadowConfig {
	csmDepthBiasV2: number;
	csmNormalBiasV2: number;
	/** how far shadows darken the sun, 0–1 */
	csmIntensity: number;
	/** penumbra tint, sampled at the shadow value; black when `null` */
	csmRampTexture: TextureRef;
	/** filter radius numerator: over each cascade's split distance, in the game's shadow atlas uv */
	csmShadowSoftness: number;
	asmCasterMinY: number;
	asmCasterMaxY: number;
	contactShadowIntensity: number;
	contactShadowSurfaceThickness: number;
	contactShadowBilinearThreshold: number;
	contactShadowContract: number;
	contactShadowIgnoreEdgePixels: boolean;
	overrideCsmFarDistanceEnabled: boolean;
	overrideCsmFarDistance: number;
	manualOverrideCsmRendering: boolean;
	overrideCsmSpherePosition: Vec3;
	overrideCsmSphereRadius: number;
	disableCsm: boolean;
	/** how far the shadow is replaced by `csmSimulatedAttenuation` (1 in caves that keep the sun out) */
	disableCsmBlendFactor: number;
	csmSimulatedAttenuation: number;
	disableAsm: boolean;
	rhodesModeEnabled: boolean;
	rhodesShipCenter: Vec3;
	rhodesShipRadius: number;
}

/**
 * `HGRainConfig`: falling rain and the wetness it leaves. `enable` turns the rain on; the wetness fields
 * apply apart from it, whenever `enableWetness` is set. only the fields the viewer reads are listed; the
 * section holds the rest of the game's (streaks, splashes, screen drops, ripples) under their own names
 */
export interface RainConfig {
	enable: boolean;
	/** 0–100 */
	intensity: number;
	enableWetness: boolean;
	enableWetnessAffectSSR: boolean;
	/** 0–1, how wet surfaces get */
	wetness: number;
	/** porosity is `saturate(smoothness · factor + base)`: how far wetness darkens instead of smoothing */
	wetnessBasePorosity: number;
	wetnessPorosityFactor: number;
	/** the wetness of surfaces sheltered from the rain */
	baseWetnessLevel: number;
	/** the wetness of vertical surfaces, against 1 for those facing up */
	verticalWetnessScalar: number;
	/** where wetness fades into the far value, in multiples of the rain occlusion range */
	farSceneWetnessDistanceFactor: number;
	farSceneWetnessValue: number;
	/** above 0, the high-quality wetness lays standing water on flat ground near the camera */
	rippleRoughnessMaskThreshold: number;
}

/**
 * `HGLensFlareConfig`: the lens flare the sun draws while `enable` is set (SRP core's data-driven lens
 * flare). its direction is {@link LightConfig.rotationLensFlare}'s and its light colour
 * {@link LightConfig.directColor}
 */
export interface LensFlareConfig {
	enable: boolean;
	/** the flare's elements, or `null` when the reference is empty or unreadable */
	lensFlareData: LensFlareData | null;
	intensity: number;
	scale: number;
	useOcclusion: boolean;
	/** how far around the sun occlusion samples reach, in units of tan⁻¹ 0.0576 (about 3.3°) */
	occlusionRadius: number;
	sampleCount: number;
	occlusionOffset: number;
	allowOffScreen: boolean;
}

/** SRP core's `LensFlareDataSRP`: a flare's elements, drawn in order */
export interface LensFlareData {
	/** the asset's name, e.g. `LFlare_common_03` */
	name: string;
	elements: LensFlareElement[];
}

/** SRP core's `LensFlareDataElementSRP`, under its field names; colours raw */
export interface LensFlareElement {
	visible: boolean;
	/** along the ray from the light through the screen's centre: 0 at the light, 1 at the centre */
	position: number;
	positionOffset: Vec2;
	/** degrees the ray turns */
	angularOffset: number;
	translationScale: Vec2;
	localIntensity: number;
	lensFlareTexture: TextureRef;
	uniformScale: number;
	sizeXY: Vec2;
	allowMultipleElement: boolean;
	count: number;
	preserveAspectRatio: boolean;
	/** degrees */
	rotation: number;
	tint: Color;
	/** 0 additive, 1 screen, 2 premultiplied, 3 lerp */
	blendMode: number;
	autoRotate: boolean;
	/** 0 image, 1 circle, 2 polygon */
	flareType: number;
	modulateByLightColor: boolean;
	/** 0 uniform, 1 curve, 2 random */
	distribution: number;
	lengthSpread: number;
	positionCurve: AnimationCurve;
	scaleCurve: AnimationCurve;
	seed: number;
	colorGradient: Gradient;
	intensityVariation: number;
	positionVariation: Vec2;
	scaleVariation: number;
	rotationVariation: number;
	enableRadialDistortion: boolean;
	targetSizeDistortion: Vec2;
	distortionCurve: AnimationCurve;
	distortionRelativeToCenter: boolean;
	fallOff: number;
	edgeOffset: number;
	sideCount: number;
	sdfRoundness: number;
	inverseSDF: boolean;
	uniformAngle: number;
	uniformAngleCurve: AnimationCurve;
}

/** `HGWindConfig`: foliage and cloth wind */
export interface WindConfig {
	/** m/s */
	speed: number;
	/** degrees */
	horizontalDirectionAngle: number;
	verticalDirectionAngle: number;
	/** unit vector the wind blows toward, Unity world frame */
	direction: Vec3;
}

/** `HGLightShaftConfig`: screen-space sun shafts */
export interface LightShaftConfig {
	enable: boolean;
	bloomScale: number;
	bloomThreshold: number;
	bloomMaxBrightness: number;
	bloomTint: Color;
	blurIntensity: number;
	occlusionDepthRange: number;
	enableOcclusion: boolean;
	occlusionMaskDarkness: number;
}

/** `HGShadowsMidtonesHighlights` */
export interface ShadowsMidtonesHighlights {
	shadows: Vec4;
	midtones: Vec4;
	highlights: Vec4;
	shadowsStart: number;
	shadowsEnd: number;
	highlightsStart: number;
	highlightsEnd: number;
	shadowsOverriding: boolean;
	midtonesOverriding: boolean;
	highlightsOverriding: boolean;
	shadowsStartOverriding: boolean;
	shadowsEndOverriding: boolean;
	highlightsStartOverriding: boolean;
	highlightsEndOverriding: boolean;
}

/** `HGLiftGammaGain` */
export interface LiftGammaGain {
	lift: Vec4;
	gamma: Vec4;
	gain: Vec4;
	liftOverriding: boolean;
	gammaOverriding: boolean;
	gainOverriding: boolean;
}

/**
 * `HGColorGradingConfig`: tonemapping and URP-style grading (the colour curves aren't included).
 * `tonemappingMode` is the game's `TonemappingMode`: 0 `None`, 1 `Neutral`, 2 `ACES`, 3 `Custom`, 4
 * `External`, 5 `ACES_modified` (5 everywhere seen; 1–4 are hidden from the game's inspector)
 */
export interface ColorGradingConfig {
	tonemappingMode: number;
	colorLookupEnabled: boolean;
	colorLookupTexture: TextureRef;
	colorLookupContribution: number;
	whiteBalanceEnabled: boolean;
	whiteBalanceTemperature: number;
	whiteBalanceTint: number;
	colorAdjustmentsEnabled: boolean;
	colorAdjustmentsPostExposure: number;
	colorAdjustmentsContrast: number;
	colorAdjustmentsColorFilter: Color;
	colorAdjustmentsHueShift: number;
	colorAdjustmentsSaturation: number;
	channelMixerEnabled: boolean;
	channelMixerRedOutRedIn: number;
	channelMixerRedOutGreenIn: number;
	channelMixerRedOutBlueIn: number;
	channelMixerGreenOutRedIn: number;
	channelMixerGreenOutGreenIn: number;
	channelMixerGreenOutBlueIn: number;
	channelMixerBlueOutRedIn: number;
	channelMixerBlueOutGreenIn: number;
	channelMixerBlueOutBlueIn: number;
	shadowsMidtonesHighlightsEnabled: boolean;
	shadowsMidtonesHighlights: ShadowsMidtonesHighlights;
	liftGammaGainEnabled: boolean;
	liftGammaGain: LiftGammaGain;
	splitToningEnabled: boolean;
	splitToningShadows: Color;
	splitToningHighlights: Color;
	splitToningBalance: number;
	colorCurvesEnabled: boolean;
}

/**
 * `HGAutoExposureConfig`: the post exposure on top of {@link LightConfig.directEV100}'s. mode 0 meters the
 * scene, 1 holds `2^autoExposureManualEvCompensationManual`; metering mode 0 averages, 1 weights the centre
 */
export interface AutoExposureConfig {
	autoExposureMode: number;
	autoExposureManualEvCompensationAuto: number;
	autoExposureLerpUpSpeed: number;
	autoExposureLerpDownSpeed: number;
	autoExposureEv100Range: Vec2;
	autoExposureEv100HistogramRange: Vec2;
	autoExposureMeteringMode: number;
	autoExposurePixelLuminanceRange: Vec2;
	autoExposureEvClampRange: Vec2;
	autoExposureManualEvCompensationManual: number;
}

/**
 * a post-processing `VolumeProfile` (`gvp_*.asset`): its components under the game's field names, each `null`
 * when the profile doesn't have it or has it switched off. values are the profile's, overridden or not (with
 * a single global volume, the non-overridden ones are the defaults in effect). tonemapping isn't a volume
 * component here; see {@link ColorGradingConfig.tonemappingMode}
 */
export interface PostProfile {
	/** the profile's asset name, e.g. `gvp_map02_lv000_art_01` */
	name: string;
	bloom: BloomSettings | null;
	ambientOcclusion: AmbientOcclusionSettings | null;
	vignette: VignetteSettings | null;
	screenSpaceReflection: ScreenSpaceReflectionSettings | null;
}

/**
 * the game's `Bloom`, with settings per quality tier (the PC client's high tier is the reference look) and a
 * second, additive pass
 */
export interface BloomSettings {
	quality: number;
	resolutionHighQuality: number;
	resolutionMedQuality: number;
	resolutionLowQuality: number;
	thresholdHighQuality: number;
	thresholdMedQuality: number;
	thresholdLowQuality: number;
	intensityHighQuality: number;
	intensityMedQuality: number;
	intensityLowQuality: number;
	scatterHighQuality: number;
	scatterMedQuality: number;
	scatterLowQuality: number;
	tint: Color;
	blendMode: number;
	bloomUpsampleAdditive: boolean;
	thresholdAdditiveHighQuality: number;
	intensityAdditiveHighQuality: number;
	scatterAdditiveHighQuality: number;
	characterBloomControl: boolean;
	characterThreshold: number;
	characterSoftness: number;
	characterIntensity: number;
	dirtIntensity: number;
	anamorphic: boolean;
}

/** the game's `GTAmbientOcclusion` (ground-truth AO) */
export interface AmbientOcclusionSettings {
	enable: boolean;
	custom: boolean;
	enableFP32Depths: boolean;
	generateNormalsInplace: boolean;
	qualityLevel: number;
	denoisePasses: number;
	/** metres */
	radius: number;
	radiusMultiplier: number;
	falloffRange: number;
	sampleDistributionPower: number;
	thinOccluderCompensation: number;
	/** exponent applied to the AO term */
	finalValuePower: number;
	depthMIPSamplingOffset: number;
	mvFactor: number;
	depthFactor: number;
}

/** URP's `Vignette`, plus the game's mode and blink */
export interface VignetteSettings {
	mode: number;
	color: Color;
	/** screen UV */
	center: Vec2;
	intensity: number;
	smoothness: number;
	roundness: number;
	rounded: boolean;
	blink: boolean;
	opacity: number;
}

/** the game's `ScreenSpaceReflectionVolume` */
export interface ScreenSpaceReflectionSettings {
	enable: boolean;
	fadenessOnScreen: number;
	fadenessOnDepth: number;
	fadenessOnDepthFactor: number;
	fadenessOnMirrorMul: number;
	fadenessOnMirrorAdd: number;
	mipThreshold: number;
}
