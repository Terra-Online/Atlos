import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import { decodeBlobTable, encodeBlobTable } from './blob-table.ts';
import { BlobCodec, BlobKind, blobPath } from './blobs.ts';
import { PackageFormatError } from './errors.ts';
import { decodeGeometryTable, encodeGeometryTable } from './geometry-table.ts';
import {
	decodeGeometryBlob,
	encodeGeometryBlob,
	type GeometryBlob,
	type GeometryEntry,
	GeometryFlags,
	GeometryStreamFlags,
	GeometryVertexFormat,
	VertexAttribute,
} from './geometry.ts';
import {
	decodeChains,
	decodeInstanceBlock,
	encodeChains,
	encodeInstanceBlock,
	pathOffset,
	type Chain,
	ChainDrawFlags,
	ChainFlags,
	DrawRole,
	type InstanceBlock,
} from './instances.ts';
import { decodeIrradianceTable, encodeIrradianceTable } from './irradiance.ts';
import {
	decodeSplatPage,
	decodeHeightPage,
	decodeSurfacePage,
	encodeSplatPage,
	encodeHeightPage,
	encodeSurfacePage,
} from './terrain.ts';
import { decodeTextureTable, encodeTextureTable, TEXTURE_FORMAT_CODES } from './texture-table.ts';
import { TEXTURE_FORMATS, type TextureEntry, textureLevelLayout, type TextureSampler } from './textures.ts';
import { tileAncestor, tileAt } from './tiles.ts';
import { decodeTree, encodeTree, ContentKind, type Tree } from './tree.ts';

describe('tree', () => {
	it('round-trips nodes and refs', () => {
		const tree: Tree = {
			nodes: [
				{
					level: 0,
					x: -1,
					z: 0,
					bounds: { min: [-4096, -10.5, 0], max: [0, 400.25, 4096] },
					geometricError: 256,
					refFirst: 0,
					refCount: 2,
				},
				{
					level: 1,
					x: -2,
					z: 1,
					bounds: { min: [-4096, 0, 2048], max: [-2048, 1, 4096] },
					geometricError: 128,
					refFirst: 2,
					refCount: 0,
				},
			],
			refs: [
				{ kind: ContentKind.TerrainHeights, tier: 0, group: 0, blob: 7, first: 0, count: 1, reach: null },
				{ kind: ContentKind.Hlod, tier: 2, group: 10, blob: 3, first: 10, count: 4, reach: null },
				{ kind: ContentKind.Conditional, tier: 0, group: 2, blob: 5, first: 0, count: 9, reach: 0 },
			],
			global: [{ kind: ContentKind.Detail, tier: 0, group: 1, blob: 2, first: 0, count: 3, reach: null }],
			reaches: [{ minX: -Infinity, minZ: -64, maxX: 32, maxZ: Infinity }],
		};
		assert.deepEqual(decodeTree(encodeTree(tree)), tree);
	});

	it('rejects truncated input', () => {
		const data = encodeTree({ nodes: [], refs: [], global: [], reaches: [] });
		assert.throws(() => decodeTree(data.subarray(0, 8)), PackageFormatError);
	});

	it('rejects ref slices past the table', () => {
		assert.throws(
			() =>
				encodeTree({
					nodes: [
						{
							level: 0,
							x: 0,
							z: 0,
							bounds: { min: [0, 0, 0], max: [1, 1, 1] },
							geometricError: 0,
							refFirst: 0,
							refCount: 1,
						},
					],
					refs: [],
					global: [],
					reaches: [],
				}),
			RangeError,
		);
	});
});

describe('chains', () => {
	it('round-trips draws in order', () => {
		const chains: Chain[] = [
			{
				flags: 1,
				draws: [
					{
						geometry: 4,
						material: 9,
						particles: null,
						submesh: 1,
						lod: 0,
						role: DrawRole.Lit,
						minSquared: 0.25,
						maxSquared: 3.4028234663852886e38,
						flags: ChainDrawFlags.CastsCascades | ChainDrawFlags.CastsStatic,
						sortingLayer: 0,
						sortingOrder: 0,
					},
					{
						geometry: 5,
						material: null,
						particles: 3,
						submesh: 0,
						lod: 1,
						role: DrawRole.ShadowOnly,
						minSquared: -0.5,
						maxSquared: 0.25,
						flags: ChainDrawFlags.CastsStatic,
						sortingLayer: -1,
						sortingOrder: -4,
					},
				],
				distanceOrigin: null,
			},
			{ flags: 2, draws: [], distanceOrigin: null },
			{ flags: ChainFlags.CameraDistance, draws: [], distanceOrigin: [0.5, -2, 12.25] },
			{ flags: 0, draws: [], distanceOrigin: null },
		];
		assert.deepEqual(decodeChains(encodeChains(chains)), chains);
	});

	it('refuses a distance origin without its flag', () => {
		assert.throws(() => encodeChains([{ flags: 0, draws: [], distanceOrigin: [0, 0, 0] }]), RangeError);
	});
});

describe('blob table', () => {
	it('round-trips records', () => {
		const blobs = [
			{
				kind: BlobKind.Instances,
				codec: BlobCodec.Zstd,
				archive: 3,
				offset: 4_000_000_000,
				length: 12,
				rawLength: 40,
			},
		];
		assert.deepEqual(decodeBlobTable(encodeBlobTable(blobs)), blobs);
		assert.equal(
			blobPath('0123456789abcdef0123456789abcdef', blobs[0].kind, null),
			'blobs/0123456789abcdef0123456789abcdef.inst',
		);
		assert.equal(
			blobPath('0123456789abcdef0123456789abcdef', blobs[0].kind, '06.01'),
			'blobs/06.01/0123456789abcdef0123456789abcdef.inst',
		);
	});

	it('rejects 64-bit offsets and 17-bit archive indices', () => {
		const record = {
			kind: BlobKind.Geometry,
			codec: BlobCodec.None,
			archive: 0,
			offset: 0,
			length: 0,
			rawLength: 0,
		};
		assert.throws(() => encodeBlobTable([{ ...record, offset: 2 ** 32 }]), RangeError);
		assert.throws(() => encodeBlobTable([{ ...record, archive: 2 ** 16 }]), RangeError);
	});

	it('rejects unknown codecs and kinds', () => {
		const table = encodeBlobTable([
			{
				kind: BlobKind.Geometry,
				codec: BlobCodec.None,
				archive: 0,
				offset: 0,
				length: 0,
				rawLength: 0,
			},
		]);
		const badCodec = table.slice();
		badCodec[16 + 1] = 0xee;
		assert.throws(() => decodeBlobTable(badCodec), /unknown blob codec 238/);
		const badKind = table.slice();
		badKind[16] = 0xee;
		assert.throws(() => decodeBlobTable(badKind), /unknown blob kind 238/);
	});
});

describe('geometry table', () => {
	const ready: GeometryEntry = {
		status: 'ready',
		blob: 70_000,
		bounds: { min: [-1.5, 0, -2], max: [1.5, 3.25, 2] },
		vertexCount: 100_000,
		indexCount: 300_000,
		submeshCount: 3,
		attributes: (1 << 0) | (1 << 1) | (1 << 4),
		tangentUv: null,
		animationFrames: null,
	};

	it('round-trips entries, and gives blobs only for ready ones', () => {
		const entries: GeometryEntry[] = [
			ready,
			{ status: 'failed' },
			{ status: 'pending' },
			{ ...ready, blob: 0, tangentUv: 1, animationFrames: 420 },
		];
		const table = decodeGeometryTable(encodeGeometryTable(entries));
		assert.equal(table.count, 4);
		assert.deepEqual(
			entries.map((_, id) => table.entry(id)),
			entries,
		);
		assert.deepEqual(
			[0, 1, 2, 3, 4, -1].map((id) => table.blob(id)),
			[70_000, null, null, 0, null, null],
		);
		assert.throws(() => table.entry(4), RangeError);
	});

	it('rejects fields past their record and unknown statuses', () => {
		assert.throws(() => encodeGeometryTable([{ ...ready, submeshCount: 2 ** 16 }]), RangeError);
		assert.throws(() => encodeGeometryTable([{ ...ready, animationFrames: 0 }]), RangeError);
		const table = encodeGeometryTable([ready]);
		table[16] = 7;
		assert.throws(() => decodeGeometryTable(table), /geometry 0 has unknown status 7/);
	});
});

describe('texture table', () => {
	const sampler: TextureSampler = {
		addressModeU: 'repeat',
		addressModeV: 'clamp-to-edge',
		addressModeW: 'mirror-repeat',
		magFilter: 'linear',
		minFilter: 'linear',
		mipmapFilter: 'nearest',
		maxAnisotropy: 8,
		mipBias: -0.5,
	};
	const ready: TextureEntry = {
		status: 'ready',
		kind: 'cube-array',
		format: 'bc6h-rgb-ufloat',
		width: 4096,
		height: 2048,
		depthOrArrayLayers: 12,
		mipCount: 13,
		sampler: 1,
		pieces: [
			{ blob: 9, firstLevel: 5, levelCount: 8 },
			{ blob: 10, firstLevel: 4, levelCount: 1 },
		],
	};

	it('round-trips samplers and entries, and reads pieces without decoding entries', () => {
		const samplers = [sampler, { ...sampler, addressModeU: 'clamp-to-edge' as const, mipBias: 0 }];
		const entries: TextureEntry[] = [
			{ status: 'pending' },
			ready,
			{ status: 'failed' },
			{
				...ready,
				kind: '2d',
				format: 'rgba8unorm-srgb',
				sampler: 0,
				pieces: [{ blob: 3, firstLevel: 0, levelCount: 1 }],
			},
		];
		const table = decodeTextureTable(encodeTextureTable(samplers, entries));
		assert.equal(table.count, 4);
		assert.deepEqual(table.samplers, samplers);
		assert.deepEqual(
			entries.map((_, id) => table.entry(id)),
			entries,
		);
		assert.equal(table.entry(1), table.entry(1));
		assert.equal(table.entry(4), undefined);
		assert.deepEqual(
			[0, 1, 2, 3, 4].map((id) => table.pieceCount(id)),
			[0, 2, 0, 1, 0],
		);
		assert.deepEqual([table.pieceBlob(1, 0), table.pieceBlob(1, 1), table.pieceBlob(3, 0)], [9, 10, 3]);
	});

	it('codes every texture format', () => {
		assert.deepEqual(TEXTURE_FORMAT_CODES.toSorted(), Object.keys(TEXTURE_FORMATS).toSorted());
	});

	it('rejects values without a code, sampler indices past the palette and unknown codes', () => {
		assert.throws(
			() => encodeTextureTable([sampler], [{ ...ready, sampler: 0, format: 'astc-4x4-unorm' }]),
			RangeError,
		);
		assert.throws(() => encodeTextureTable([sampler], [ready]), RangeError);
		const table = encodeTextureTable([sampler, sampler], [ready]);
		// the texture record follows the 20-byte header and two 12-byte samplers
		const badFormat = table.slice();
		badFormat[20 + 24 + 2] = 0xee;
		assert.throws(() => decodeTextureTable(badFormat), /unknown texture format 238/);
		const badSampler = table.slice();
		badSampler[20 + 24 + 10] = 2;
		assert.throws(() => decodeTextureTable(badSampler), /sampler is past the palette/);
	});
});

describe('irradiance table', () => {
	it('round-trips cells, with a scene-state bake repeating a key', () => {
		const table = {
			keys: Uint32Array.of(1, 0x0108_8080, 0x0108_8080, 0x0230_9040),
			blobs: Uint32Array.of(7, 3, 0, 12),
			groups: Uint32Array.of(0, 5, 0, 0),
		};
		const decoded = decodeIrradianceTable(encodeIrradianceTable(table));
		assert.deepEqual([...decoded.keys], [...table.keys]);
		assert.deepEqual([...decoded.blobs], [...table.blobs]);
		assert.deepEqual([...decoded.groups], [...table.groups]);
	});

	it('rejects descending keys and truncated input', () => {
		assert.throws(
			() =>
				encodeIrradianceTable({
					keys: Uint32Array.of(2, 1),
					blobs: Uint32Array.of(0, 1),
					groups: Uint32Array.of(0, 0),
				}),
			RangeError,
		);
		const encoded = encodeIrradianceTable({
			keys: Uint32Array.of(1),
			blobs: Uint32Array.of(0),
			groups: Uint32Array.of(0),
		});
		assert.throws(() => decodeIrradianceTable(encoded.subarray(0, encoded.length - 4)), PackageFormatError);
	});
});

describe('instance blocks', () => {
	const block = (count: number): InstanceBlock => ({
		origin: [-1024, 0, 512],
		chains: Uint32Array.from({ length: count }, (_, i) => i * 3),
		transforms: Float32Array.from({ length: count * 12 }, (_, i) => i / 4),
		bounds: Float32Array.from({ length: count * 6 }, (_, i) => -i),
		// every other row a decal
		decals: {
			rows: Uint32Array.from({ length: Math.ceil(count / 2) }, (_, i) => i * 2),
			values: Float32Array.from({ length: Math.ceil(count / 2) * 8 }, (_, i) => i / 8),
		},
		// every third row spinning
		spins: {
			rows: Uint32Array.from({ length: Math.ceil(count / 3) }, (_, i) => i * 3),
			values: Float32Array.from({ length: Math.ceil(count / 3) * 7 }, (_, i) => i / 7),
		},
		// every row past the first floating
		floaters: {
			rows: Uint32Array.from({ length: Math.max(count - 1, 0) }, (_, i) => i + 1),
			values: Uint32Array.from({ length: Math.max(count - 1, 0) }, (_, i) => i * 5),
		},
		// the last row riding the second of two paths
		rides: {
			rows: count === 0 ? new Uint32Array(0) : Uint32Array.of(count - 1),
			values: count === 0 ? new Uint32Array(0) : Uint32Array.of(1),
		},
		paths:
			count === 0
				? []
				: [
						{ frameRate: 15, offsets: Float32Array.of(0, 0, 0) },
						{ frameRate: 7.5, offsets: Float32Array.of(0, 0, 0, 1, 2, 3, 4, 5, 6) },
					],
	});

	it('finds a path’s offset at a time, blending frames and wrapping to the loop', () => {
		const path = { frameRate: 2, offsets: Float32Array.of(0, 0, 0, 4, 0, 0, 4, 2, 0) };
		const at = (time: number) => pathOffset(path, time, [0, 0, 0]);
		assert.deepEqual(at(0), [0, 0, 0]);
		assert.deepEqual(at(0.25), [2, 0, 0]);
		assert.deepEqual(at(0.5), [4, 0, 0]);
		// the last frame blends back towards the first
		assert.deepEqual(at(1.25), [2, 1, 0]);
		assert.deepEqual(at(1.75), [2, 0, 0]);
		assert.deepEqual(at(-1.25), [2, 0, 0]);
	});

	it('rejects rides naming no path, and paths without whole frames or a frame rate', () => {
		const ride = { rows: Uint32Array.of(0), values: Uint32Array.of(2) };
		assert.throws(() => encodeInstanceBlock({ ...block(3), rides: ride }), RangeError);
		const paths = (path: { frameRate: number; offsets: Float32Array }) => ({
			...block(3),
			paths: [path, path],
		});
		assert.throws(
			() => encodeInstanceBlock(paths({ frameRate: 15, offsets: new Float32Array(0) })),
			RangeError,
		);
		assert.throws(
			() => encodeInstanceBlock(paths({ frameRate: 15, offsets: new Float32Array(4) })),
			RangeError,
		);
		assert.throws(
			() => encodeInstanceBlock(paths({ frameRate: 0, offsets: new Float32Array(3) })),
			RangeError,
		);
	});

	it('round-trips any count, with its decal placements, spins, floaters, rides and paths', () => {
		for (const count of [0, 1, 3, 4, 5]) {
			assert.deepEqual(decodeInstanceBlock(encodeInstanceBlock(block(count))), block(count));
		}
	});

	it('keeps sections 4-byte aligned', () => {
		const data = encodeInstanceBlock(block(3));
		assert.equal(data.length % 4, 0);
	});

	it('rejects mismatched sections, and decal or spinning rows out of order or past the block', () => {
		assert.throws(() => encodeInstanceBlock({ ...block(2), bounds: new Float32Array(6) }), RangeError);
		const placements = (rows: number[]) => ({
			rows: Uint32Array.from(rows),
			values: new Float32Array(rows.length * 8),
		});
		assert.throws(() => encodeInstanceBlock({ ...block(3), decals: placements([2, 0]) }), RangeError);
		assert.throws(() => encodeInstanceBlock({ ...block(3), decals: placements([3]) }), RangeError);
		const spins = (rows: number[]) => ({
			rows: Uint32Array.from(rows),
			values: new Float32Array(rows.length * 7),
		});
		assert.throws(() => encodeInstanceBlock({ ...block(3), spins: spins([1, 1]) }), RangeError);
		assert.throws(() => encodeInstanceBlock({ ...block(3), spins: spins([3]) }), RangeError);
		assert.throws(
			() =>
				encodeInstanceBlock({
					...block(3),
					floaters: { rows: Uint32Array.of(0), values: new Uint32Array(2) },
				}),
			RangeError,
		);
	});
});

describe('height pages', () => {
	it('round-trips heights, holes and wrapping deltas exactly', () => {
		const side = 65;
		const samples = new Uint16Array(side * side);
		let seed = 12345;
		for (let i = 0; i < samples.length; i++) {
			seed = (seed * 1103515245 + 12345) & 0x7fff_ffff;
			const x = i % side;
			const z = Math.floor(i / side);
			// smooth terrain with a hole patch and a few extreme values
			let h = 8000 + x * 37 + z * 11 + (seed % 7);
			if (x > 40 && z < 10) {
				h |= 0x8000;
			}
			if (i % 997 === 0) {
				h = i % 2 === 0 ? 0 : 0xffff;
			}
			samples[i] = h;
		}
		const decoded = decodeHeightPage(encodeHeightPage(samples, side));
		assert.equal(decoded.side, side);
		assert.deepEqual(decoded.samples, samples);
	});

	it('rejects the wrong sample count', () => {
		assert.throws(() => encodeHeightPage(new Uint16Array(10), 65), RangeError);
	});
});

describe('splat pages', () => {
	it('round-trips every section', () => {
		const page = {
			side: 8,
			cells: 2,
			control: Uint8Array.from({ length: 8 * 8 * 4 }, (_, i) => i & 0xff),
			tint: Uint8Array.from({ length: 4 * 16 }, (_, i) => 200 - i),
			index: Uint8Array.from({ length: 2 * 2 * 4 }, (_, i) => i),
		};
		const decoded = decodeSplatPage(encodeSplatPage(page));
		assert.equal(decoded.side, 8);
		assert.equal(decoded.cells, 2);
		assert.deepEqual(decoded.control, page.control);
		assert.deepEqual(decoded.tint, page.tint);
		assert.deepEqual(decoded.index, page.index);
	});

	it('rejects sections of the wrong size', () => {
		const page = {
			side: 8,
			cells: 2,
			control: new Uint8Array(8 * 8 * 4),
			tint: new Uint8Array(4 * 16),
			index: new Uint8Array(15),
		};
		assert.throws(() => encodeSplatPage(page), RangeError);
	});
});

describe('surface pages', () => {
	it('round-trips both images', () => {
		const albedo = Uint8Array.from({ length: 4 * 16 }, (_, i) => i);
		const normal = Uint8Array.from({ length: 4 * 16 }, (_, i) => 255 - i);
		const decoded = decodeSurfacePage(encodeSurfacePage({ side: 8, albedo, normal }));
		assert.equal(decoded.side, 8);
		assert.deepEqual(decoded.albedo, albedo);
		assert.deepEqual(decoded.normal, normal);
	});

	it('rejects images of the wrong size', () => {
		const image = new Uint8Array(4 * 16);
		assert.throws(() => encodeSurfacePage({ side: 8, albedo: image, normal: image.subarray(1) }), RangeError);
	});

	it('rejects truncated data', () => {
		const image = new Uint8Array(4 * 16);
		const encoded = encodeSurfacePage({ side: 8, albedo: image, normal: image });
		assert.throws(() => decodeSurfacePage(encoded.subarray(0, encoded.length - 1)), PackageFormatError);
	});
});

describe('geometry blobs', () => {
	it('round-trips the container with unaligned payloads', () => {
		const blob: GeometryBlob = {
			flags: GeometryFlags.GeneratedTangents,
			vertexCount: 5,
			indexCount: 9,
			streams: [
				{
					attribute: VertexAttribute.Position,
					format: GeometryVertexFormat.Unorm16x4,
					flags: GeometryStreamFlags.Dequantize,
					offset: [-1, 0, 2.5],
					scale: [2, 0, 0.5],
					data: Uint8Array.from([1, 2, 3, 4, 5]),
				},
				{
					attribute: VertexAttribute.TexCoord0 + 1,
					format: GeometryVertexFormat.Float32x2,
					flags: 0,
					offset: [0, 0, 0],
					scale: [1, 1, 1],
					data: Uint8Array.from([9, 8, 7]),
				},
			],
			submeshes: [
				{
					firstIndex: 0,
					indexCount: 6,
					baseVertex: 0,
					vertexCount: 4,
					bounds: { min: [-1, 0, 2.5], max: [1, 0, 3] },
				},
				{
					firstIndex: 6,
					indexCount: 3,
					baseVertex: 4,
					vertexCount: 1,
					bounds: { min: [0, 0, 0], max: [0, 0, 0] },
				},
			],
			indices: Uint8Array.from([42, 43, 44, 45, 46, 47, 48]),
			animation: null,
		};
		const encoded = encodeGeometryBlob(blob);
		assert.equal(encoded.byteLength % 4, 0);
		assert.deepEqual(decodeGeometryBlob(encoded), blob);
		assert.throws(() => decodeGeometryBlob(encoded.subarray(0, encoded.byteLength - 4)), PackageFormatError);
		const badFormat = encoded.slice();
		badFormat[32 + 1] = 200;
		assert.throws(() => decodeGeometryBlob(badFormat), /unknown vertex format/);
	});

	it('round-trips a skeletal animation after the indices', () => {
		const blob: GeometryBlob = {
			flags: 0,
			vertexCount: 1,
			indexCount: 3,
			streams: [
				{
					attribute: VertexAttribute.BlendIndices,
					format: GeometryVertexFormat.Uint8x4,
					flags: 0,
					offset: [0, 0, 0],
					scale: [1, 1, 1],
					data: Uint8Array.from([1, 0, 0, 0]),
				},
			],
			submeshes: [],
			// six bytes, so the animation starts after padding
			indices: Uint8Array.from([1, 2, 3, 4, 5, 6]),
			animation: {
				boneCount: 2,
				frameCount: 3,
				frameRate: 30,
				offset: [-1, 0, -2],
				scale: [2, 7, 4],
				matrices: Float32Array.from({ length: 2 * 3 * 12 }, (_, i) => i / 4),
			},
		};
		const encoded = encodeGeometryBlob(blob);
		assert.deepEqual(decodeGeometryBlob(encoded), blob);
		assert.throws(() => decodeGeometryBlob(encoded.subarray(0, encoded.byteLength - 4)), PackageFormatError);
		assert.throws(
			() => encodeGeometryBlob({ ...blob, animation: { ...blob.animation!, frameCount: 4 } }),
			/disagree with its matrices/,
		);
	});
});

describe('texture levels', () => {
	it('lays out block-compressed, array and 3D levels', () => {
		const bc7 = {
			kind: '2d-array',
			format: 'bc7-rgba-unorm',
			width: 100,
			height: 60,
			depthOrArrayLayers: 3,
		} as const;
		// 100×60 → 25×15 blocks of 16 bytes, three layers
		assert.deepEqual(textureLevelLayout(bc7, 0), {
			width: 100,
			height: 60,
			depthOrArrayLayers: 3,
			bytesPerRow: 400,
			rowsPerImage: 15,
			byteLength: 18_000,
		});
		// 1×1 still takes a whole block
		assert.equal(textureLevelLayout(bc7, 7).byteLength, 48);
		const volume = { kind: '3d', format: 'rgba16float', width: 8, height: 8, depthOrArrayLayers: 8 } as const;
		assert.equal(textureLevelLayout(volume, 1).byteLength, 4 * 4 * 4 * 8);
		assert.throws(() => textureLevelLayout({ ...volume, format: 'astc-4x4-unorm' }, 0), RangeError);
	});
});

describe('tile addressing', () => {
	const tree = { origin: [-2048, -2048] as [number, number], rootSize: 4096 };

	it('finds tiles off the root square', () => {
		assert.deepEqual(tileAt(tree, 6, -2048, -2048), { level: 6, x: 0, z: 0 });
		assert.deepEqual(tileAt(tree, 6, -2049, 2048), { level: 6, x: -1, z: 64 });
	});

	it('floors negative coordinates towards their ancestor', () => {
		assert.deepEqual(tileAncestor({ level: 6, x: -1, z: 65 }, 3), { level: 3, x: -1, z: 8 });
		assert.throws(() => tileAncestor({ level: 2, x: 0, z: 0 }, 3), RangeError);
	});
});
