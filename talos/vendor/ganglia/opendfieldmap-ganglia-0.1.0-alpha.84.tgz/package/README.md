# Ganglia

Ganglia is an experimental route solver for Open Endfield Map. Atlos owns game-data
adaptation and visualization; Ganglia owns route feasibility, search and movement
scheduling. See the [development guide](docs/contributing.md) for local integration.

**License notice:** current project-owned releases use the custom [Ganglia Source-Available
License](LICENSE), which excludes zmdmap.com, fz.wiki and the related operators and projects
defined there. For eligible recipients, it incorporates AGPL 3.0 copyleft obligations,
including the modified-version network source offer. Read the complete license before use.

## Solver interface

Choose an algorithm and its fixed policy when preparing a solver. Scene resources
and movement facts must belong to the same immutable game snapshot. Queries supply
starts, a goal and optional interaction conditions or discovery waypoints.

```ts
import {
  gangliaV1Defaults,
  prepareRouteSolver,
} from '@opendfieldmap/ganglia/solver';

const solver = await prepareRouteSolver(
  { ...gangliaV1Defaults, maxCandidates: 4000 },
  { kind: 'scene', scene, resources, locomotion },
);
try {
  const results = await solver.solveBatch(queries);
} finally {
  await solver.close();
}
```

The factory also accepts prepared physical or surface inputs. Configuration fields,
units and policy constraints are defined in [GangliaV1Config](src/solver/ganglia-v1.ts).
The same policy applies to every query and batch lane. Results distinguish complete,
partial and unverified routes; bounded-search truncation does not prove that no route
exists or that a returned route is optimal.

Package entry points separate callers by responsibility:

- `@opendfieldmap/ganglia`: geometry/movement/route types and trajectory playback.
- `@opendfieldmap/ganglia/solver`: solver factory, fixed configuration and contracts.
- `@opendfieldmap/ganglia/solver/host`: resource-adapter operations and serialized work.
- `@opendfieldmap/ganglia/build`: physical ground generation.
- `@opendfieldmap/ganglia/collision`: collision queries.

The `src/v1/` tree contains the ganglia-v1 implementation. It has no package export.
Shared contracts live outside it so another solver can implement the same interface.
Algorithm changes belong in Ganglia. Atlos owns its maintained noclip patches;
`talos/.cache/noclip` is generated source.

## Development

Node.js 24.12 or newer runs the TypeScript sources directly. Native Node consumers
link extracted sources outside `node_modules`; browser consumers use their bundler.
The package-local `#@/` imports resolve through `package.json`. Atlos consumes a pinned
source archive through a generated workspace package.

```bash
pnpm check
pnpm benchmark:full --limit 3 --json
```

The benchmark submits a full scene batch after loading inputs and prewarming the
prepared solver. `--config` accepts a complete serialized solver configuration.
Keep local dependencies, data and generated evidence under `.local/`.
